import React, { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { AppProvider } from './contexts/AppContext';
import { LoginForm } from './components/Auth/LoginForm';
import { Sidebar } from './components/Layout/Sidebar';
import { ChatInterface } from './components/Chat/ChatInterface';
import { SettingsPanel } from './components/Settings/SettingsPanel';
import { TemplatesPanel } from './components/Templates/TemplatesPanel';
import { PersonalAssistantPanel } from './components/PersonalAssistant/PersonalAssistantPanel';
import { ArticleGeneratorPanel } from '@/components/ArticleGenerator/ArticleGeneratorPanel';
import { ImageGeneratorPanel } from '@/components/ImageGenerator/ImageGeneratorPanel';
import { ResearchAssistantPanel } from '@/components/ResearchAssistant/ResearchAssistantPanel';
import { PromptLibraryPanel } from '@/components/PromptLibrary/PromptLibraryPanel';
import { TaskPlannerPanel } from '@/components/TaskPlanner/TaskPlannerPanel';
import { PaymentsPanel } from './components/Payments/PaymentsPanel';
import { Toaster } from './components/ui/toaster';
import './App.css';

function AppContent() {
  const { user, isLoading } = useAuth();
  const [activeTab, setActiveTab] = useState('chat');

  if (isLoading) {
    return (
      <div className="w-full h-full bg-gradient-to-b from-purple-900 via-indigo-900 to-black flex items-center justify-center">
        <div className="text-white text-xl">Yükleniyor...</div>
      </div>
    );
  }

  if (!user) {
    return <LoginForm />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'chat':
        return <ChatInterface />;
      case 'settings':
        return <SettingsPanel />;
      case 'templates':
        return <TemplatesPanel />;
      case 'personal-assistant':
        return <PersonalAssistantPanel />;
      case 'article-generator':
        return <ArticleGeneratorPanel />;
      case 'image-generator':
        return <ImageGeneratorPanel />;
      case 'research-assistant':
        return <ResearchAssistantPanel />;
      case 'prompt-library':
        return <PromptLibraryPanel />;
      case 'task-planner':
        return <TaskPlannerPanel />;
      case 'payments':
        return <PaymentsPanel />;
      default:
        return <ChatInterface />;
    }
  };

  return (
    <div className="flex w-full h-full bg-gradient-to-b from-gray-900 to-black overflow-hidden">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      <main className="flex-1 flex flex-col h-full">
        {renderContent()}
      </main>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppProvider>
        <AppContent />
        <Toaster />
      </AppProvider>
    </AuthProvider>
  );
}

export default App;