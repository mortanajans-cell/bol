import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Conversation, Settings, Template } from '@/types';

interface AppContextType {
  conversations: Conversation[];
  currentConversation: Conversation | null;
  settings: Settings;
  templates: Template[];
  language: 'tr' | 'en';
  autoSave: boolean;
  notifications: boolean;
  setConversations: (conversations: Conversation[]) => void;
  setCurrentConversation: (conversation: Conversation | null) => void;
  setSettings: (settings: Settings) => void;
  setTemplates: (templates: Template[]) => void;
  setLanguage: (language: 'tr' | 'en') => void;
  setAutoSave: (autoSave: boolean) => void;
  setNotifications: (notifications: boolean) => void;
  addMessage: (content: string, role: 'user' | 'assistant') => void;
  createNewConversation: () => void;
  selectConversation: (conversation: Conversation) => void;
  updateConversationTitle: (conversationId: string, newTitle: string) => void;
  generateAIResponse: (userMessage: string, settings: Settings) => Promise<string>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const defaultSettings: Settings = {
  id: '1',
  user_id: '1',
  mode: 'creative',
  temperature: 0.7,
  max_tokens: 1024,
  response_length: 'long',
  response_style: 'balanced',
};

export function AppProvider({ children }: { children: ReactNode }) {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [currentConversation, setCurrentConversation] = useState<Conversation | null>(null);
  const [settings, setSettings] = useState<Settings>(defaultSettings);
  const [templates, setTemplates] = useState<Template[]>([]);
  const [language, setLanguage] = useState<'tr' | 'en'>('tr');
  const [autoSave, setAutoSave] = useState(true);
  const [notifications, setNotifications] = useState(true);

  // Load conversations from localStorage on mount
  React.useEffect(() => {
    const savedConversations = localStorage.getItem('conversations');
    if (savedConversations) {
      try {
        const parsedConversations = JSON.parse(savedConversations);
        setConversations(parsedConversations);
      } catch (error) {
        console.error('Error loading conversations:', error);
      }
    }
  }, []);

  // OpenRouter.ai API Integration
  const generateAIResponse = async (userMessage: string, currentSettings: Settings): Promise<string> => {
    const { mode, temperature, max_tokens, response_style } = currentSettings;
    
    // System prompt based on mode
    const systemPrompts = {
      creative: "Sen yaratıcı ve ilham verici bir AI asistanısın. Özgün fikirler üret ve yaratıcı çözümler sun.",
      analytical: "Sen analitik düşünen bir AI asistanısın. Verileri analiz et, objektif değerlendirmeler yap.",
      business: "Sen iş dünyasında uzman bir AI asistanısın. Profesyonel tavsiyelerde bulun ve iş stratejileri öner.",
      technical: "Sen teknik konularda uzman bir AI asistanısın. Kod, sistem mimarisi ve teknik çözümler konusunda yardım et."
    };

    // Response style instructions
    const styleInstructions = {
      balanced: "Dengeli ve anlaşılır bir dille yanıtla.",
      detailed: "Detaylı açıklamalar yap ve örnekler ver.",
      summary: "Kısa ve öz yanıtlar ver.",
      casual: "Samimi ve günlük bir dille konuş.",
      professional: "Profesyonel ve resmi bir ton kullan."
    };

    try {
      const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': 'Bearer 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',
          'Content-Type': 'application/json',
          'HTTP-Referer': window.location.origin,
          'X-Title': 'AI Portal Chat'
        },
        body: JSON.stringify({
          model: 'anthropic/claude-3.5-sonnet',
          messages: [
            {
              role: 'system',
              content: `${systemPrompts[mode]} ${styleInstructions[response_style]} Türkçe yanıt ver.`
            },
            {
              role: 'user',
              content: userMessage
            }
          ],
          temperature: temperature,
          max_tokens: max_tokens,
          stream: false
        })
      });

      if (!response.ok) {
        throw new Error(`API Error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      
      if (data.choices && data.choices[0] && data.choices[0].message) {
        return data.choices[0].message.content;
      } else {
        throw new Error('Geçersiz API yanıtı');
      }
      
    } catch (error) {
      console.error('OpenRouter API Error:', error);
      
      // Fallback response
      return `Üzgünüm, şu anda AI servisine bağlanamıyorum. Lütfen daha sonra tekrar deneyin.\n\nHata: ${error.message}`;
    }
  };
  
  const addMessage = (content: string, role: 'user' | 'assistant') => {
    if (!currentConversation) {
      return;
    }

    const newMessage = {
      id: Math.random().toString(36).substr(2, 9),
      role,
      content,
      timestamp: new Date().toISOString(),
    };

    // CRITICAL: Always use functional update to preserve existing messages
    const updatedConversation = {
      ...currentConversation,
      messages: [...currentConversation.messages, newMessage],
      updated_at: new Date().toISOString(),
    };

    // Update current conversation immediately
    setCurrentConversation(updatedConversation);

    // Update conversations list
    setConversations(prev => {
      const existingIndex = prev.findIndex(conv => conv.id === updatedConversation.id);
      if (existingIndex >= 0) {
        const newConversations = [...prev];
        newConversations[existingIndex] = updatedConversation;
        return newConversations;
      } else {
        return [updatedConversation, ...prev];
      }
    });

    if (autoSave) {
      setTimeout(() => {
        localStorage.setItem(`conversation_${updatedConversation.id}`, JSON.stringify(updatedConversation));
        const currentConversations = JSON.parse(localStorage.getItem('conversations') || '[]');
        const updatedConversations = currentConversations.map((conv: Conversation) => 
          conv.id === updatedConversation.id ? updatedConversation : conv
        );
        if (!updatedConversations.find((conv: Conversation) => conv.id === updatedConversation.id)) {
          updatedConversations.unshift(updatedConversation);
        }
        localStorage.setItem('conversations', JSON.stringify(updatedConversations));
      }, 100);
    }
  };

  const createNewConversation = () => {
    const newConversation: Conversation = {
      id: Math.random().toString(36).substr(2, 9),
      user_id: '1',
      title: 'Yeni Sohbet',
      messages: [],
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    setCurrentConversation(newConversation);
    setConversations(prev => [newConversation, ...prev]);

    if (autoSave) {
      setTimeout(() => {
        const currentConversations = JSON.parse(localStorage.getItem('conversations') || '[]');
        const updatedConversations = [newConversation, ...currentConversations];
        localStorage.setItem('conversations', JSON.stringify(updatedConversations));
        localStorage.setItem(`conversation_${newConversation.id}`, JSON.stringify(newConversation));
      }, 100);
    }
  };

  const selectConversation = (conversation: Conversation) => {
    setCurrentConversation(conversation);
  };

  const updateConversationTitle = (conversationId: string, newTitle: string) => {
    const updatedConversations = conversations.map(conv => 
      conv.id === conversationId 
        ? { ...conv, title: newTitle, updated_at: new Date().toISOString() }
        : conv
    );
    
    setConversations(updatedConversations);
    
    if (currentConversation?.id === conversationId) {
      setCurrentConversation({ ...currentConversation, title: newTitle, updated_at: new Date().toISOString() });
    }
    
    // Auto-save if enabled
    if (autoSave) {
      const updatedConv = updatedConversations.find(c => c.id === conversationId);
      if (updatedConv) {
        localStorage.setItem(`conversation_${conversationId}`, JSON.stringify(updatedConv));
      }
    }
  };
  return (
    <AppContext.Provider value={{
      conversations,
      currentConversation,
      settings,
      templates,
      language,
      autoSave,
      notifications,
      setConversations,
      setCurrentConversation,
      setSettings,
      setTemplates,
      setLanguage,
      setAutoSave,
      setNotifications,
      addMessage,
      createNewConversation,
      selectConversation,
      updateConversationTitle,
      generateAIResponse,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}