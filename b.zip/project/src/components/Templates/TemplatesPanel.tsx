import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Heart, Play, Crown, Filter, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useApp } from '@/contexts/AppContext';
import { useAuth } from '@/contexts/AuthContext';
import { Template } from '@/types';
import { toast } from '@/hooks/use-toast';

const mockTemplates: Template[] = [
  // İş
  {
    id: '1',
    category: 'İş',
    title: 'E-posta Taslağı',
    description: 'Profesyonel iş e-postası hazırlayın',
    content: 'Aşağıdaki konuda profesyonel bir e-posta yazın: [KONU]',
    premium_only: false,
  },
  {
    id: '2',
    category: 'İş',
    title: 'Toplantı Özeti',
    description: 'Toplantı notlarınızdan özet çıkarın',
    content: 'Bu toplantı notlarından kapsamlı bir özet çıkarın: [NOTLAR]',
    premium_only: false,
  },
  {
    id: '3',
    category: 'İş',
    title: 'İş Planı Taslağı',
    description: 'Detaylı iş planı hazırlayın',
    content: 'Aşağıdaki iş fikri için detaylı bir iş planı hazırlayın: [İŞ FİKRİ]',
    premium_only: true,
  },
  {
    id: '4',
    category: 'İş',
    title: 'Proje Teklifi',
    description: 'Müşteri için proje teklifi hazırlayın',
    content: 'Bu proje için detaylı teklif hazırlayın: [PROJE DETAYLARI]. Zaman çizelgesi, bütçe ve deliverable\'ları dahil edin.',
    premium_only: false,
  },
  {
    id: '5',
    category: 'İş',
    title: 'İK Politikası',
    description: 'Şirket için İK politikası oluşturun',
    content: 'Şirketimiz için [POLİTİKA KONUSU] hakkında kapsamlı İK politikası yazın.',
    premium_only: true,
  },
  {
    id: '6',
    category: 'İş',
    title: 'Müşteri Memnuniyeti Anketi',
    description: 'Müşteri geri bildirimi için anket soruları',
    content: '[HİZMET/ÜRÜN] için müşteri memnuniyeti anketi hazırlayın. 10-15 soru içersin.',
    premium_only: false,
  },
  {
    id: '7',
    category: 'İş',
    title: 'Satış Sunumu',
    description: 'Etkili satış sunumu hazırlayın',
    content: '[ÜRÜN/HİZMET] için ikna edici satış sunumu hazırlayın. Müşteri ihtiyaçlarına odaklanın.',
    premium_only: true,
  },
  {
    id: '8',
    category: 'İş',
    title: 'Performans Değerlendirmesi',
    description: 'Çalışan performans değerlendirme formu',
    content: '[POZİSYON] için kapsamlı performans değerlendirme formu oluşturun.',
    premium_only: true,
  },
  {
    id: '9',
    category: 'İş',
    title: 'İş İlanı',
    description: 'Çekici iş ilanı metni yazın',
    content: '[POZİSYON] için çekici ve detaylı iş ilanı yazın. Gereksinimler ve faydaları belirtin.',
    premium_only: false,
  },
  
  // Pazarlama
  {
    id: '10',
    category: 'Pazarlama',
    title: 'Sosyal Medya İçeriği',
    description: 'Sosyal medya paylaşımları oluşturun',
    content: 'Bu ürün/hizmet için çekici sosyal medya içeriği yazın: [ÜRÜN/HİZMET]',
    premium_only: false,
  },
  {
    id: '11',
    category: 'Pazarlama',
    title: 'Blog Yazısı Başlıkları',
    description: 'SEO uyumlu blog başlıkları',
    content: 'Bu konuda 10 farklı SEO uyumlu blog yazısı başlığı öner: [KONU]',
    premium_only: false,
  },
  {
    id: '12',
    category: 'Pazarlama',
    title: 'E-posta Pazarlama Kampanyası',
    description: 'Etkili e-posta pazarlama metni',
    content: '[ÜRÜN/HİZMET] için e-posta pazarlama kampanyası yazın. Konu satırı ve CTA dahil.',
    premium_only: false,
  },
  {
    id: '13',
    category: 'Pazarlama',
    title: 'Influencer İş Birliği Teklifi',
    description: 'Influencer\'lara iş birliği teklifi',
    content: '[MARKA] adına influencer\'lara iş birliği teklifi yazın. Karşılıklı faydaları vurgulayın.',
    premium_only: true,
  },
  {
    id: '14',
    category: 'Pazarlama',
    title: 'Google Ads Metni',
    description: 'Etkili Google Ads reklam metni',
    content: '[ÜRÜN/HİZMET] için Google Ads reklam metni yazın. Başlık, açıklama ve CTA dahil.',
    premium_only: false,
  },
  {
    id: '15',
    category: 'Pazarlama',
    title: 'Marka Hikayesi',
    description: 'Duygusal bağ kuran marka hikayesi',
    content: '[MARKA] için duygusal ve etkileyici marka hikayesi yazın.',
    premium_only: true,
  },
  {
    id: '16',
    category: 'Pazarlama',
    title: 'Müşteri Testimonial\'ı',
    description: 'İnandırıcı müşteri yorumu yazın',
    content: '[ÜRÜN/HİZMET] için gerçekçi ve ikna edici müşteri testimonial\'ı yazın.',
    premium_only: false,
  },
  {
    id: '17',
    category: 'Pazarlama',
    title: 'Pazarlama Stratejisi',
    description: 'Kapsamlı pazarlama stratejisi planı',
    content: '[ÜRÜN/HİZMET] için 6 aylık pazarlama stratejisi planı hazırlayın.',
    premium_only: true,
  },
  {
    id: '18',
    category: 'Pazarlama',
    title: 'Landing Page Metni',
    description: 'Dönüşüm odaklı landing page',
    content: '[ÜRÜN/HİZMET] için yüksek dönüşüm oranına sahip landing page metni yazın.',
    premium_only: true,
  },
  
  // Gazeteciler
  {
    id: '19',
    category: 'Gazeteciler',
    title: 'Son Dakika Haber',
    description: 'Hızlı haber metni üretin',
    content: 'Bu olayı son dakika haber formatında yazın: [OLAY]',
    premium_only: true,
  },
  {
    id: '20',
    category: 'Gazeteciler',
    title: 'Röportaj Soruları',
    description: 'Derinlemesine röportaj soruları',
    content: 'Bu kişi/konu için 15 derinlemesine röportaj sorusu hazırlayın: [KİŞİ/KONU]',
    premium_only: true,
  },
  {
    id: '21',
    category: 'Gazeteciler',
    title: 'Haber Analizi',
    description: 'Objektif haber analizi yazın',
    content: 'Bu haberi objektif şekilde analiz edin: [HABER]. Farklı bakış açılarını dahil edin.',
    premium_only: true,
  },
  {
    id: '22',
    category: 'Gazeteciler',
    title: 'Köşe Yazısı',
    description: 'Güncel konularda köşe yazısı',
    content: '[KONU] hakkında düşündürücü bir köşe yazısı yazın.',
    premium_only: true,
  },
  {
    id: '23',
    category: 'Gazeteciler',
    title: 'Basın Bülteni',
    description: 'Profesyonel basın bülteni',
    content: '[OLAY/DUYURU] için profesyonel basın bülteni hazırlayın.',
    premium_only: true,
  },
  {
    id: '24',
    category: 'Gazeteciler',
    title: 'Haber Başlığı',
    description: 'Çekici haber başlıkları üretin',
    content: 'Bu haber için 10 farklı çekici başlık önerisi: [HABER ÖZETİ]',
    premium_only: true,
  },
  {
    id: '25',
    category: 'Gazeteciler',
    title: 'Editöryal',
    description: 'Gazete editöryal yazısı',
    content: '[KONU] hakkında gazete editöryal yazısı yazın. Gazetenin görüşünü yansıtın.',
    premium_only: true,
  },
  {
    id: '26',
    category: 'Gazeteciler',
    title: 'Canlı Yayın Metni',
    description: 'Canlı yayın için sunum metni',
    content: '[OLAY] hakkında canlı yayın sunum metni hazırlayın.',
    premium_only: true,
  },
  {
    id: '27',
    category: 'Gazeteciler',
    title: 'Haber Özeti',
    description: 'Günlük haber özeti',
    content: 'Bugünün önemli haberlerinden özet çıkarın: [HABER LİSTESİ]',
    premium_only: true,
  },
  
  // Akademisyenler
  {
    id: '28',
    category: 'Akademisyenler',
    title: 'Makale Özeti',
    description: 'Akademik makale özeti çıkarın',
    content: 'Bu akademik metinden özet çıkarın ve ana noktaları listeleyin: [METİN]',
    premium_only: true,
  },
  {
    id: '29',
    category: 'Akademisyenler',
    title: 'Araştırma Hipotezi',
    description: 'Bilimsel hipotez geliştirin',
    content: 'Bu araştırma konusu için testedilebilir hipotezler geliştirin: [ARAŞTIRMA KONUSU]',
    premium_only: true,
  },
  {
    id: '30',
    category: 'Akademisyenler',
    title: 'Literatür Taraması',
    description: 'Akademik literatür taraması',
    content: '[KONU] hakkında literatür taraması yapın ve ana kaynakları özetleyin.',
    premium_only: true,
  },
  {
    id: '31',
    category: 'Akademisyenler',
    title: 'Araştırma Metodolojisi',
    description: 'Araştırma yöntemi önerisi',
    content: '[ARAŞTIRMA KONUSU] için uygun araştırma metodolojisi önerisi hazırlayın.',
    premium_only: true,
  },
  {
    id: '32',
    category: 'Akademisyenler',
    title: 'Tez Önerisi',
    description: 'Lisansüstü tez önerisi',
    content: '[KONU] alanında lisansüstü tez önerisi hazırlayın.',
    premium_only: true,
  },
  {
    id: '33',
    category: 'Akademisyenler',
    title: 'Konferans Özeti',
    description: 'Akademik konferans özeti',
    content: '[ARAŞTIRMA] için akademik konferans özeti (abstract) yazın.',
    premium_only: true,
  },
  {
    id: '34',
    category: 'Akademisyenler',
    title: 'Peer Review',
    description: 'Akademik makale değerlendirmesi',
    content: 'Bu akademik makaleyi peer review kriterlerine göre değerlendirin: [MAKALE]',
    premium_only: true,
  },
  {
    id: '35',
    category: 'Akademisyenler',
    title: 'Grant Başvurusu',
    description: 'Araştırma hibesi başvurusu',
    content: '[PROJE] için araştırma hibesi başvuru metni yazın.',
    premium_only: true,
  },
  {
    id: '36',
    category: 'Akademisyenler',
    title: 'Ders Planı',
    description: 'Üniversite ders planı',
    content: '[DERS] için 14 haftalık ders planı hazırlayın.',
    premium_only: true,
  },
  
  // Teknik
  {
    id: '37',
    category: 'Teknik',
    title: 'Kod İncelemesi',
    description: 'Kod kalitesi analizi yapın',
    content: 'Bu kodu inceleyin ve iyileştirme önerileri sunun: [KOD]',
    premium_only: false,
  },
  {
    id: '38',
    category: 'Teknik',
    title: 'API Dokümantasyonu',
    description: 'API endpoint dokümantasyonu',
    content: 'Bu API endpoint için detaylı dokümantasyon yazın: [ENDPOINT]',
    premium_only: false,
  },
  {
    id: '39',
    category: 'Teknik',
    title: 'Bug Raporu',
    description: 'Detaylı bug raporu oluşturun',
    content: 'Bu sorun için detaylı bug raporu hazırlayın: [SORUN AÇIKLAMASI]',
    premium_only: false,
  },
  {
    id: '40',
    category: 'Teknik',
    title: 'Sistem Mimarisi',
    description: 'Yazılım sistem mimarisi önerisi',
    content: '[PROJE] için ölçeklenebilir sistem mimarisi önerisi hazırlayın.',
    premium_only: true,
  },
  {
    id: '41',
    category: 'Teknik',
    title: 'Database Schema',
    description: 'Veritabanı şema tasarımı',
    content: '[UYGULAMA] için veritabanı şema tasarımı yapın.',
    premium_only: true,
  },
  {
    id: '42',
    category: 'Teknik',
    title: 'Test Senaryoları',
    description: 'Yazılım test senaryoları',
    content: '[ÖZELLİK] için kapsamlı test senaryoları yazın.',
    premium_only: false,
  },
  {
    id: '43',
    category: 'Teknik',
    title: 'Güvenlik Analizi',
    description: 'Sistem güvenlik değerlendirmesi',
    content: '[SİSTEM] için güvenlik açığı analizi yapın.',
    premium_only: true,
  },
  {
    id: '44',
    category: 'Teknik',
    title: 'Performans Optimizasyonu',
    description: 'Kod performans iyileştirme',
    content: 'Bu kodun performansını optimize edin: [KOD]',
    premium_only: true,
  },
  {
    id: '45',
    category: 'Teknik',
    title: 'DevOps Pipeline',
    description: 'CI/CD pipeline konfigürasyonu',
    content: '[PROJE] için CI/CD pipeline konfigürasyonu hazırlayın.',
    premium_only: true,
  },
  
  // Yaratıcı
  {
    id: '46',
    category: 'Yaratıcı',
    title: 'Hikaye Başlangıcı',
    description: 'Yaratıcı hikaye başlangıçları',
    content: 'Bu temayı kullanarak yaratıcı bir hikaye başlangıcı yazın: [TEMA]',
    premium_only: false,
  },
  {
    id: '47',
    category: 'Yaratıcı',
    title: 'Şiir Yazımı',
    description: 'Duygusal şiir yazın',
    content: '[TEMA/DUYGU] hakkında etkileyici bir şiir yazın.',
    premium_only: false,
  },
  {
    id: '48',
    category: 'Yaratıcı',
    title: 'Karakter Geliştirme',
    description: 'Detaylı karakter profili',
    content: '[TÜR] türünde hikaye için detaylı karakter profili oluşturun.',
    premium_only: false,
  },
  {
    id: '49',
    category: 'Yaratıcı',
    title: 'Senaryo Taslağı',
    description: 'Kısa film senaryosu',
    content: '[KONU] hakkında 5 dakikalık kısa film senaryosu yazın.',
    premium_only: true,
  },
  {
    id: '50',
    category: 'Yaratıcı',
    title: 'Yaratıcı Yazma Egzersizi',
    description: 'Yazma becerisi geliştirme',
    content: 'Bu kelimelerle yaratıcı bir metin yazın: [KELİME LİSTESİ]',
    premium_only: false,
  },
  {
    id: '51',
    category: 'Yaratıcı',
    title: 'Diyalog Yazımı',
    description: 'Gerçekçi karakter diyalogları',
    content: '[DURUM] için iki karakter arasında gerçekçi diyalog yazın.',
    premium_only: false,
  },
  {
    id: '52',
    category: 'Yaratıcı',
    title: 'Dünya Kurgusu',
    description: 'Fantastik dünya yaratımı',
    content: '[TÜR] türünde hikaye için detaylı dünya kurgusu yapın.',
    premium_only: true,
  },
  {
    id: '53',
    category: 'Yaratıcı',
    title: 'Metafor ve Benzetme',
    description: 'Yaratıcı metaforlar üretin',
    content: '[KAVRAM] için yaratıcı metafor ve benzetmeler üretin.',
    premium_only: false,
  },
  {
    id: '54',
    category: 'Yaratıcı',
    title: 'Hikaye Sonu',
    description: 'Etkileyici hikaye sonları',
    content: 'Bu hikaye için 3 farklı son alternatifi yazın: [HİKAYE ÖZETİ]',
    premium_only: true,
  },
];

export function TemplatesPanel() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Tümü');
  const [favorites, setFavorites] = useState<string[]>([]);
  const { templates, setTemplates } = useApp();
  const { user } = useAuth();
  const isPremium = user?.role === 'premium';

  const categories = ['Tümü', 'İş', 'Pazarlama', 'Gazeteciler', 'Akademisyenler', 'Teknik', 'Yaratıcı'];

  useEffect(() => {
    setTemplates(mockTemplates);
    // Load favorites from localStorage
    const savedFavorites = localStorage.getItem('template_favorites');
    if (savedFavorites) {
      setFavorites(JSON.parse(savedFavorites));
    }
  }, [setTemplates]);

  const filteredTemplates = templates.filter(template => {
    const matchesSearch = template.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         template.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'Tümü' || template.category === selectedCategory;
    const accessibleToPlan = !template.premium_only || isPremium;
    
    return matchesSearch && matchesCategory && accessibleToPlan;
  });

  const favoriteTemplates = templates.filter(template => 
    favorites.includes(template.id) && (!template.premium_only || isPremium)
  );

  const toggleFavorite = (templateId: string) => {
    const newFavorites = favorites.includes(templateId)
      ? favorites.filter(id => id !== templateId)
      : [...favorites, templateId];
    
    setFavorites(newFavorites);
    localStorage.setItem('template_favorites', JSON.stringify(newFavorites));
    
    toast({
      title: favorites.includes(templateId) ? "Favorilerden kaldırıldı" : "Favorilere eklendi",
    });
  };

  const useTemplate = (template: Template) => {
    if (template.premium_only && !isPremium) {
      toast({
        title: "Premium Gerekli",
        description: "Bu şablon Premium üyelik gerektirir.",
        variant: "destructive",
      });
      return;
    }
    
    // In a real app, this would open the chat and insert the template
    navigator.clipboard.writeText(template.content);
    toast({
      title: "Şablon kopyalandı",
      description: "Şablon panoya kopyalandı, sohbet alanına yapıştırabilirsiniz.",
    });
  };

  return (
    <div className="flex-1 p-6 bg-gradient-to-b from-gray-900 to-black h-full overflow-y-auto">
      <div className="max-w-6xl mx-auto space-y-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col sm:flex-row sm:items-center justify-between gap-4"
        >
          <div>
            <h1 className="text-3xl font-bold text-white">Hazır Şablonlar</h1>
            <p className="text-gray-400 mt-2">Hızlı başlangıç için önceden hazırlanmış promptlar</p>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Search size={18} className="absolute left-3 top-3 text-gray-400" />
              <Input
                placeholder="Şablon ara..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-64 bg-gray-800 border-gray-600 text-white placeholder-gray-400"
              />
            </div>
          </div>
        </motion.div>

        <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="space-y-6">
          <TabsList className="grid w-full grid-cols-7 bg-gray-800/50 border border-gray-700">
            {categories.map((category) => (
              <TabsTrigger
                key={category}
                value={category}
                className="data-[state=active]:bg-purple-600 data-[state=active]:text-white"
              >
                {category}
              </TabsTrigger>
            ))}
          </TabsList>

          <TabsContent value={selectedCategory} className="space-y-6">
            {selectedCategory === 'Favoriler' ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <AnimatePresence>
                  {favoriteTemplates.map((template) => (
                    <TemplateCard
                      key={template.id}
                      template={template}
                      isFavorite={true}
                      onToggleFavorite={toggleFavorite}
                      onUseTemplate={useTemplate}
                      isPremium={isPremium}
                    />
                  ))}
                </AnimatePresence>
              </div>
            ) : (
              <>
                {/* Category Stats */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="grid grid-cols-1 sm:grid-cols-3 gap-4"
                >
                  <Card className="bg-gray-800/50 border-gray-700">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-gray-400">Toplam Şablon</p>
                          <p className="text-2xl font-bold text-white">{filteredTemplates.length}</p>
                        </div>
                        <Filter className="text-purple-500" size={24} />
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-gray-800/50 border-gray-700">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-gray-400">Favorilerim</p>
                          <p className="text-2xl font-bold text-white">{favoriteTemplates.length}</p>
                        </div>
                        <Star className="text-yellow-500" size={24} />
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-gray-800/50 border-gray-700">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-gray-400">Premium Şablonlar</p>
                          <p className="text-2xl font-bold text-white">
                            {templates.filter(t => t.premium_only).length}
                          </p>
                        </div>
                        <Crown className="text-orange-500" size={24} />
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>

                {/* Templates Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <AnimatePresence>
                    {filteredTemplates.map((template, index) => (
                      <motion.div
                        key={template.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.05 }}
                      >
                        <TemplateCard
                          template={template}
                          isFavorite={favorites.includes(template.id)}
                          onToggleFavorite={toggleFavorite}
                          onUseTemplate={useTemplate}
                          isPremium={isPremium}
                        />
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>

                {filteredTemplates.length === 0 && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="text-center py-12"
                  >
                    <div className="text-gray-400">
                      <Search size={48} className="mx-auto mb-4 opacity-50" />
                      <p className="text-lg">Şablon bulunamadı</p>
                      <p className="text-sm">Arama terimini değiştirmeyi deneyin</p>
                    </div>
                  </motion.div>
                )}
              </>
            )}
          </TabsContent>
        </Tabs>

        {!isPremium && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Card className="bg-gradient-to-r from-purple-900/50 to-indigo-900/50 border-purple-500/30">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-semibold text-white flex items-center">
                      <Crown size={20} className="mr-2 text-yellow-500" />
                      Premium Şablonlar
                    </h3>
                    <p className="text-gray-300">
                      Gazeteciler, Akademisyenler ve daha fazla kategoriye erişin
                    </p>
                  </div>
                  <Button className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-400 hover:to-orange-400 text-black font-semibold">
                    Premium'a Geç
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>
    </div>
  );
}

interface TemplateCardProps {
  template: Template;
  isFavorite: boolean;
  onToggleFavorite: (id: string) => void;
  onUseTemplate: (template: Template) => void;
  isPremium: boolean;
}

function TemplateCard({ template, isFavorite, onToggleFavorite, onUseTemplate, isPremium }: TemplateCardProps) {
  return (
    <Card className="bg-gray-800/50 border-gray-700 hover:border-purple-500/50 transition-all duration-200 group">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-white text-lg group-hover:text-purple-300 transition-colors">
              {template.title}
              {template.premium_only && (
                <Crown size={16} className="inline ml-2 text-yellow-500" />
              )}
            </CardTitle>
            <Badge variant="secondary" className="mt-2 text-xs bg-purple-600/30 text-purple-300">
              {template.category}
            </Badge>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onToggleFavorite(template.id)}
            className="w-8 h-8 text-gray-400 hover:text-red-400 transition-colors"
          >
            <Heart size={16} fill={isFavorite ? 'currentColor' : 'none'} />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <CardDescription className="text-gray-400 mb-4">
          {template.description}
        </CardDescription>
        <div className="flex items-center justify-between">
          <Button
            onClick={() => onUseTemplate(template)}
            disabled={template.premium_only && !isPremium}
            className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Play size={16} className="mr-2" />
            Kullan
          </Button>
          {template.premium_only && !isPremium && (
            <Badge variant="outline" className="text-yellow-500 border-yellow-500/50">
              Premium
            </Badge>
          )}
        </div>
      </CardContent>
    </Card>
  );
}