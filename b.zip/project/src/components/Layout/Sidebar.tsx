import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  MessageCircle, 
  Settings, 
  FileText, 
  CreditCard, 
  ChevronLeft, 
  ChevronRight,
  Plus,
  Crown,
  User,
  LogOut,
  Folder,
  PenTool,
  ImageIcon,
  BookOpen,
  Search
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';
import { useApp } from '@/contexts/AppContext';
import { cn } from '@/lib/utils';
import { Input } from '@/components/ui/input';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export function Sidebar({ activeTab, setActiveTab }: SidebarProps) {
  const [isExpanded, setIsExpanded] = useState(true);
  const [editingConversation, setEditingConversation] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const { user, logout } = useAuth();
  const { conversations, currentConversation, createNewConversation, selectConversation, updateConversationTitle } = useApp();

  const menuItems = [
    { id: 'chat', icon: MessageCircle, label: 'Sohbet', badge: conversations.length },
    { id: 'templates', icon: FileText, label: 'Şablonlar' },
    { id: 'personal-assistant', icon: User, label: 'Kişisel Asistan' },
    { id: 'article-generator', icon: PenTool, label: 'Makale Oluşturucu' },
    { id: 'image-generator', icon: ImageIcon, label: 'Görsel Oluşturucu' },
    { id: 'research-assistant', icon: Search, label: 'Araştırma Asistanı' },
    { id: 'prompt-library', icon: BookOpen, label: 'Prompt Kütüphanesi' },
    { id: 'task-planner', icon: FileText, label: 'İş Takibi ve Plan Oluşturucu' },
    { id: 'settings', icon: Settings, label: 'Ayarlar' },
    { id: 'payments', icon: CreditCard, label: 'Planlar' },
  ];

  const isPremium = user?.role === 'premium';

  const handleEditStart = (conv: any, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingConversation(conv.id);
    setEditTitle(conv.title);
  };

  const handleEditSave = (convId: string) => {
    if (editTitle.trim()) {
      updateConversationTitle(convId, editTitle.trim());
    }
    setEditingConversation(null);
    setEditTitle('');
  };

  const handleEditCancel = () => {
    setEditingConversation(null);
    setEditTitle('');
  };
  return (
    <motion.div
      initial={false}
      animate={{ width: isExpanded ? 280 : 70 }}
      className="h-full bg-gradient-to-b from-purple-900/90 to-indigo-900/90 backdrop-blur-xl border-r border-purple-500/20 relative flex flex-col"
    >
      {/* Toggle Button */}
      <Button
        variant="ghost"
        size="icon"
        onClick={() => setIsExpanded(!isExpanded)}
        className="absolute -right-3 top-6 w-6 h-6 rounded-full bg-purple-600 hover:bg-purple-500 border border-purple-400/30 z-10"
      >
        {isExpanded ? <ChevronLeft size={14} /> : <ChevronRight size={14} />}
      </Button>

      <div className="flex-1 flex flex-col p-4 space-y-6">
        {/* Header */}
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center">
            <MessageCircle size={16} className="text-white" />
          </div>
          <AnimatePresence>
            {isExpanded && (
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="flex-1"
              >
                <h1 className="text-lg font-bold text-white">AI Portal</h1>
                {isPremium && (
                  <Badge variant="secondary" className="text-xs bg-gradient-to-r from-yellow-500 to-orange-500 text-white border-0">
                    <Crown size={10} className="mr-1" />
                    Premium
                  </Badge>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* New Chat Button */}
        <Button
          onClick={createNewConversation}
          className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 border border-purple-400/30"
        >
          <Plus size={16} />
          <AnimatePresence>
            {isExpanded && (
              <motion.span
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                className="ml-2"
              >
                Yeni Sohbet
              </motion.span>
            )}
          </AnimatePresence>
        </Button>

        {/* Navigation */}
        <nav className="space-y-2">
          {menuItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <Button
                key={item.id}
                variant="ghost"
                onClick={() => setActiveTab(item.id)}
                className={cn(
                  "w-full justify-start transition-all duration-200",
                  isActive 
                    ? "bg-purple-500/30 text-purple-100 border border-purple-400/30" 
                    : "text-purple-200 hover:bg-purple-500/20 hover:text-purple-100"
                )}
              >
                <item.icon size={18} />
                <AnimatePresence>
                  {isExpanded && (
                    <motion.div
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -10 }}
                      className="ml-3 flex-1 flex items-center justify-between"
                    >
                      <span>{item.label}</span>
                      {item.badge && (
                        <Badge variant="secondary" className="text-xs bg-purple-600/50">
                          {item.badge}
                        </Badge>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </Button>
            );
          })}
        </nav>

        {/* Conversations List */}
        <AnimatePresence>
          {isExpanded && activeTab === 'chat' && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="space-y-2 overflow-hidden"
            >
              <div className="flex items-center space-x-2 text-sm text-purple-300 px-2">
                <Folder size={14} />
                <span>Son Sohbetler</span>
              </div>
              <div className="max-h-60 overflow-y-auto space-y-1">
                {conversations.slice(0, isPremium ? conversations.length : 5).map((conv) => (
                  <div
                    key={conv.id}
                    className={cn(
                      "w-full rounded-md transition-colors",
                      currentConversation?.id === conv.id
                        ? "bg-purple-500/30"
                        : "hover:bg-purple-500/20"
                    )}
                  >
                    {editingConversation === conv.id ? (
                      <Input
                        value={editTitle}
                        onChange={(e) => setEditTitle(e.target.value)}
                        onBlur={() => handleEditSave(conv.id)}
                        onKeyPress={(e) => {
                          if (e.key === 'Enter') {
                            handleEditSave(conv.id);
                          } else if (e.key === 'Escape') {
                            handleEditCancel();
                          }
                        }}
                        className="text-xs h-8 bg-gray-800 border-gray-600 text-white"
                        autoFocus
                      />
                    ) : (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => selectConversation(conv)}
                        onDoubleClick={(e) => handleEditStart(conv, e)}
                        className="w-full justify-start text-xs p-2 h-auto text-purple-200 hover:text-purple-100"
                      >
                        <span className="truncate">{conv.title}</span>
                      </Button>
                    )}
                  </div>
                ))}
              </div>
              {!isPremium && conversations.length > 5 && (
                <div className="text-xs text-purple-400 px-2">
                  +{conversations.length - 5} sohbet daha (Premium gerekli)
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* User Section */}
      <div className="p-4 border-t border-purple-500/20">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center">
            <User size={16} className="text-white" />
          </div>
          <AnimatePresence>
            {isExpanded && (
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="flex-1"
              >
                <div className="text-sm text-white truncate">{user?.email}</div>
                <div className="text-xs text-purple-300">{isPremium ? 'Premium' : 'Free'}</div>
              </motion.div>
            )}
          </AnimatePresence>
          <Button
            variant="ghost"
            size="icon"
            onClick={logout}
            className="w-8 h-8 text-purple-300 hover:text-white hover:bg-purple-500/20"
          >
            <LogOut size={16} />
          </Button>
        </div>
      </div>
    </motion.div>
  );
}