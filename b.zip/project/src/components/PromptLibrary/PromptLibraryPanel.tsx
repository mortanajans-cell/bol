import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  BookOpen, 
  Search, 
  Plus, 
  Edit3, 
  Copy, 
  Star, 
  Filter,
  Tag,
  Zap,
  Code,
  Briefcase,
  GraduationCap,
  Palette,
  BarChart3,
  User,
  Globe,
  MessageSquare,
  Users,
  Save,
  Trash2,
  Eye,
  Settings,
  Target,
  Lightbulb,
  Award,
  TrendingUp,
  FileText,
  Send,
  Bot,
  Wand2,
  CheckCircle,
  AlertCircle,
  Sparkles
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useApp } from '@/contexts/AppContext';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

interface PromptTemplate {
  id: string;
  title: string;
  description: string;
  category: string;
  content: string;
  tags: string[];
  difficulty: number;
  rating: number;
  usage: number;
  isFavorite: boolean;
  isCustom: boolean;
  createdAt: string;
}

const promptCategories = [
  { 
    id: 'content', 
    name: 'İçerik Üretimi', 
    icon: FileText, 
    color: 'from-blue-500 to-cyan-500',
    description: 'Blog, makale, sosyal medya içerikleri'
  },
  { 
    id: 'development', 
    name: 'Yazılım Geliştirme', 
    icon: Code, 
    color: 'from-green-500 to-emerald-500',
    description: 'Kod review, debugging, dokümantasyon'
  },
  { 
    id: 'business', 
    name: 'İş Geliştirme', 
    icon: Briefcase, 
    color: 'from-purple-500 to-violet-500',
    description: 'Strateji, analiz, rapor hazırlama'
  },
  { 
    id: 'education', 
    name: 'Eğitim', 
    icon: GraduationCap, 
    color: 'from-orange-500 to-red-500',
    description: 'Ders planı, quiz, açıklama'
  },
  { 
    id: 'creative', 
    name: 'Yaratıcılık', 
    icon: Palette, 
    color: 'from-pink-500 to-rose-500',
    description: 'Hikaye, şiir, senaryo yazımı'
  },
  { 
    id: 'analysis', 
    name: 'Analiz', 
    icon: BarChart3, 
    color: 'from-indigo-500 to-blue-500',
    description: 'Veri, pazar, rekabet analizi'
  },
  { 
    id: 'personal', 
    name: 'Kişisel', 
    icon: User, 
    color: 'from-teal-500 to-cyan-500',
    description: 'Günlük, planlama, motivasyon'
  },
  { 
    id: 'translation', 
    name: 'Çeviri ve Dil', 
    icon: Globe, 
    color: 'from-yellow-500 to-orange-500',
    description: 'Çeviri, dil öğrenimi, gramer'
  },
  { 
    id: 'marketing', 
    name: 'Pazarlama', 
    icon: TrendingUp, 
    color: 'from-red-500 to-pink-500',
    description: 'Reklam, kampanya, sosyal medya'
  },
  { 
    id: 'customer', 
    name: 'Müşteri Hizmetleri', 
    icon: MessageSquare, 
    color: 'from-violet-500 to-purple-500',
    description: 'Destek, iletişim, problem çözme'
  }
];

const mockPrompts: PromptTemplate[] = [
  {
    id: '1',
    title: 'Blog Yazısı Oluşturucu',
    description: 'SEO uyumlu blog yazıları için kapsamlı prompt',
    category: 'content',
    content: `Sen [uzmanlık alanı] konusunda uzman bir content writer'sın. 
Konu: [konu]
Hedef kitle: [hedef kitle]
Ton: [profesyonel/samimi/eğitici]
Uzunluk: [kelime sayısı]

Yazının içermesi gerekenler:
- Dikkat çekici başlık
- Giriş paragrafı
- Ana noktalar (3-5 adet)
- Pratik örnekler
- Call-to-action
- SEO anahtar kelimeler: [kelimeler]`,
    tags: ['blog', 'seo', 'içerik', 'yazım'],
    difficulty: 6,
    rating: 4.8,
    usage: 1250,
    isFavorite: false,
    isCustom: false,
    createdAt: '2024-01-15'
  },
  {
    id: '2',
    title: 'Kod İnceleme Asistanı',
    description: 'Kod kalitesi ve optimizasyon için detaylı inceleme',
    category: 'development',
    content: `Sen senior [programlama dili] developer'ısın. Aşağıdaki kodu incele:

[KOD]

İnceleme kriterleri:
1. Kod kalitesi ve okunabilirlik
2. Performance optimizasyonları
3. Güvenlik açıkları
4. Best practices uygunluğu
5. Hata yönetimi

Her kategori için 1-10 puan ver ve iyileştirme önerileri sun.`,
    tags: ['kod', 'review', 'optimizasyon', 'güvenlik'],
    difficulty: 8,
    rating: 4.9,
    usage: 890,
    isFavorite: true,
    isCustom: false,
    createdAt: '2024-01-10'
  },
  {
    id: '3',
    title: 'İş Stratejisi Danışmanı',
    description: 'Kapsamlı iş stratejisi ve analiz için prompt',
    category: 'business',
    content: `Sen deneyimli bir business consultant'sın. 
Şirket: [şirket tipi]
Sektör: [sektör]
Problem: [ana problem]

Analiz et ve şunları sun:
1. Durum analizi (SWOT)
2. 3 alternatif çözüm
3. Her çözüm için risk/fayda analizi
4. Önerilen aksiyon planı
5. KPI'lar ve ölçüm kriterleri`,
    tags: ['strateji', 'analiz', 'swot', 'danışmanlık'],
    difficulty: 9,
    rating: 4.7,
    usage: 650,
    isFavorite: false,
    isCustom: false,
    createdAt: '2024-01-08'
  },
  {
    id: '4',
    title: 'Eğitim İçeriği Oluşturucu',
    description: 'Ders planı ve eğitim materyali hazırlama',
    category: 'education',
    content: `Sen deneyimli bir eğitmensin. [konu] hakkında eğitim içeriği hazırla.

Hedef grup: [yaş/seviye]
Süre: [ders süresi]
Öğrenme hedefleri: [hedefler]

İçerik yapısı:
1. Giriş ve motivasyon
2. Temel kavramlar
3. Pratik örnekler
4. Aktiviteler
5. Değerlendirme soruları
6. Ek kaynaklar`,
    tags: ['eğitim', 'ders', 'öğretim', 'materyal'],
    difficulty: 7,
    rating: 4.6,
    usage: 420,
    isFavorite: true,
    isCustom: false,
    createdAt: '2024-01-05'
  },
  {
    id: '5',
    title: 'Yaratıcı Hikaye Yazarı',
    description: 'Özgün hikaye ve karakter geliştirme',
    category: 'creative',
    content: `Sen yaratıcı bir hikaye yazarısın. Aşağıdaki kriterlere göre hikaye yaz:

Tür: [bilim kurgu/fantastik/gerilim/romantik]
Uzunluk: [kısa hikaye/novella/roman]
Ana karakter: [karakter özellikleri]
Setting: [zaman ve mekan]
Tema: [ana tema]

Hikaye yapısı:
- Çekici açılış
- Karakter gelişimi
- Artan gerilim
- Doruk noktası
- Tatmin edici sonuç`,
    tags: ['hikaye', 'yaratıcı', 'karakter', 'kurgu'],
    difficulty: 8,
    rating: 4.5,
    usage: 780,
    isFavorite: false,
    isCustom: false,
    createdAt: '2024-01-03'
  },
  {
    id: '6',
    title: 'Veri Analizi Uzmanı',
    description: 'Veri analizi ve görselleştirme rehberi',
    category: 'analysis',
    content: `Sen veri analizi uzmanısın. Aşağıdaki veri setini analiz et:

[VERİ SETİ/AÇIKLAMA]

Analiz adımları:
1. Veri temizleme ve hazırlama
2. Keşifsel veri analizi (EDA)
3. İstatistiksel analiz
4. Görselleştirme önerileri
5. Ana bulgular ve insights
6. Aksiyon önerileri

Sonuçları iş dünyasından örneklerle açıkla.`,
    tags: ['veri', 'analiz', 'istatistik', 'görselleştirme'],
    difficulty: 9,
    rating: 4.8,
    usage: 340,
    isFavorite: true,
    isCustom: false,
    createdAt: '2024-01-01'
  }
];

export function PromptLibraryPanel() {
  const [prompts, setPrompts] = useState<PromptTemplate[]>(mockPrompts);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedPrompt, setSelectedPrompt] = useState<PromptTemplate | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [newPrompt, setNewPrompt] = useState({
    title: '',
    description: '',
    category: 'content',
    content: '',
    tags: ''
  });
  const [activeTab, setActiveTab] = useState('browse');
  const [messages, setMessages] = useState<Array<{id: string, role: 'user' | 'assistant', content: string, timestamp: string}>>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const { generateAIResponse, settings } = useApp();
  const { user } = useAuth();
  const isPremium = user?.role === 'premium';

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const filteredPrompts = prompts.filter(prompt => {
    const matchesSearch = prompt.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         prompt.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         prompt.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = selectedCategory === 'all' || prompt.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const favoritePrompts = prompts.filter(prompt => prompt.isFavorite);

  const toggleFavorite = (promptId: string) => {
    setPrompts(prev => 
      prev.map(prompt => 
        prompt.id === promptId ? { ...prompt, isFavorite: !prompt.isFavorite } : prompt
      )
    );
    toast({
      title: "Favori durumu güncellendi",
    });
  };

  const copyPrompt = (content: string) => {
    navigator.clipboard.writeText(content);
    toast({
      title: "Prompt kopyalandı!",
      description: "Prompt panoya kopyalandı."
    });
  };

  const usePrompt = (prompt: PromptTemplate) => {
    setPrompts(prev => 
      prev.map(p => 
        p.id === prompt.id ? { ...p, usage: p.usage + 1 } : p
      )
    );
    copyPrompt(prompt.content);
    toast({
      title: "Prompt kullanıldı!",
      description: "Prompt kopyalandı ve kullanım sayısı güncellendi."
    });
  };

  const createPrompt = () => {
    if (!newPrompt.title || !newPrompt.content) {
      toast({
        title: "Eksik bilgiler",
        description: "Başlık ve içerik alanları zorunludur.",
        variant: "destructive"
      });
      return;
    }

    const prompt: PromptTemplate = {
      id: `custom_${Date.now()}`,
      title: newPrompt.title,
      description: newPrompt.description,
      category: newPrompt.category,
      content: newPrompt.content,
      tags: newPrompt.tags.split(',').map(tag => tag.trim()).filter(tag => tag),
      difficulty: 5,
      rating: 0,
      usage: 0,
      isFavorite: false,
      isCustom: true,
      createdAt: new Date().toISOString().split('T')[0]
    };

    setPrompts(prev => [prompt, ...prev]);
    setNewPrompt({ title: '', description: '', category: 'content', content: '', tags: '' });
    setIsCreating(false);
    
    toast({
      title: "Prompt oluşturuldu!",
      description: "Yeni prompt kütüphanenize eklendi."
    });
  };

  const sendMessage = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setIsLoading(true);

    const userMsgObj = {
      id: `user_${Date.now()}`,
      role: 'user' as const,
      content: userMessage,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMsgObj]);

    try {
      const promptLibraryPrompt = `Sen bir Prompt Kütüphanesi yöneticisisin. Kullanıcıların AI promptlarını optimize etmelerine, düzenlemelerine ve geliştirmelerine yardımcı oluyorsun.

Kullanıcı Mesajı: ${userMessage}

Lütfen:
1. Prompt analizi yap ve iyileştirme önerileri sun
2. Daha etkili prompt yazımı için rehberlik et
3. Kategori ve etiket önerileri ver
4. Prompt yapısı, netlik ve spesifik talimatlar konusunda tavsiyelerde bulun
5. Farklı AI modelleri için optimize et
6. Örneklerle somutlaştır

Yanıtını Türkçe ver ve prompt uzmanı rolünde kal.`;

      const aiResponse = await generateAIResponse(promptLibraryPrompt, settings);
      
      const aiMsgObj = {
        id: `ai_${Date.now()}`,
        role: 'assistant' as const,
        content: aiResponse,
        timestamp: new Date().toISOString()
      };

      setMessages(prev => [...prev, aiMsgObj]);

    } catch (error) {
      console.error('Prompt Library Error:', error);
      setMessages(prev => [...prev, {
        id: `error_${Date.now()}`,
        role: 'assistant' as const,
        content: 'Üzgünüm, bir hata oluştu. Lütfen tekrar deneyin.',
        timestamp: new Date().toISOString()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="flex-1 bg-gradient-to-br from-slate-950 via-purple-950 to-indigo-950 h-full overflow-hidden">
      <div className="flex h-full">
        {/* Left Panel - Categories and Filters */}
        <div className="w-80 bg-gradient-to-b from-purple-900/95 via-indigo-900/90 to-purple-950/95 backdrop-blur-xl border-r border-purple-400/30 p-6 overflow-y-auto shadow-2xl shadow-purple-900/50">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            {/* Header */}
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-gradient-to-r from-purple-500 via-violet-500 to-indigo-500 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-purple-500/40">
                <BookOpen size={24} className="text-white" />
              </div>
              <h1 className="text-2xl font-black bg-gradient-to-r from-white via-purple-100 to-violet-100 bg-clip-text text-transparent">Prompt Kütüphanesi</h1>
              <p className="text-purple-300 text-sm font-bold">AI promptlarınızı organize edin</p>
            </div>

            {/* Search */}
            <div className="relative">
              <Search size={18} className="absolute left-3 top-3 text-purple-400" />
              <Input
                placeholder="Prompt ara..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-purple-950/80 border-purple-600/60 text-purple-50 placeholder-purple-300/70 focus:border-purple-400 focus:ring-purple-400/30 font-semibold"
              />
            </div>

            {/* Categories */}
            <Card className="bg-gradient-to-br from-purple-900/90 via-indigo-900/80 to-purple-950/90 border-purple-400/40 backdrop-blur-md shadow-2xl shadow-purple-900/60">
              <CardHeader>
                <CardTitle className="text-white text-xl flex items-center font-black">
                  <Filter size={18} className="mr-2" />
                  Kategoriler
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button
                  variant={selectedCategory === 'all' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSelectedCategory('all')}
                  className={cn(
                    "w-full justify-start font-bold",
                    selectedCategory === 'all' 
                      ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg shadow-purple-500/40" 
                      : "bg-purple-950/80 border-purple-600/50 text-purple-200 hover:bg-purple-800/60 hover:border-purple-500/70"
                  )}
                >
                  <Target size={16} className="mr-2" />
                  Tümü ({prompts.length})
                </Button>
                
                {promptCategories.map((category) => {
                  const count = prompts.filter(p => p.category === category.id).length;
                  return (
                    <Button
                      key={category.id}
                      variant={selectedCategory === category.id ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setSelectedCategory(category.id)}
                      className={cn(
                        "w-full justify-start text-xs font-bold",
                        selectedCategory === category.id 
                          ? `bg-gradient-to-r ${category.color} text-white shadow-lg shadow-purple-500/40` 
                          : "bg-purple-950/80 border-purple-600/50 text-purple-200 hover:bg-purple-800/60 hover:border-purple-500/70"
                      )}
                    >
                      <category.icon size={14} className="mr-2" />
                      <div className="flex-1 text-left">
                        <div className="font-black">{category.name}</div>
                        <div className="text-xs opacity-80">({count})</div>
                      </div>
                    </Button>
                  );
                })}
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card className="bg-gradient-to-br from-emerald-900/90 via-green-900/80 to-teal-900/90 border-emerald-400/50 backdrop-blur-md shadow-2xl shadow-emerald-900/60">
              <CardHeader>
                <CardTitle className="text-white text-lg flex items-center font-black">
                  <Award size={18} className="mr-2" />
                  İstatistikler
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-emerald-950/80 p-3 rounded-lg border border-emerald-400/30">
                    <div className="text-white font-black text-lg">{prompts.length}</div>
                    <div className="text-emerald-100 text-xs font-bold">Toplam Prompt</div>
                  </div>
                  <div className="bg-emerald-950/80 p-3 rounded-lg border border-emerald-400/30">
                    <div className="text-white font-black text-lg">{favoritePrompts.length}</div>
                    <div className="text-emerald-100 text-xs font-bold">Favoriler</div>
                  </div>
                  <div className="bg-emerald-950/80 p-3 rounded-lg border border-emerald-400/30">
                    <div className="text-white font-black text-lg">{prompts.filter(p => p.isCustom).length}</div>
                    <div className="text-emerald-100 text-xs font-bold">Özel Promptlar</div>
                  </div>
                  <div className="bg-emerald-950/80 p-3 rounded-lg border border-emerald-400/30">
                    <div className="text-white font-black text-lg">{prompts.reduce((sum, p) => sum + p.usage, 0)}</div>
                    <div className="text-emerald-100 text-xs font-bold">Toplam Kullanım</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Right Panel - Main Content */}
        <div className="flex-1 flex flex-col">
          {/* Header */}
          <div className="p-4 border-b border-purple-500/30 bg-gradient-to-r from-purple-900/80 via-indigo-900/70 to-purple-900/80 backdrop-blur-md shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-black text-white">Prompt Kütüphanesi</h2>
                <p className="text-sm text-purple-100 font-bold">
                  AI promptlarınızı optimize edin ve yönetin
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <Button
                  variant={activeTab === 'browse' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setActiveTab('browse')}
                  className={cn(
                    "font-bold",
                    activeTab === 'browse' 
                      ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white" 
                      : "border-purple-600/60 text-purple-200 hover:bg-purple-800/60"
                  )}
                >
                  <BookOpen size={16} className="mr-2" />
                  Gözat
                </Button>
                <Button
                  variant={activeTab === 'create' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setActiveTab('create')}
                  className={cn(
                    "font-bold",
                    activeTab === 'create' 
                      ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white" 
                      : "border-purple-600/60 text-purple-200 hover:bg-purple-800/60"
                  )}
                >
                  <Plus size={16} className="mr-2" />
                  Oluştur
                </Button>
                <Button
                  variant={activeTab === 'optimize' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setActiveTab('optimize')}
                  className={cn(
                    "font-bold",
                    activeTab === 'optimize' 
                      ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white" 
                      : "border-purple-600/60 text-purple-200 hover:bg-purple-800/60"
                  )}
                >
                  <Wand2 size={16} className="mr-2" />
                  Optimize Et
                </Button>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto">
            {activeTab === 'browse' && (
              <div className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredPrompts.map((prompt) => (
                    <motion.div
                      key={prompt.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="group"
                    >
                      <Card className="bg-gradient-to-br from-purple-900/60 to-indigo-900/60 border-purple-400/40 backdrop-blur-md shadow-xl shadow-purple-900/40 hover:shadow-purple-800/60 hover:border-purple-300/60 transition-all duration-300 h-full">
                        <CardHeader className="pb-3">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <CardTitle className="text-white text-lg group-hover:text-purple-200 transition-colors font-black">
                                {prompt.title}
                              </CardTitle>
                              <CardDescription className="text-purple-300 font-semibold">
                                {prompt.description}
                              </CardDescription>
                            </div>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => toggleFavorite(prompt.id)}
                              className="w-8 h-8 text-purple-400 hover:text-yellow-400 transition-colors"
                            >
                              <Star size={16} fill={prompt.isFavorite ? 'currentColor' : 'none'} />
                            </Button>
                          </div>
                          
                          <div className="flex items-center space-x-2 mt-2">
                            <Badge 
                              variant="secondary" 
                              className={cn(
                                "text-xs font-bold",
                                `bg-gradient-to-r ${promptCategories.find(c => c.id === prompt.category)?.color || 'from-purple-600 to-indigo-600'} text-white`
                              )}
                            >
                              {promptCategories.find(c => c.id === prompt.category)?.name}
                            </Badge>
                            {prompt.isCustom && (
                              <Badge variant="outline" className="text-xs border-yellow-500/50 text-yellow-400 font-bold">
                                Özel
                              </Badge>
                            )}
                          </div>
                        </CardHeader>
                        
                        <CardContent className="space-y-4">
                          <div className="flex flex-wrap gap-1">
                            {prompt.tags.slice(0, 3).map((tag, index) => (
                              <Badge key={index} variant="secondary" className="text-xs bg-purple-600/30 text-purple-200 font-semibold">
                                #{tag}
                              </Badge>
                            ))}
                            {prompt.tags.length > 3 && (
                              <Badge variant="secondary" className="text-xs bg-purple-600/30 text-purple-200 font-semibold">
                                +{prompt.tags.length - 3}
                              </Badge>
                            )}
                          </div>
                          
                          <div className="grid grid-cols-3 gap-2 text-xs">
                            <div className="text-center">
                              <div className="text-white font-black">{prompt.rating.toFixed(1)}</div>
                              <div className="text-purple-300 font-bold">Puan</div>
                            </div>
                            <div className="text-center">
                              <div className="text-white font-black">{prompt.usage}</div>
                              <div className="text-purple-300 font-bold">Kullanım</div>
                            </div>
                            <div className="text-center">
                              <div className="text-white font-black">{prompt.difficulty}/10</div>
                              <div className="text-purple-300 font-bold">Zorluk</div>
                            </div>
                          </div>
                          
                          <div className="flex items-center space-x-2">
                            <Button
                              onClick={() => usePrompt(prompt)}
                              className="flex-1 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 font-bold"
                            >
                              <Zap size={14} className="mr-2" />
                              Kullan
                            </Button>
                            <Button
                              onClick={() => copyPrompt(prompt.content)}
                              variant="outline"
                              size="icon"
                              className="border-purple-600/60 text-purple-200 hover:bg-purple-800/60 hover:border-purple-500/70"
                            >
                              <Copy size={14} />
                            </Button>
                            <Button
                              onClick={() => setSelectedPrompt(prompt)}
                              variant="outline"
                              size="icon"
                              className="border-purple-600/60 text-purple-200 hover:bg-purple-800/60 hover:border-purple-500/70"
                            >
                              <Eye size={14} />
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>

                {filteredPrompts.length === 0 && (
                  <div className="text-center py-12">
                    <div className="w-20 h-20 rounded-full bg-gradient-to-r from-purple-500 via-violet-500 to-indigo-500 flex items-center justify-center mx-auto mb-6 shadow-lg shadow-purple-500/40">
                      <Search size={32} className="text-white" />
                    </div>
                    <h3 className="text-2xl font-black bg-gradient-to-r from-white via-purple-100 to-violet-100 bg-clip-text text-transparent mb-4">
                      Prompt Bulunamadı
                    </h3>
                    <p className="text-purple-300 max-w-md mx-auto font-bold">
                      Arama kriterlerinizi değiştirin veya yeni bir prompt oluşturun.
                    </p>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'create' && (
              <div className="p-6 max-w-4xl mx-auto">
                <Card className="bg-gradient-to-br from-purple-900/60 to-indigo-900/60 border-purple-400/40 backdrop-blur-md shadow-xl shadow-purple-900/40">
                  <CardHeader>
                    <CardTitle className="text-white text-2xl flex items-center font-black">
                      <Plus size={24} className="mr-3" />
                      Yeni Prompt Oluştur
                    </CardTitle>
                    <CardDescription className="text-purple-300 font-bold">
                      Kendi özel promptunuzu oluşturun ve kütüphanenize ekleyin
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="text-white text-sm font-black mb-2 block">Prompt Başlığı</label>
                        <Input
                          value={newPrompt.title}
                          onChange={(e) => setNewPrompt({...newPrompt, title: e.target.value})}
                          placeholder="Örn: Blog Yazısı Oluşturucu"
                          className="bg-purple-950/80 border-purple-600/60 text-white placeholder-purple-300/70 focus:border-purple-400 focus:ring-purple-400/30 font-semibold"
                        />
                      </div>
                      <div>
                        <label className="text-white text-sm font-black mb-2 block">Kategori</label>
                        <Select value={newPrompt.category} onValueChange={(value) => setNewPrompt({...newPrompt, category: value})}>
                          <SelectTrigger className="bg-purple-950/80 border-purple-600/60 text-white hover:border-purple-400/80 font-semibold">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="bg-purple-950 border-purple-600/60">
                            {promptCategories.map((category) => (
                              <SelectItem key={category.id} value={category.id} className="text-white hover:bg-purple-900/70 font-semibold">
                                <div className="flex items-center space-x-2">
                                  <category.icon size={16} />
                                  <span className="font-bold">{category.name}</span>
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div>
                      <label className="text-white text-sm font-black mb-2 block">Açıklama</label>
                      <Input
                        value={newPrompt.description}
                        onChange={(e) => setNewPrompt({...newPrompt, description: e.target.value})}
                        placeholder="Promptun ne işe yaradığını kısaca açıklayın"
                        className="bg-purple-950/80 border-purple-600/60 text-white placeholder-purple-300/70 focus:border-purple-400 focus:ring-purple-400/30 font-semibold"
                      />
                    </div>

                    <div>
                      <label className="text-white text-sm font-black mb-2 block">Etiketler</label>
                      <Input
                        value={newPrompt.tags}
                        onChange={(e) => setNewPrompt({...newPrompt, tags: e.target.value})}
                        placeholder="blog, seo, içerik, yazım (virgülle ayırın)"
                        className="bg-purple-950/80 border-purple-600/60 text-white placeholder-purple-300/70 focus:border-purple-400 focus:ring-purple-400/30 font-semibold"
                      />
                    </div>

                    <div>
                      <label className="text-white text-sm font-black mb-2 block">Prompt İçeriği</label>
                      <Textarea
                        value={newPrompt.content}
                        onChange={(e) => setNewPrompt({...newPrompt, content: e.target.value})}
                        placeholder="Promptunuzu buraya yazın. [değişken] şeklinde parametreler kullanabilirsiniz."
                        className="min-h-[200px] bg-purple-950/80 border-purple-600/60 text-white placeholder-purple-300/70 focus:border-purple-400 focus:ring-purple-400/30 font-semibold"
                      />
                    </div>

                    <div className="flex items-center space-x-4">
                      <Button
                        onClick={createPrompt}
                        className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 font-black"
                      >
                        <Save size={16} className="mr-2" />
                        Prompt Oluştur
                      </Button>
                      <Button
                        onClick={() => setNewPrompt({ title: '', description: '', category: 'content', content: '', tags: '' })}
                        variant="outline"
                        className="border-purple-600/60 text-purple-200 hover:bg-purple-800/60 hover:border-purple-500/70 font-bold"
                      >
                        Temizle
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {activeTab === 'optimize' && (
              <div className="flex-1 flex flex-col">
                {/* Chat Messages */}
                <div className="flex-1 overflow-y-auto p-4 space-y-6">
                  {messages.length === 0 && (
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="text-center py-12"
                    >
                      <div className="w-20 h-20 rounded-full bg-gradient-to-r from-purple-500 via-violet-500 to-indigo-500 flex items-center justify-center mx-auto mb-6 shadow-lg shadow-purple-500/40">
                        <Wand2 size={32} className="text-white" />
                      </div>
                      <h3 className="text-2xl font-black bg-gradient-to-r from-white via-purple-100 to-violet-100 bg-clip-text text-transparent mb-4">
                        Prompt Optimizasyon Uzmanı
                      </h3>
                      <p className="text-purple-100 max-w-md mx-auto mb-6 font-bold">
                        Mevcut promptlarınızı analiz edip optimize etmenize yardımcı oluyorum!
                      </p>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl mx-auto">
                        <div className="p-4 bg-gradient-to-br from-purple-900/80 to-indigo-900/80 rounded-lg border border-purple-400/50 hover:border-purple-300/70 transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/50">
                          <CheckCircle className="text-green-500 mb-2" size={24} />
                          <h4 className="text-white font-black mb-1">Prompt Analizi</h4>
                          <p className="text-purple-100 text-sm font-semibold">Mevcut promptlarınızı inceleyin</p>
                        </div>
                        <div className="p-4 bg-gradient-to-br from-purple-900/80 to-indigo-900/80 rounded-lg border border-purple-400/50 hover:border-purple-300/70 transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/50">
                          <Sparkles className="text-yellow-500 mb-2" size={24} />
                          <h4 className="text-white font-black mb-1">Optimizasyon</h4>
                          <p className="text-purple-100 text-sm font-semibold">Daha etkili promptlar oluşturun</p>
                        </div>
                        <div className="p-4 bg-gradient-to-br from-purple-900/80 to-indigo-900/80 rounded-lg border border-purple-400/50 hover:border-purple-300/70 transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/50">
                          <Target className="text-blue-500 mb-2" size={24} />
                          <h4 className="text-white font-black mb-1">Kategori Önerileri</h4>
                          <p className="text-purple-100 text-sm font-semibold">Doğru kategori ve etiketler</p>
                        </div>
                        <div className="p-4 bg-gradient-to-br from-purple-900/80 to-indigo-900/80 rounded-lg border border-purple-400/50 hover:border-purple-300/70 transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/50">
                          <Award className="text-purple-500 mb-2" size={24} />
                          <h4 className="text-white font-black mb-1">Best Practices</h4>
                          <p className="text-purple-100 text-sm font-semibold">Uzman tavsiyeleri alın</p>
                        </div>
                      </div>
                    </motion.div>
                  )}

                  <AnimatePresence>
                    {messages.map((message) => (
                      <motion.div
                        key={message.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3 }}
                        className={cn(
                          "flex",
                          message.role === 'user' ? "justify-end" : "justify-start"
                        )}
                      >
                        <div
                          className={cn(
                            "max-w-3xl rounded-2xl p-4 shadow-lg flex items-start space-x-3",
                            message.role === 'user'
                              ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white ml-12 flex-row-reverse space-x-reverse"
                              : "bg-slate-800/80 backdrop-blur-sm text-slate-100 mr-12 border border-purple-500/20"
                          )}
                        >
                          <div className={cn(
                            "w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0",
                            message.role === 'user'
                              ? "bg-white/20"
                              : "bg-gradient-to-r from-purple-600 to-indigo-600"
                          )}>
                            {message.role === 'user' ? (
                              <User size={16} className="text-white" />
                            ) : (
                              <Bot size={16} className="text-white" />
                            )}
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <div className={cn(
                              "text-xs font-bold mb-1",
                              message.role === 'user' ? "text-purple-200" : "text-purple-300"
                            )}>
                              {message.role === 'user' ? 'Siz' : 'Prompt Uzmanı'}
                            </div>
                            <p className="whitespace-pre-wrap leading-relaxed text-sm font-semibold">{message.content}</p>
                            <div className={cn(
                              "text-xs opacity-60 mt-2",
                              message.role === 'user' ? "text-purple-200" : "text-purple-300"
                            )}>
                              {new Date(message.timestamp).toLocaleTimeString('tr-TR')}
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>

                  {/* Typing Indicator */}
                  <AnimatePresence>
                    {isLoading && (
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        className="flex justify-start"
                      >
                        <div className="max-w-3xl rounded-2xl p-4 bg-slate-800/80 backdrop-blur-sm border border-purple-500/20 mr-12 flex items-start space-x-3">
                          <div className="w-8 h-8 rounded-full bg-gradient-to-r from-purple-600 to-indigo-600 flex items-center justify-center flex-shrink-0">
                            <Bot size={16} className="text-white" />
                          </div>
                          
                          <div className="flex-1">
                            <div className="text-xs font-bold mb-1 text-purple-200">Prompt Uzmanı</div>
                            <div className="flex items-center space-x-2">
                              <div className="flex space-x-1">
                                <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce"></div>
                                <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                                <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                              </div>
                              <span className="text-purple-200 text-sm font-bold">Prompt analiz ediliyor...</span>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <div ref={messagesEndRef} />
                </div>

                {/* Input Area */}
                <div className="p-4 border-t border-purple-500/40 bg-purple-900/60 backdrop-blur-sm">
                  <div className="max-w-4xl mx-auto">
                    <div className="relative">
                      <Textarea
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyPress={handleKeyPress}
                        placeholder="Promptunuzu buraya yapıştırın veya prompt optimizasyonu hakkında soru sorun..."
                        className="min-h-[60px] pr-12 resize-none bg-purple-950/80 border-purple-500/60 focus:border-purple-400 text-white placeholder-purple-300 font-semibold"
                        disabled={isLoading}
                      />
                      <Button
                        onClick={sendMessage}
                        disabled={!input.trim() || isLoading}
                        size="icon"
                        className="absolute right-2 bottom-2 w-8 h-8 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500"
                      >
                        <Send size={16} />
                      </Button>
                    </div>
                    
                    <div className="flex justify-between items-center mt-2 text-xs text-purple-300 font-bold">
                      <span>🎯 Prompt optimizasyon uzmanı ile konuşuyorsunuz</span>
                      <span>✨ Daha etkili promptlar oluşturun</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Prompt Detail Modal */}
      <AnimatePresence>
        {selectedPrompt && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedPrompt(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-gradient-to-br from-purple-900/95 to-indigo-900/95 backdrop-blur-xl border border-purple-400/40 rounded-2xl p-6 max-w-4xl w-full max-h-[80vh] overflow-y-auto shadow-2xl shadow-purple-900/60"
            >
              <div className="flex items-start justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-black text-white mb-2">{selectedPrompt.title}</h2>
                  <p className="text-purple-300 font-bold">{selectedPrompt.description}</p>
                </div>
                <Button
                  onClick={() => setSelectedPrompt(null)}
                  variant="ghost"
                  size="icon"
                  className="text-purple-400 hover:text-white"
                >
                  ×
                </Button>
              </div>

              <div className="space-y-4">
                <div className="flex flex-wrap gap-2">
                  {selectedPrompt.tags.map((tag, index) => (
                    <Badge key={index} variant="secondary" className="bg-purple-600/30 text-purple-200 font-semibold">
                      #{tag}
                    </Badge>
                  ))}
                </div>

                <div className="bg-purple-950/80 p-4 rounded-lg border border-purple-600/30">
                  <h3 className="text-white font-black mb-3">Prompt İçeriği:</h3>
                  <pre className="text-purple-100 whitespace-pre-wrap font-mono text-sm leading-relaxed font-semibold">
                    {selectedPrompt.content}
                  </pre>
                </div>

                <div className="flex items-center space-x-4">
                  <Button
                    onClick={() => usePrompt(selectedPrompt)}
                    className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 font-black"
                  >
                    <Zap size={16} className="mr-2" />
                    Kullan
                  </Button>
                  <Button
                    onClick={() => copyPrompt(selectedPrompt.content)}
                    variant="outline"
                    className="border-purple-600/60 text-purple-200 hover:bg-purple-800/60 hover:border-purple-500/70 font-bold"
                  >
                    <Copy size={16} className="mr-2" />
                    Kopyala
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}