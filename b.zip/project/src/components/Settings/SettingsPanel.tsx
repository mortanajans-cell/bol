import React from 'react';
import { motion } from 'framer-motion';
import { Save, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { useApp } from '@/contexts/AppContext';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';

export function SettingsPanel() {
  const { settings, setSettings, language, setLanguage, autoSave, setAutoSave, notifications, setNotifications } = useApp();
  const { user } = useAuth();
  const isPremium = user?.role === 'premium';

  const conversationModes = [
    { id: 'creative', label: 'Yaratıcı', description: 'Kreativ ve özgün çıktılar' },
    { id: 'analytical', label: 'Analitik', description: 'Analizler ve raporlar' },
    { id: 'business', label: 'İş Odaklı', description: 'Profesyonel iş tonu' },
    { id: 'technical', label: 'Teknik', description: 'Kod ve teknik destek' },
  ];

  const responseStyles = [
    { value: 'balanced', label: 'Dengeli' },
    { value: 'detailed', label: 'Detaylı' },
    { value: 'summary', label: 'Özet' },
    { value: 'casual', label: 'Günlük' },
    { value: 'professional', label: 'Profesyonel' },
  ];

  const maxTokenOptions = [
    { value: 512, label: '512 token' },
    { value: 1024, label: '1024 token' },
    { value: 2048, label: '2048 token (Premium)', premium: true },
    { value: 4096, label: '4096 token (Premium)', premium: true },
  ];

  const handleSaveSettings = () => {
    // In a real app, this would save to Supabase
    localStorage.setItem('user_settings', JSON.stringify(settings));
    localStorage.setItem('app_preferences', JSON.stringify({ autoSave, notifications, language }));
    toast({ title: "Ayarlar kaydedildi", description: "Tüm değişiklikler başarıyla kaydedildi." });
  };

  const resetSettings = () => {
    const defaultSettings = {
      id: settings.id,
      user_id: settings.user_id,
      mode: 'creative' as const,
      temperature: 0.7,
      max_tokens: 1024,
      response_length: 'long' as const,
      response_style: 'balanced' as const,
    };
    setSettings(defaultSettings);
    setAutoSave(true);
    setNotifications(true);
    setLanguage('tr');
    toast({ title: "Ayarlar sıfırlandı", description: "Tüm ayarlar varsayılan değerlere döndürüldü." });
  };

  const handleModeChange = (value: string) => {
    setSettings({ ...settings, mode: value as any });
    toast({ 
      title: "Konuşma modu değiştirildi", 
      description: `Yeni mod: ${conversationModes.find(m => m.id === value)?.label}` 
    });
  };

  const handleTemperatureChange = (value: number[]) => {
    setSettings({ ...settings, temperature: value[0] });
    const creativityLevel = value[0] > 0.7 ? "Çok Yaratıcı" : value[0] > 0.4 ? "Dengeli" : "Tutarlı";
    toast({ 
      title: "Yaratıcılık seviyesi güncellendi", 
      description: `Yeni seviye: ${creativityLevel} (${value[0]})` 
    });
  };

  const handleMaxTokensChange = (value: string) => {
    const tokenValue = parseInt(value);
    if (tokenValue > 1024 && !isPremium) {
      toast({
        title: "Premium Gerekli",
        description: "Bu özellik Premium üyelik gerektirir.",
        variant: "destructive",
      });
      return;
    }
    setSettings({ ...settings, max_tokens: tokenValue });
    toast({ 
      title: "Maksimum yanıt uzunluğu güncellendi", 
      description: `Yeni limit: ${tokenValue} token` 
    });
  };
  return (
    <div className="flex-1 p-6 bg-gradient-to-br from-black via-gray-900 via-purple-950 to-indigo-950 h-full overflow-y-auto">
      <div className="max-w-4xl mx-auto space-y-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between"
        >
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-white to-gray-100 bg-clip-text text-transparent">Ayarlar</h1>
            <p className="text-gray-200 mt-2 text-lg">AI portal deneyiminizi kişiselleştirin</p>
          </div>
          <div className="flex items-center space-x-3">
            <Button
              onClick={resetSettings}
              variant="outline"
              className="border-gray-600 text-white hover:bg-gray-800 hover:border-gray-400 transition-all duration-300"
            >
              <RefreshCw size={16} className="mr-2" />
              Sıfırla
            </Button>
            <Button
              onClick={handleSaveSettings}
              className="bg-gradient-to-r from-gray-800 to-black hover:from-gray-700 hover:to-gray-900 shadow-xl shadow-black/50 transition-all duration-300"
            >
              <Save size={16} className="mr-2" />
              Kaydet
            </Button>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Conversation Mode */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Card className="h-[400px] bg-gradient-to-br from-purple-900/90 via-indigo-900/85 to-blue-900/80 border-purple-700/30 backdrop-blur-md shadow-2xl shadow-purple-900/50 hover:shadow-purple-800/70 hover:border-purple-600/50 transition-all duration-300">
              <CardHeader>
                <CardTitle className="text-white text-xl font-semibold">Konuşma Modu</CardTitle>
                <CardDescription className="text-gray-200">AI'nın yanıt verme stilini belirleyin</CardDescription>
              </CardHeader>
              <CardContent className="flex-1 overflow-y-auto">
                <RadioGroup
                  value={settings.mode}
                  onValueChange={handleModeChange}
                >
                  {conversationModes.map((mode) => (
                    <div key={mode.id} className="flex items-start space-x-3 p-3 rounded-xl hover:bg-purple-800/40 transition-all duration-300 border border-transparent hover:border-purple-600/40">
                      <RadioGroupItem value={mode.id} id={mode.id} className="mt-1 border-gray-300 text-white" />
                      <div className="flex-1">
                        <Label htmlFor={mode.id} className="text-white font-semibold cursor-pointer text-base">
                          {mode.label}
                        </Label>
                        <p className="text-xs text-gray-300 mt-1">{mode.description}</p>
                      </div>
                    </div>
                  ))}
                </RadioGroup>
              </CardContent>
            </Card>
          </motion.div>

          {/* Advanced Settings */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="h-[400px] bg-gradient-to-br from-indigo-900/90 via-purple-900/85 to-slate-900/80 border-indigo-700/30 backdrop-blur-md shadow-2xl shadow-indigo-900/50 hover:shadow-indigo-800/70 hover:border-indigo-600/50 transition-all duration-300">
              <CardHeader>
                <CardTitle className="text-white text-xl font-semibold">Gelişmiş Ayarlar</CardTitle>
                <CardDescription className="text-gray-200">Yaratıcılık ve yanıt uzunluğu ayarları</CardDescription>
              </CardHeader>
              <CardContent className="flex-1 overflow-y-auto space-y-4">
                {/* Temperature Slider */}
                <div>
                  <Label className="text-white text-sm font-medium">Yaratıcılık Seviyesi: {settings.temperature}</Label>
                  <div className="mt-2">
                    <Slider
                      value={[settings.temperature]}
                      onValueChange={handleTemperatureChange}
                      max={1}
                      min={0}
                      step={0.1}
                      className="w-full [&_[role=slider]]:bg-white [&_[role=slider]]:border-gray-300"
                    />
                    <div className="flex justify-between text-xs text-gray-300 mt-1">
                      <span>Tutarlı</span>
                      <span>Yaratıcı</span>
                    </div>
                  </div>
                </div>

                {/* Max Tokens */}
                <div>
                  <Label className="text-white text-sm font-medium">Maksimum Yanıt Uzunluğu</Label>
                  <Select
                    value={settings.max_tokens.toString()}
                    onValueChange={handleMaxTokensChange}
                  >
                    <SelectTrigger className="bg-purple-950/80 border-purple-700/50 text-white mt-2 hover:border-purple-600/70 transition-colors">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-purple-950 border-purple-700/60">
                      {maxTokenOptions.map((option) => (
                        <SelectItem
                          key={option.value}
                          value={option.value.toString()}
                          disabled={option.premium && !isPremium}
                          className="text-white hover:bg-purple-900/70"
                        >
                          {option.label}
                          {option.premium && !isPremium && " 🔒"}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {!isPremium && (
                    <p className="text-xs text-gray-300 mt-1">
                      Premium üyelik ile daha uzun yanıtlar alabilirsiniz
                    </p>
                  )}
                </div>

                {/* Response Length */}
                <div>
                  <Label className="text-white text-sm font-medium">Yanıt Uzunluğu</Label>
                  <RadioGroup
                    value={settings.response_length}
                    onValueChange={(value: any) => setSettings({ ...settings, response_length: value })}
                    className="mt-2"
                  >
                    <div className="flex items-center space-x-3 p-1 rounded-lg hover:bg-purple-900/50 transition-colors">
                      <RadioGroupItem value="short" id="short" className="border-gray-300 text-white" />
                      <Label htmlFor="short" className="text-white cursor-pointer text-sm">Kısa</Label>
                    </div>
                    <div className="flex items-center space-x-3 p-1 rounded-lg hover:bg-purple-900/50 transition-colors">
                      <RadioGroupItem value="long" id="long" className="border-gray-300 text-white" />
                      <Label htmlFor="long" className="text-white cursor-pointer text-sm">Uzun</Label>
                    </div>
                  </RadioGroup>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Response Style */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="h-[400px] bg-gradient-to-br from-purple-900/90 via-blue-900/85 to-indigo-900/80 border-purple-700/30 backdrop-blur-md shadow-2xl shadow-purple-900/50 hover:shadow-purple-800/70 hover:border-purple-600/50 transition-all duration-300">
              <CardHeader>
                <CardTitle className="text-white text-xl font-semibold">Yanıt Stili</CardTitle>
                <CardDescription className="text-gray-200">AI'nın kullanacağı dil ve ton</CardDescription>
              </CardHeader>
              <CardContent className="flex-1 overflow-y-auto space-y-4">
                <Select
                  value={settings.response_style}
                  onValueChange={(value: any) => setSettings({ ...settings, response_style: value })}
                >
                  <SelectTrigger className="bg-purple-950/80 border-purple-700/50 text-white hover:border-purple-600/70 transition-colors">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-purple-950 border-purple-700/60">
                    {responseStyles.map((style) => (
                      <SelectItem key={style.value} value={style.value} className="text-white hover:bg-purple-900/70">
                        {style.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <div className="p-2 bg-purple-950/70 rounded-xl border border-purple-700/50">
                  <p className="text-xs text-gray-200 leading-relaxed">
                    <strong className="text-white text-sm">Mevcut Ayarlar:</strong><br/>
                    Mod: {conversationModes.find(m => m.id === settings.mode)?.label}<br/>
                    Yaratıcılık: {settings.temperature}<br/>
                    Token Limiti: {settings.max_tokens}<br/>
                    Stil: {responseStyles.find(s => s.value === settings.response_style)?.label}
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Language and Preferences */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card className="h-[400px] bg-gradient-to-br from-slate-900/90 via-indigo-900/85 to-purple-900/80 border-slate-700/30 backdrop-blur-md shadow-2xl shadow-slate-900/50 hover:shadow-slate-800/70 hover:border-slate-600/50 transition-all duration-300">
              <CardHeader>
                <CardTitle className="text-white text-xl font-semibold">Genel Tercihler</CardTitle>
                <CardDescription className="text-gray-200">Dil ve görünüm ayarları</CardDescription>
              </CardHeader>
              <CardContent className="flex-1 overflow-y-auto space-y-3">
                <div className="flex items-center justify-between p-2 rounded-xl hover:bg-indigo-900/50 transition-colors">
                  <div>
                    <Label className="text-white text-sm font-medium">Dil</Label>
                    <p className="text-xs text-gray-300">Arayüz dili</p>
                  </div>
                  <Select value={language} onValueChange={(value: 'tr' | 'en') => setLanguage(value)}>
                    <SelectTrigger className="w-32 bg-indigo-950/80 border-indigo-700/50 text-white hover:border-indigo-600/70 transition-colors">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-indigo-950 border-indigo-700/60">
                      <SelectItem value="tr" className="text-white hover:bg-indigo-900/70">Türkçe</SelectItem>
                      <SelectItem value="en" className="text-white hover:bg-indigo-900/70">English</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center justify-between p-2 rounded-xl hover:bg-indigo-900/50 transition-colors">
                  <div>
                    <Label className="text-white text-sm font-medium">Otomatik Kaydet</Label>
                    <p className="text-xs text-gray-300">Sohbetleri otomatik kaydet</p>
                  </div>
                  <Switch 
                    checked={autoSave} 
                    onCheckedChange={(checked) => {
                      setAutoSave(checked);
                      toast({ 
                        title: checked ? "Otomatik kaydet açıldı" : "Otomatik kaydet kapatıldı",
                        description: checked ? "Sohbetler otomatik kaydedilecek" : "Manuel kaydetme gerekli"
                      });
                    }}
                    className="data-[state=checked]:bg-white"
                  />
                </div>

                <div className="flex items-center justify-between p-2 rounded-xl hover:bg-indigo-900/50 transition-colors">
                  <div>
                    <Label className="text-white text-sm font-medium">Bildirimler</Label>
                    <p className="text-xs text-gray-300">Sistem bildirimleri</p>
                  </div>
                  <Switch 
                    checked={notifications} 
                    onCheckedChange={(checked) => {
                      setNotifications(checked);
                      toast({ 
                        title: checked ? "Bildirimler açıldı" : "Bildirimler kapatıldı",
                        description: checked ? "Sistem bildirimleri alacaksınız" : "Bildirimler kapatıldı"
                      });
                    }}
                    className="data-[state=checked]:bg-white"
                  />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {!isPremium && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <Card className="bg-gradient-to-r from-purple-900/90 via-indigo-900/85 to-blue-900/80 border-purple-600/40 backdrop-blur-md shadow-2xl shadow-purple-900/60">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xl font-bold text-white">Premium'a Geçin</h3>
                    <p className="text-gray-200">Tüm gelişmiş ayarlara ve sınırsız özelliklere erişin</p>
                  </div>
                  <Button className="bg-gradient-to-r from-white to-gray-200 hover:from-gray-100 hover:to-white text-black font-bold shadow-xl shadow-white/20 hover:shadow-white/30 transition-all duration-300">
                    Premium'a Geç
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>
    </div>
  );
}