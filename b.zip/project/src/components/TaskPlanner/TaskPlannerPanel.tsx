import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Calendar, 
  Clock, 
  CheckSquare, 
  Target,
  Users,
  BarChart3,
  Brain,
  Shield,
  Plus,
  Play,
  Pause,
  RotateCcw,
  Settings,
  Filter,
  Download,
  Share2,
  Eye,
  Edit3,
  Trash2,
  Star,
  Award,
  Zap,
  TrendingUp,
  User,
  Bot,
  Send,
  Lightbulb,
  CheckCircle,
  AlertCircle,
  Timer,
  PieChart,
  Activity,
  Briefcase,
  FileText,
  Globe,
  Smartphone
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { useApp } from '@/contexts/AppContext';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

const plannerModules = [
  {
    id: 'smart-planner',
    title: 'Akıllı Proje Planlayıcı',
    icon: Calendar,
    color: 'from-blue-600 to-cyan-600',
    description: 'AI destekli proje planlaması ve zaman tahmini',
    features: [
      'AI destekli görev süre tahmini',
      'Gantt chart görselleştirme',
      'Otomatik kaynak dağılımı',
      'Critical path analizi',
      'Proje risk değerlendirmesi',
      'Milestone tracking'
    ],
    emoji: '📅',
    stats: { projects: 24, completion: 87, efficiency: 94 }
  },
  {
    id: 'time-management',
    title: 'Zaman Yönetimi Hub\'ı',
    icon: Clock,
    color: 'from-green-600 to-emerald-600',
    description: 'Pomodoro, time tracking ve verimlilik analizi',
    features: [
      'Gelişmiş Pomodoro timer',
      'Otomatik zaman takibi',
      'Verimlilik heat map\'i',
      'Focus müzik entegrasyonu',
      'Akıllı bildirim sistemi',
      'Günlük/haftalık analiz raporları'
    ],
    emoji: '⏱️',
    stats: { hours: 156, focus: 92, breaks: 48 }
  },
  {
    id: 'task-manager',
    title: 'Görev ve Süreç Yöneticisi',
    icon: CheckSquare,
    color: 'from-purple-600 to-violet-600',
    description: 'Kapsamlı görev takibi ve workflow otomasyonu',
    features: [
      'Kanban board görünümü',
      'Recurring task automation',
      'Akıllı etiketleme sistemi',
      'Görev performans analizi',
      'Görev bağımlılık haritası',
      'Mobile sync ve offline mod'
    ],
    emoji: '📋',
    stats: { tasks: 342, completed: 289, pending: 53 }
  },
  {
    id: 'performance-tracker',
    title: 'Hedef ve Performans Takibi',
    icon: Target,
    color: 'from-orange-600 to-red-600',
    description: 'OKR sistemi ve KPI dashboard\'u',
    features: [
      'OKR (Objectives & Key Results) sistemi',
      'KPI dashboard ve metriks',
      'Achievement badges sistemi',
      'Performance trend analizi',
      'Hedef tamamlanma tahmini',
      'Progress raporları (haftalık/aylık)'
    ],
    emoji: '🎯',
    stats: { goals: 12, achieved: 8, progress: 78 }
  }
];

const additionalModules = [
  {
    id: 'team-collaboration',
    title: 'Takım Kolaborasyon Merkezi',
    icon: Users,
    color: 'from-indigo-600 to-blue-600',
    description: 'Takım çalışması ve iletişim araçları',
    emoji: '🤝'
  },
  {
    id: 'analytics-dashboard',
    title: 'İş Analitik Dashboard\'u',
    icon: BarChart3,
    color: 'from-teal-600 to-cyan-600',
    description: 'Detaylı analiz ve raporlama',
    emoji: '📊'
  },
  {
    id: 'ai-assistant',
    title: 'AI İş Asistanı',
    icon: Brain,
    color: 'from-pink-600 to-rose-600',
    description: 'Akıllı iş önerileri ve otomasyonu',
    emoji: '🧠'
  },
  {
    id: 'security-backup',
    title: 'İş Güvenliği ve Backup',
    icon: Shield,
    color: 'from-gray-600 to-slate-600',
    description: 'Veri güvenliği ve yedekleme',
    emoji: '🔒'
  }
];

const quickActions = [
  { id: 'new-project', label: 'Yeni Proje', icon: Plus, color: 'bg-blue-600' },
  { id: 'start-timer', label: 'Timer Başlat', icon: Play, color: 'bg-green-600' },
  { id: 'add-task', label: 'Görev Ekle', icon: CheckSquare, color: 'bg-purple-600' },
  { id: 'view-analytics', label: 'Analitik', icon: BarChart3, color: 'bg-orange-600' }
];

export function TaskPlannerPanel() {
  const [selectedModule, setSelectedModule] = useState<string | null>(null);
  const [messages, setMessages] = useState<Array<{id: string, role: 'user' | 'assistant', content: string, timestamp: string}>>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('modules');
  const [pomodoroTime, setPomodoroTime] = useState(25 * 60); // 25 minutes
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const { generateAIResponse, settings } = useApp();
  const { user } = useAuth();
  const isPremium = user?.role === 'premium';

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Pomodoro Timer Logic
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isTimerRunning && pomodoroTime > 0) {
      interval = setInterval(() => {
        setPomodoroTime(time => time - 1);
      }, 1000);
    } else if (pomodoroTime === 0) {
      setIsTimerRunning(false);
      toast({
        title: "🍅 Pomodoro Tamamlandı!",
        description: "Harika! 5 dakika mola zamanı."
      });
      setPomodoroTime(25 * 60);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, pomodoroTime]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const sendMessage = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setIsLoading(true);

    const userMsgObj = {
      id: `user_${Date.now()}`,
      role: 'user' as const,
      content: userMessage,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMsgObj]);

    try {
      const taskPlannerPrompt = `Sen bir proje yönetimi ve verimlilik uzmanısın. Kullanıcıların iş planlaması, görev yönetimi, zaman yönetimi ve proje organizasyonu konularında yardımcı oluyorsun.

${selectedModule ? `Aktif Modül: ${plannerModules.find(m => m.id === selectedModule)?.title}` : ''}

Kullanıcı Sorusu: ${userMessage}

Lütfen:
1. Pratik ve uygulanabilir öneriler sun
2. Zaman yönetimi teknikleri öner
3. Proje planlama metodolojileri açıkla
4. Verimlilik artırıcı stratejiler ver
5. Görev önceliklendirme yöntemleri sun
6. Takım çalışması için ipuçları ver

Yanıtını Türkçe ver ve proje yönetimi uzmanı rolünde kal.`;

      const aiResponse = await generateAIResponse(taskPlannerPrompt, settings);
      
      const aiMsgObj = {
        id: `ai_${Date.now()}`,
        role: 'assistant' as const,
        content: aiResponse,
        timestamp: new Date().toISOString()
      };

      setMessages(prev => [...prev, aiMsgObj]);

    } catch (error) {
      console.error('Task Planner Error:', error);
      setMessages(prev => [...prev, {
        id: `error_${Date.now()}`,
        role: 'assistant' as const,
        content: 'Üzgünüm, bir hata oluştu. Lütfen tekrar deneyin.',
        timestamp: new Date().toISOString()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const startModule = (moduleId: string) => {
    setSelectedModule(moduleId);
    setActiveTab('assistant');
    
    const moduleData = plannerModules.find(m => m.id === moduleId);
    toast({
      title: `${moduleData?.emoji} ${moduleData?.title}`,
      description: "Modül aktif! AI asistanından yardım alabilirsiniz."
    });
  };

  const handleQuickAction = (actionId: string) => {
    switch (actionId) {
      case 'start-timer':
        setIsTimerRunning(!isTimerRunning);
        toast({
          title: isTimerRunning ? "⏸️ Timer Durduruldu" : "▶️ Pomodoro Timer Başlatıldı",
          description: isTimerRunning ? "Timer duraklatıldı" : "25 dakikalık odaklanma süresi başladı"
        });
        break;
      default:
        toast({
          title: `${quickActions.find(a => a.id === actionId)?.label}`,
          description: "Özellik yakında eklenecek!"
        });
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="flex-1 bg-gradient-to-br from-slate-950 via-blue-950 to-cyan-950 h-full overflow-hidden">
      <div className="flex h-full">
        {/* Left Panel - Modules and Tools */}
        <div className="w-80 bg-gradient-to-b from-slate-900/95 via-blue-900/90 to-cyan-950/95 backdrop-blur-xl border-r border-cyan-400/30 p-6 overflow-y-auto shadow-2xl shadow-cyan-900/50">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            {/* Header */}
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-gradient-to-r from-blue-500 via-cyan-500 to-teal-500 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-cyan-500/40">
                <Briefcase size={24} className="text-white" />
              </div>
              <h1 className="text-2xl font-black bg-gradient-to-r from-white via-cyan-100 to-blue-100 bg-clip-text text-transparent">İş Takibi ve Plan Oluşturucu</h1>
              <p className="text-cyan-300 text-sm font-bold">Akıllı proje yönetimi ve verimlilik araçları</p>
            </div>

            {/* Pomodoro Timer */}
            <Card className="bg-gradient-to-br from-green-900/90 via-emerald-900/80 to-teal-900/90 border-emerald-400/50 backdrop-blur-md shadow-2xl shadow-emerald-900/60">
              <CardHeader>
                <CardTitle className="text-white text-lg flex items-center font-black">
                  <Timer size={18} className="mr-2" />
                  Pomodoro Timer
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <div className="text-4xl font-black text-white mb-2">
                    {formatTime(pomodoroTime)}
                  </div>
                  <Progress 
                    value={((25 * 60 - pomodoroTime) / (25 * 60)) * 100} 
                    className="h-2 bg-emerald-950/80"
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Button
                    onClick={() => handleQuickAction('start-timer')}
                    className={cn(
                      "flex-1 font-bold",
                      isTimerRunning 
                        ? "bg-red-600 hover:bg-red-500" 
                        : "bg-green-600 hover:bg-green-500"
                    )}
                  >
                    {isTimerRunning ? <Pause size={16} className="mr-2" /> : <Play size={16} className="mr-2" />}
                    {isTimerRunning ? 'Durdur' : 'Başlat'}
                  </Button>
                  <Button
                    onClick={() => {
                      setPomodoroTime(25 * 60);
                      setIsTimerRunning(false);
                    }}
                    variant="outline"
                    size="icon"
                    className="border-emerald-600/60 text-emerald-200 hover:bg-emerald-800/60"
                  >
                    <RotateCcw size={16} />
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="bg-gradient-to-br from-blue-900/90 via-cyan-900/80 to-blue-950/90 border-cyan-400/40 backdrop-blur-md shadow-2xl shadow-cyan-900/60">
              <CardHeader>
                <CardTitle className="text-white text-lg flex items-center font-black">
                  <Zap size={18} className="mr-2" />
                  Hızlı Aksiyonlar
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-2">
                  {quickActions.map((action) => (
                    <Button
                      key={action.id}
                      onClick={() => handleQuickAction(action.id)}
                      className={cn(
                        "h-auto p-3 flex flex-col items-center space-y-1 text-xs font-bold",
                        action.color,
                        "hover:opacity-90 transition-all duration-300"
                      )}
                    >
                      <action.icon size={16} />
                      <span className="text-center leading-tight">{action.label}</span>
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Performance Stats */}
            <Card className="bg-gradient-to-br from-orange-900/90 via-red-900/80 to-pink-900/90 border-orange-400/50 backdrop-blur-md shadow-2xl shadow-orange-900/60">
              <CardHeader>
                <CardTitle className="text-white text-lg flex items-center font-black">
                  <Activity size={18} className="mr-2" />
                  Performans Özeti
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-orange-950/80 p-3 rounded-lg border border-orange-400/30">
                    <div className="text-white font-black text-lg">24</div>
                    <div className="text-orange-100 text-xs font-bold">Aktif Proje</div>
                  </div>
                  <div className="bg-orange-950/80 p-3 rounded-lg border border-orange-400/30">
                    <div className="text-white font-black text-lg">87%</div>
                    <div className="text-orange-100 text-xs font-bold">Tamamlanma</div>
                  </div>
                  <div className="bg-orange-950/80 p-3 rounded-lg border border-orange-400/30">
                    <div className="text-white font-black text-lg">156h</div>
                    <div className="text-orange-100 text-xs font-bold">Bu Ay</div>
                  </div>
                  <div className="bg-orange-950/80 p-3 rounded-lg border border-orange-400/30">
                    <div className="text-white font-black text-lg">94%</div>
                    <div className="text-orange-100 text-xs font-bold">Verimlilik</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Right Panel - Main Content */}
        <div className="flex-1 flex flex-col">
          {/* Header */}
          <div className="p-4 border-b border-cyan-500/30 bg-gradient-to-r from-slate-900/80 via-blue-900/70 to-cyan-900/80 backdrop-blur-md shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-black text-white">📚 İş Takibi ve Plan Oluşturucu</h2>
                <p className="text-sm text-cyan-100 font-bold">
                  {selectedModule 
                    ? `${plannerModules.find(m => m.id === selectedModule)?.emoji} ${plannerModules.find(m => m.id === selectedModule)?.title}`
                    : 'Akıllı proje yönetimi ve verimlilik araçları'
                  }
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <Button
                  variant={activeTab === 'modules' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setActiveTab('modules')}
                  className={cn(
                    "font-bold",
                    activeTab === 'modules' 
                      ? "bg-gradient-to-r from-blue-600 to-cyan-600 text-white" 
                      : "border-cyan-600/60 text-cyan-200 hover:bg-cyan-800/60"
                  )}
                >
                  <Briefcase size={16} className="mr-2" />
                  Modüller
                </Button>
                <Button
                  variant={activeTab === 'assistant' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setActiveTab('assistant')}
                  className={cn(
                    "font-bold",
                    activeTab === 'assistant' 
                      ? "bg-gradient-to-r from-blue-600 to-cyan-600 text-white" 
                      : "border-cyan-600/60 text-cyan-200 hover:bg-cyan-800/60"
                  )}
                >
                  <Brain size={16} className="mr-2" />
                  AI Asistan
                </Button>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto">
            {activeTab === 'modules' ? (
              /* Modules View */
              <div className="p-6 space-y-8">
                {/* Main Modules */}
                <div>
                  <h3 className="text-2xl font-black text-white mb-6 flex items-center">
                    <Star size={24} className="mr-3 text-yellow-500" />
                    Ana Modüller
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {plannerModules.map((module, index) => (
                      <motion.div
                        key={module.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="group"
                      >
                        <Card className="bg-gradient-to-br from-slate-950/90 to-blue-950/90 border-cyan-500/50 backdrop-blur-md shadow-xl shadow-cyan-900/60 hover:shadow-cyan-800/80 hover:border-cyan-400/70 transition-all duration-300 h-full cursor-pointer"
                             onClick={() => startModule(module.id)}>
                          <CardHeader className="pb-4">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <div className="flex items-center space-x-3 mb-3">
                                  <div className={cn(
                                    "w-12 h-12 rounded-xl flex items-center justify-center text-2xl shadow-lg",
                                    `bg-gradient-to-r ${module.color}`
                                  )}>
                                    {module.emoji}
                                  </div>
                                  <div>
                                    <CardTitle className="text-white text-xl group-hover:text-cyan-200 transition-colors font-black">
                                      {module.title}
                                    </CardTitle>
                                  </div>
                                </div>
                                <CardDescription className="text-cyan-200 font-bold text-sm leading-relaxed">
                                  {module.description}
                                </CardDescription>
                              </div>
                            </div>
                          </CardHeader>
                          
                          <CardContent className="space-y-4">
                            <div className="space-y-2">
                              <h4 className="text-white font-black text-sm">Özellikler:</h4>
                              <div className="grid grid-cols-1 gap-1">
                                {module.features.slice(0, 4).map((feature, featureIndex) => (
                                  <div key={featureIndex} className="flex items-center space-x-2 text-xs">
                                    <CheckCircle size={12} className="text-emerald-400 flex-shrink-0" />
                                    <span className="text-cyan-100 font-semibold">{feature}</span>
                                  </div>
                                ))}
                                {module.features.length > 4 && (
                                  <div className="text-xs text-cyan-300 font-semibold">
                                    +{module.features.length - 4} özellik daha...
                                  </div>
                                )}
                              </div>
                            </div>

                            <div className="grid grid-cols-3 gap-2 text-xs">
                              {Object.entries(module.stats).map(([key, value]) => (
                                <div key={key} className="text-center bg-slate-950/80 p-2 rounded-lg border border-cyan-400/20">
                                  <div className="text-white font-black">{value}</div>
                                  <div className="text-cyan-300 font-bold capitalize">{key}</div>
                                </div>
                              ))}
                            </div>
                            
                            <Button
                              className={cn(
                                "w-full font-black transition-all duration-300",
                                `bg-gradient-to-r ${module.color} hover:opacity-90 shadow-lg hover:shadow-xl`
                              )}
                            >
                              <module.icon size={16} className="mr-2" />
                              Modülü Başlat
                            </Button>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))}
                  </div>
                </div>

                {/* Additional Modules */}
                <div>
                  <h3 className="text-2xl font-black text-white mb-6 flex items-center">
                    <Award size={24} className="mr-3 text-purple-500" />
                    Ek Modüller
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    {additionalModules.map((module, index) => (
                      <motion.div
                        key={module.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.4 + index * 0.1 }}
                      >
                        <Card className="bg-gradient-to-br from-slate-950/90 to-blue-950/90 border-cyan-500/50 backdrop-blur-md shadow-xl shadow-cyan-900/60 hover:shadow-cyan-800/80 hover:border-cyan-400/70 transition-all duration-300 cursor-pointer">
                          <CardContent className="p-4 text-center">
                            <div className={cn(
                              "w-12 h-12 rounded-xl flex items-center justify-center text-2xl shadow-lg mx-auto mb-3",
                              `bg-gradient-to-r ${module.color}`
                            )}>
                              {module.emoji}
                            </div>
                            <h4 className="text-white font-black text-sm mb-2">{module.title}</h4>
                            <p className="text-cyan-200 text-xs font-semibold">{module.description}</p>
                            <Button
                              size="sm"
                              className={cn(
                                "w-full mt-3 font-bold",
                                `bg-gradient-to-r ${module.color} hover:opacity-90`
                              )}
                            >
                              <module.icon size={14} className="mr-1" />
                              Yakında
                            </Button>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))}
                  </div>
                </div>

                {/* Features Overview */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.8 }}
                >
                  <Card className="bg-gradient-to-br from-slate-950/90 to-blue-950/90 border-cyan-500/50 backdrop-blur-md shadow-xl shadow-cyan-900/60">
                    <CardHeader>
                      <CardTitle className="text-white text-xl flex items-center font-black">
                        <Lightbulb size={20} className="mr-2" />
                        Platform Özellikleri
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="space-y-2">
                          <h4 className="text-white font-black flex items-center">
                            <Smartphone size={16} className="mr-2 text-blue-400" />
                            Teknoloji
                          </h4>
                          <ul className="space-y-1 text-cyan-100 text-sm font-semibold">
                            <li>• PWA desteği (Offline çalışma)</li>
                            <li>• Real-time senkronizasyon</li>
                            <li>• Push bildirimler</li>
                            <li>• Voice commands</li>
                          </ul>
                        </div>
                        <div className="space-y-2">
                          <h4 className="text-white font-black flex items-center">
                            <Globe size={16} className="mr-2 text-green-400" />
                            Entegrasyonlar
                          </h4>
                          <ul className="space-y-1 text-cyan-100 text-sm font-semibold">
                            <li>• Slack, Trello, Asana</li>
                            <li>• Google Workspace</li>
                            <li>• Microsoft 365</li>
                            <li>• Zapier otomasyonu</li>
                          </ul>
                        </div>
                        <div className="space-y-2">
                          <h4 className="text-white font-black flex items-center">
                            <FileText size={16} className="mr-2 text-purple-400" />
                            Export & Raporlar
                          </h4>
                          <ul className="space-y-1 text-cyan-100 text-sm font-semibold">
                            <li>• PDF, Excel, JSON export</li>
                            <li>• Custom report builder</li>
                            <li>• Executive summaries</li>
                            <li>• Automated insights</li>
                          </ul>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              </div>
            ) : (
              /* AI Assistant Chat View */
              <div className="flex-1 flex flex-col">
                {/* Chat Messages */}
                <div className="flex-1 overflow-y-auto p-4 space-y-6">
                  {messages.length === 0 && (
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="text-center py-12"
                    >
                      <div className="w-20 h-20 rounded-full bg-gradient-to-r from-blue-500 via-cyan-500 to-teal-500 flex items-center justify-center mx-auto mb-6 shadow-lg shadow-cyan-500/40">
                        <Brain size={32} className="text-white" />
                      </div>
                      <h3 className="text-2xl font-black bg-gradient-to-r from-white via-cyan-100 to-blue-100 bg-clip-text text-transparent mb-4">
                        AI İş Planlama Asistanı
                      </h3>
                      <p className="text-cyan-100 max-w-md mx-auto mb-6 font-bold">
                        {selectedModule 
                          ? `${plannerModules.find(m => m.id === selectedModule)?.emoji} ${plannerModules.find(m => m.id === selectedModule)?.title} konusunda size yardımcı olacağım.`
                          : 'Proje yönetimi, görev planlama ve verimlilik konularında size yardımcı olacağım.'
                        }
                      </p>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl mx-auto">
                        <div className="p-4 bg-gradient-to-br from-slate-900/80 to-blue-900/80 rounded-lg border border-cyan-400/50 hover:border-cyan-300/70 transition-all duration-300 hover:shadow-xl hover:shadow-cyan-500/50">
                          <Calendar className="text-blue-500 mb-2" size={24} />
                          <h4 className="text-white font-black mb-1">Proje Planlama</h4>
                          <p className="text-cyan-100 text-sm font-semibold">Akıllı proje planları oluşturun</p>
                        </div>
                        <div className="p-4 bg-gradient-to-br from-slate-900/80 to-blue-900/80 rounded-lg border border-cyan-400/50 hover:border-cyan-300/70 transition-all duration-300 hover:shadow-xl hover:shadow-cyan-500/50">
                          <Clock className="text-green-500 mb-2" size={24} />
                          <h4 className="text-white font-black mb-1">Zaman Yönetimi</h4>
                          <p className="text-cyan-100 text-sm font-semibold">Verimlilik teknikleri öğrenin</p>
                        </div>
                        <div className="p-4 bg-gradient-to-br from-slate-900/80 to-blue-900/80 rounded-lg border border-cyan-400/50 hover:border-cyan-300/70 transition-all duration-300 hover:shadow-xl hover:shadow-cyan-500/50">
                          <Target className="text-orange-500 mb-2" size={24} />
                          <h4 className="text-white font-black mb-1">Hedef Belirleme</h4>
                          <p className="text-cyan-100 text-sm font-semibold">SMART hedefler oluşturun</p>
                        </div>
                        <div className="p-4 bg-gradient-to-br from-slate-900/80 to-blue-900/80 rounded-lg border border-cyan-400/50 hover:border-cyan-300/70 transition-all duration-300 hover:shadow-xl hover:shadow-cyan-500/50">
                          <Users className="text-purple-500 mb-2" size={24} />
                          <h4 className="text-white font-black mb-1">Takım Yönetimi</h4>
                          <p className="text-cyan-100 text-sm font-semibold">Etkili takım koordinasyonu</p>
                        </div>
                      </div>
                    </motion.div>
                  )}

                  <AnimatePresence>
                    {messages.map((message) => (
                      <motion.div
                        key={message.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3 }}
                        className={cn(
                          "flex",
                          message.role === 'user' ? "justify-end" : "justify-start"
                        )}
                      >
                        <div
                          className={cn(
                            "max-w-3xl rounded-2xl p-4 shadow-lg flex items-start space-x-3",
                            message.role === 'user'
                              ? "bg-gradient-to-r from-blue-600 to-cyan-600 text-white ml-12 flex-row-reverse space-x-reverse"
                              : "bg-slate-800/80 backdrop-blur-sm text-slate-100 mr-12 border border-cyan-500/20"
                          )}
                        >
                          <div className={cn(
                            "w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0",
                            message.role === 'user'
                              ? "bg-white/20"
                              : "bg-gradient-to-r from-blue-600 to-cyan-600"
                          )}>
                            {message.role === 'user' ? (
                              <User size={16} className="text-white" />
                            ) : (
                              <Bot size={16} className="text-white" />
                            )}
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <div className={cn(
                              "text-xs font-bold mb-1",
                              message.role === 'user' ? "text-cyan-200" : "text-cyan-300"
                            )}>
                              {message.role === 'user' ? 'Siz' : 'İş Planlama Asistanı'}
                            </div>
                            <p className="whitespace-pre-wrap leading-relaxed text-sm font-semibold">{message.content}</p>
                            <div className={cn(
                              "text-xs opacity-60 mt-2",
                              message.role === 'user' ? "text-cyan-200" : "text-cyan-300"
                            )}>
                              {new Date(message.timestamp).toLocaleTimeString('tr-TR')}
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>

                  {/* Typing Indicator */}
                  <AnimatePresence>
                    {isLoading && (
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        className="flex justify-start"
                      >
                        <div className="max-w-3xl rounded-2xl p-4 bg-slate-800/80 backdrop-blur-sm border border-cyan-500/20 mr-12 flex items-start space-x-3">
                          <div className="w-8 h-8 rounded-full bg-gradient-to-r from-blue-600 to-cyan-600 flex items-center justify-center flex-shrink-0">
                            <Bot size={16} className="text-white" />
                          </div>
                          
                          <div className="flex-1">
                            <div className="text-xs font-bold mb-1 text-cyan-200">İş Planlama Asistanı</div>
                            <div className="flex items-center space-x-2">
                              <div className="flex space-x-1">
                                <div className="w-2 h-2 bg-cyan-500 rounded-full animate-bounce"></div>
                                <div className="w-2 h-2 bg-cyan-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                                <div className="w-2 h-2 bg-cyan-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                              </div>
                              <span className="text-cyan-200 text-sm font-bold">Plan hazırlanıyor...</span>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <div ref={messagesEndRef} />
                </div>

                {/* Input Area */}
                <div className="p-4 border-t border-cyan-500/40 bg-slate-900/60 backdrop-blur-sm">
                  <div className="max-w-4xl mx-auto">
                    <div className="relative">
                      <Textarea
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyPress={handleKeyPress}
                        placeholder="Proje planınızı, görevlerinizi veya zaman yönetimi sorularınızı yazın..."
                        className="min-h-[60px] pr-12 resize-none bg-slate-950/80 border-cyan-500/60 focus:border-cyan-400 text-white placeholder-cyan-300 font-semibold"
                        disabled={isLoading}
                      />
                      <Button
                        onClick={sendMessage}
                        disabled={!input.trim() || isLoading}
                        size="icon"
                        className="absolute right-2 bottom-2 w-8 h-8 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500"
                      >
                        <Send size={16} />
                      </Button>
                    </div>
                    
                    <div className="flex justify-between items-center mt-2 text-xs text-cyan-300 font-bold">
                      <span>📚 İş planlama asistanı ile konuşuyorsunuz</span>
                      {!isPremium && (
                        <span>✨ Premium ile gelişmiş özellikler</span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}