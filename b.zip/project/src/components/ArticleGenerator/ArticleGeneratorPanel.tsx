import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Send, 
  FileText, 
  Download, 
  Copy, 
  RefreshCw, 
  Save, 
  Eye, 
  EyeOff,
  Lightbulb,
  Target,
  Users,
  Hash,
  Clock,
  BookOpen,
  Zap,
  Sparkles,
  Bot,
  User,
  Settings,
  Wand2,
  PenTool
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { useApp } from '@/contexts/AppContext';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

interface ArticleStep {
  id: string;
  title: string;
  description: string;
  prompt: string;
  completed: boolean;
  result?: string;
}

const articleSteps: ArticleStep[] = [
  {
    id: 'topic',
    title: 'Konu Belirleme',
    description: 'Makale konusunu ve ana fikrini belirleyin',
    prompt: 'Bu konu hakkında kapsamlı bir makale yazacağım: [KONU]. Bu konunun ana başlıklarını, alt konularını ve makale yapısını öner.',
    completed: false
  },
  {
    id: 'outline',
    title: 'Makale Taslağı',
    description: 'Detaylı makale yapısı ve başlıklar',
    prompt: 'Şu konu için detaylı makale taslağı hazırla: [KONU]. Giriş, ana bölümler, alt başlıklar ve sonuç kısmını içeren yapılandırılmış bir taslak oluştur.',
    completed: false
  },
  {
    id: 'introduction',
    title: 'Giriş Yazımı',
    description: 'Çekici ve bilgilendirici giriş paragrafı',
    prompt: 'Bu makale konusu için etkileyici bir giriş paragrafı yaz: [KONU]. Okuyucunun ilgisini çekecek, konunun önemini vurgulayacak ve makale boyunca neler öğreneceğini belirtecek bir giriş hazırla.',
    completed: false
  },
  {
    id: 'content',
    title: 'Ana İçerik',
    description: 'Makale ana içeriğini oluşturun',
    prompt: 'Şu taslağa göre makale ana içeriğini yaz: [TASLAK]. Her bölümü detaylı şekilde açıkla, örnekler ver ve okuyucu için değerli bilgiler sun.',
    completed: false
  },
  {
    id: 'conclusion',
    title: 'Sonuç ve Özet',
    description: 'Makaleyi güçlü bir sonuçla bitirin',
    prompt: 'Bu makale için güçlü bir sonuç paragrafı yaz: [MAKALE_ÖZETİ]. Ana noktaları özetle, okuyucuya eylem çağrısı yap ve konunun gelecekteki önemini vurgula.',
    completed: false
  }
];

const articleTypes = [
  { value: 'blog', label: 'Blog Yazısı', description: 'SEO uyumlu blog içeriği' },
  { value: 'news', label: 'Haber Makalesi', description: 'Güncel haber formatı' },
  { value: 'tutorial', label: 'Eğitim Makalesi', description: 'Adım adım rehber' },
  { value: 'review', label: 'İnceleme', description: 'Ürün/hizmet incelemesi' },
  { value: 'opinion', label: 'Görüş Yazısı', description: 'Kişisel görüş ve analiz' },
  { value: 'research', label: 'Araştırma Makalesi', description: 'Detaylı araştırma içeriği' }
];

const toneOptions = [
  { value: 'professional', label: 'Profesyonel', icon: '👔' },
  { value: 'casual', label: 'Samimi', icon: '😊' },
  { value: 'academic', label: 'Akademik', icon: '🎓' },
  { value: 'creative', label: 'Yaratıcı', icon: '🎨' },
  { value: 'persuasive', label: 'İkna Edici', icon: '💪' },
  { value: 'informative', label: 'Bilgilendirici', icon: '📚' }
];

export function ArticleGeneratorPanel() {
  const [currentStep, setCurrentStep] = useState(0);
  const [steps, setSteps] = useState<ArticleStep[]>(articleSteps);
  const [articleConfig, setArticleConfig] = useState({
    topic: '',
    type: 'blog',
    tone: 'professional',
    targetAudience: '',
    keywords: '',
    wordCount: 1000,
    language: 'tr'
  });
  const [messages, setMessages] = useState<Array<{id: string, role: 'user' | 'assistant', content: string, timestamp: string}>>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [generatedArticle, setGeneratedArticle] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const { generateAIResponse, settings } = useApp();
  const { user } = useAuth();
  const isPremium = user?.role === 'premium';

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const sendMessage = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setIsLoading(true);

    // Add user message
    const userMsgObj = {
      id: `user_${Date.now()}`,
      role: 'user' as const,
      content: userMessage,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMsgObj]);

    try {
      // Generate AI response with article context
      const contextPrompt = `Sen bir makale yazma uzmanısın. Kullanıcı şu makale için yardım istiyor:
      
Makale Türü: ${articleTypes.find(t => t.value === articleConfig.type)?.label}
Ton: ${toneOptions.find(t => t.value === articleConfig.tone)?.label}
Hedef Kitle: ${articleConfig.targetAudience || 'Genel'}
Anahtar Kelimeler: ${articleConfig.keywords || 'Belirtilmemiş'}
Kelime Sayısı: ${articleConfig.wordCount}

Kullanıcı Sorusu: ${userMessage}

Makale yazımına yönelik profesyonel ve detaylı yardım sağla.`;

      const aiResponse = await generateAIResponse(contextPrompt, settings);
      
      const aiMsgObj = {
        id: `ai_${Date.now()}`,
        role: 'assistant' as const,
        content: aiResponse,
        timestamp: new Date().toISOString()
      };

      setMessages(prev => [...prev, aiMsgObj]);

    } catch (error) {
      console.error('Article Generator Error:', error);
      setMessages(prev => [...prev, {
        id: `error_${Date.now()}`,
        role: 'assistant' as const,
        content: 'Üzgünüm, bir hata oluştu. Lütfen tekrar deneyin.',
        timestamp: new Date().toISOString()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const generateStepContent = async (stepIndex: number) => {
    if (isLoading) return;

    const step = steps[stepIndex];
    setIsLoading(true);

    try {
      let prompt = step.prompt;
      
      // Replace placeholders with actual values
      if (articleConfig.topic) {
        prompt = prompt.replace(/\[KONU\]/g, articleConfig.topic);
      }
      
      // Add context for better results
      const contextualPrompt = `${prompt}

Makale Detayları:
- Tür: ${articleTypes.find(t => t.value === articleConfig.type)?.label}
- Ton: ${toneOptions.find(t => t.value === articleConfig.tone)?.label}
- Hedef Kitle: ${articleConfig.targetAudience || 'Genel okuyucu'}
- Anahtar Kelimeler: ${articleConfig.keywords || 'Yok'}
- Hedef Kelime Sayısı: ${articleConfig.wordCount}

Lütfen bu bilgileri göz önünde bulundurarak ${step.title.toLowerCase()} hazırla.`;

      const response = await generateAIResponse(contextualPrompt, settings);
      
      // Update step with result
      const updatedSteps = [...steps];
      updatedSteps[stepIndex] = {
        ...updatedSteps[stepIndex],
        completed: true,
        result: response
      };
      setSteps(updatedSteps);

      // Add to chat messages
      const aiMsgObj = {
        id: `step_${Date.now()}`,
        role: 'assistant' as const,
        content: `**${step.title} Tamamlandı:**\n\n${response}`,
        timestamp: new Date().toISOString()
      };

      setMessages(prev => [...prev, aiMsgObj]);

      toast({
        title: `${step.title} Tamamlandı!`,
        description: "Sonraki adıma geçebilirsiniz."
      });

    } catch (error) {
      console.error('Step Generation Error:', error);
      toast({
        title: "Hata",
        description: "İçerik oluşturulurken bir hata oluştu.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const generateFullArticle = async () => {
    if (!articleConfig.topic) {
      toast({
        title: "Konu Gerekli",
        description: "Lütfen önce makale konusunu belirtin.",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);

    try {
      const fullPrompt = `Şu özelliklerde kapsamlı bir makale yaz:

Konu: ${articleConfig.topic}
Makale Türü: ${articleTypes.find(t => t.value === articleConfig.type)?.label}
Ton: ${toneOptions.find(t => t.value === articleConfig.tone)?.label}
Hedef Kitle: ${articleConfig.targetAudience || 'Genel okuyucu'}
Anahtar Kelimeler: ${articleConfig.keywords || 'Yok'}
Hedef Kelime Sayısı: ${articleConfig.wordCount}

Makale şu yapıda olmalı:
1. Çekici başlık
2. Giriş paragrafı
3. Ana bölümler (alt başlıklarla)
4. Sonuç ve özet
5. SEO uyumlu meta açıklama

Profesyonel, akıcı ve okuyucu dostu bir makale hazırla.`;

      const article = await generateAIResponse(fullPrompt, settings);
      setGeneratedArticle(article);
      setShowPreview(true);

      toast({
        title: "Makale Oluşturuldu!",
        description: "Tam makale başarıyla oluşturuldu."
      });

    } catch (error) {
      console.error('Full Article Generation Error:', error);
      toast({
        title: "Hata",
        description: "Makale oluşturulurken bir hata oluştu.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const exportArticle = (format: 'txt' | 'md') => {
    if (!generatedArticle) return;

    const content = format === 'md' ? generatedArticle : generatedArticle.replace(/\*\*/g, '').replace(/\*/g, '');
    const blob = new Blob([content], { type: format === 'md' ? 'text/markdown' : 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `makale_${articleConfig.topic.replace(/\s+/g, '_')}.${format}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="flex-1 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 h-full overflow-hidden">
      <div className="flex h-full">
        {/* Left Panel - Configuration */}
        <div className="w-80 bg-gradient-to-b from-purple-950/95 via-indigo-950/90 to-purple-950/95 backdrop-blur-xl border-r border-purple-400/30 p-6 overflow-y-auto shadow-2xl shadow-purple-900/50">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center mx-auto mb-4">
                <PenTool size={24} className="text-white" />
              </div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-white via-purple-100 to-purple-200 bg-clip-text text-transparent">Makale Oluşturucu</h1>
              <p className="text-purple-300 text-sm font-medium">AI destekli makale yazım asistanı</p>
            </div>

            {/* Article Configuration */}
            <Card className="bg-gradient-to-br from-purple-900/90 via-indigo-900/80 to-purple-950/90 border-purple-400/40 backdrop-blur-md shadow-2xl shadow-purple-900/60">
              <CardHeader>
                <CardTitle className="text-purple-50 text-lg flex items-center font-bold">
                  <Settings size={18} className="mr-2" />
                  Makale Ayarları
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-purple-100 text-sm font-semibold mb-2 block">Makale Konusu</label>
                  <Input
                    value={articleConfig.topic}
                    onChange={(e) => setArticleConfig({...articleConfig, topic: e.target.value})}
                    placeholder="Makale konusunu yazın..."
                    className="bg-purple-950/80 border-purple-600/60 text-purple-50 placeholder-purple-300/70 focus:border-purple-400 focus:ring-purple-400/30"
                  />
                </div>

                <div>
                  <label className="text-purple-100 text-sm font-semibold mb-2 block">Makale Türü</label>
                  <Select value={articleConfig.type} onValueChange={(value) => setArticleConfig({...articleConfig, type: value})}>
                    <SelectTrigger className="bg-purple-950/80 border-purple-600/60 text-purple-50 hover:border-purple-400/80 transition-colors">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-purple-950 border-purple-600/60">
                      {articleTypes.map((type) => (
                        <SelectItem key={type.value} value={type.value} className="text-purple-50 hover:bg-purple-900/70 focus:bg-purple-900/70">
                          <div>
                            <div className="font-semibold text-purple-50">{type.label}</div>
                            <div className="text-xs text-purple-300">{type.description}</div>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-purple-100 text-sm font-semibold mb-2 block">Yazım Tonu</label>
                  <div className="grid grid-cols-2 gap-2">
                    {toneOptions.map((tone) => (
                      <Button
                        key={tone.value}
                        variant={articleConfig.tone === tone.value ? "default" : "outline"}
                        size="sm"
                        onClick={() => setArticleConfig({...articleConfig, tone: tone.value})}
                        className={cn(
                          "text-xs",
                          articleConfig.tone === tone.value 
                            ? "bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold shadow-lg shadow-purple-500/40" 
                            : "border-purple-600/50 text-purple-200 hover:bg-purple-800/60 hover:border-purple-500/70 hover:text-purple-100"
                        )}
                      >
                        <span className="mr-1">{tone.icon}</span>
                        {tone.label}
                      </Button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-purple-100 text-sm font-semibold mb-2 block">Hedef Kitle</label>
                  <Input
                    value={articleConfig.targetAudience}
                    onChange={(e) => setArticleConfig({...articleConfig, targetAudience: e.target.value})}
                    placeholder="Örn: Girişimciler, öğrenciler..."
                    className="bg-purple-950/80 border-purple-600/60 text-purple-50 placeholder-purple-300/70 focus:border-purple-400 focus:ring-purple-400/30"
                  />
                </div>

                <div>
                  <label className="text-purple-100 text-sm font-semibold mb-2 block">Anahtar Kelimeler</label>
                  <Input
                    value={articleConfig.keywords}
                    onChange={(e) => setArticleConfig({...articleConfig, keywords: e.target.value})}
                    placeholder="Virgülle ayırın..."
                    className="bg-purple-950/80 border-purple-600/60 text-purple-50 placeholder-purple-300/70 focus:border-purple-400 focus:ring-purple-400/30"
                  />
                </div>

                <div>
                  <label className="text-purple-100 text-sm font-semibold mb-2 block">
                    Kelime Sayısı: {articleConfig.wordCount}
                  </label>
                  <Slider
                    value={[articleConfig.wordCount]}
                    onValueChange={(value) => setArticleConfig({...articleConfig, wordCount: value[0]})}
                    max={5000}
                    min={300}
                    step={100}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-purple-300 mt-1">
                    <span>300</span>
                    <span>5000</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <div className="space-y-3">
              <Button
                onClick={generateFullArticle}
                disabled={isLoading || !articleConfig.topic}
                className="w-full bg-gradient-to-r from-purple-600 via-violet-600 to-indigo-600 hover:from-purple-500 hover:via-violet-500 hover:to-indigo-500 text-white font-bold shadow-xl shadow-purple-500/50 hover:shadow-purple-400/60 transition-all duration-300"
              >
                <Wand2 size={16} className="mr-2" />
                {isLoading ? 'Oluşturuluyor...' : 'Tam Makale Oluştur'}
              </Button>

              {generatedArticle && (
                <div className="flex space-x-2">
                  <Button
                    onClick={() => setShowPreview(!showPreview)}
                    variant="outline"
                    size="sm"
                    className="flex-1 border-purple-600/60 text-purple-200 hover:bg-purple-800/60 hover:border-purple-500/80 hover:text-purple-100 transition-all duration-200"
                  >
                    {showPreview ? <EyeOff size={14} /> : <Eye size={14} />}
                  </Button>
                  <Button
                    onClick={() => exportArticle('md')}
                    variant="outline"
                    size="sm"
                    className="flex-1 border-purple-600/60 text-purple-200 hover:bg-purple-800/60 hover:border-purple-500/80 hover:text-purple-100 transition-all duration-200"
                  >
                    <Download size={14} />
                  </Button>
                  <Button
                    onClick={() => {
                      navigator.clipboard.writeText(generatedArticle);
                      toast({ title: "Kopyalandı!" });
                    }}
                    variant="outline"
                    size="sm"
                    className="flex-1 border-purple-600/60 text-purple-200 hover:bg-purple-800/60 hover:border-purple-500/80 hover:text-purple-100 transition-all duration-200"
                  >
                    <Copy size={14} />
                  </Button>
                </div>
              )}
            </div>

            {/* Step Progress */}
            <Card className="bg-gradient-to-br from-purple-900/90 via-indigo-900/80 to-purple-950/90 border-purple-400/40 backdrop-blur-md shadow-2xl shadow-purple-900/60">
              <CardHeader>
                <CardTitle className="text-purple-50 text-sm font-bold">Adım Adım Oluşturma</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {steps.map((step, index) => (
                  <div
                    key={step.id}
                    className={cn(
                      "p-3 rounded-lg border cursor-pointer transition-all",
                      step.completed 
                        ? "bg-gradient-to-r from-emerald-900/60 to-green-900/60 border-emerald-400/60 shadow-lg shadow-emerald-500/30" 
                        : "bg-purple-950/60 border-purple-600/50 hover:border-purple-400/70 hover:bg-purple-900/70 hover:shadow-lg hover:shadow-purple-500/30"
                    )}
                    onClick={() => generateStepContent(index)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="text-purple-50 text-sm font-semibold">{step.title}</div>
                        <div className="text-purple-300 text-xs">{step.description}</div>
                      </div>
                      {step.completed ? (
                        <div className="w-6 h-6 rounded-full bg-gradient-to-r from-emerald-500 to-green-500 flex items-center justify-center shadow-lg shadow-emerald-500/40">
                          <span className="text-white text-xs">✓</span>
                        </div>
                      ) : (
                        <div className="w-6 h-6 rounded-full border border-purple-400/60 flex items-center justify-center">
                          <span className="text-purple-300 text-xs font-semibold">{index + 1}</span>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Right Panel - Chat & Preview */}
        <div className="flex-1 flex flex-col">
          {showPreview && generatedArticle ? (
            /* Article Preview */
            <div className="flex-1 p-6 overflow-y-auto">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-4xl mx-auto"
              >
                <div className="bg-white rounded-lg shadow-lg p-8">
                  <div className="prose prose-lg max-w-none">
                    <div className="whitespace-pre-wrap text-gray-800 leading-relaxed">
                      {generatedArticle}
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          ) : (
            /* Chat Interface */
            <>
              {/* Chat Header */}
              <div className="p-4 border-b border-purple-500/30 bg-gradient-to-r from-purple-900/80 via-indigo-900/70 to-purple-900/80 backdrop-blur-md shadow-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-lg font-bold text-purple-50">Makale Asistanı</h2>
                    <p className="text-sm text-purple-300 font-medium">
                      {articleConfig.topic ? `Konu: ${articleConfig.topic}` : 'Makale konusunu belirtin'}
                    </p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge variant="secondary" className="bg-gradient-to-r from-purple-600/40 to-indigo-600/40 text-purple-100 border border-purple-400/30 font-semibold">
                      {articleTypes.find(t => t.value === articleConfig.type)?.label}
                    </Badge>
                    <Badge variant="secondary" className="bg-gradient-to-r from-indigo-600/40 to-violet-600/40 text-indigo-100 border border-indigo-400/30 font-semibold">
                      {toneOptions.find(t => t.value === articleConfig.tone)?.label}
                    </Badge>
                  </div>
                </div>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-6">
                {messages.length === 0 && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center py-12"
                  >
                    <div className="w-20 h-20 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center mx-auto mb-6">
                      <Sparkles size={32} className="text-white" />
                    </div>
                    <h3 className="text-2xl font-bold bg-gradient-to-r from-white via-purple-100 to-purple-200 bg-clip-text text-transparent mb-4">Makale Oluşturmaya Başlayın!</h3>
                    <p className="text-purple-300 max-w-md mx-auto mb-6 font-medium">
                      Sol panelden makale ayarlarınızı yapın ve AI asistanından yardım isteyin.
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl mx-auto">
                      <div className="p-4 bg-gradient-to-br from-purple-900/60 to-indigo-900/60 rounded-lg border border-purple-500/40 hover:border-purple-400/60 transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/30">
                        <Lightbulb className="text-yellow-500 mb-2" size={24} />
                        <h4 className="text-purple-50 font-bold mb-1">Konu Önerileri</h4>
                        <p className="text-purple-300 text-sm">AI'dan makale konusu önerileri alın</p>
                      </div>
                      <div className="p-4 bg-gradient-to-br from-purple-900/60 to-indigo-900/60 rounded-lg border border-purple-500/40 hover:border-purple-400/60 transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/30">
                        <Target className="text-green-500 mb-2" size={24} />
                        <h4 className="text-purple-50 font-bold mb-1">Hedef Kitle</h4>
                        <p className="text-purple-300 text-sm">Doğru hedef kitle belirleme</p>
                      </div>
                      <div className="p-4 bg-gradient-to-br from-purple-900/60 to-indigo-900/60 rounded-lg border border-purple-500/40 hover:border-purple-400/60 transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/30">
                        <Hash className="text-blue-500 mb-2" size={24} />
                        <h4 className="text-purple-50 font-bold mb-1">SEO Optimizasyonu</h4>
                        <p className="text-purple-300 text-sm">Anahtar kelime önerileri</p>
                      </div>
                      <div className="p-4 bg-gradient-to-br from-purple-900/60 to-indigo-900/60 rounded-lg border border-purple-500/40 hover:border-purple-400/60 transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/30">
                        <BookOpen className="text-purple-500 mb-2" size={24} />
                        <h4 className="text-purple-50 font-bold mb-1">İçerik Yapısı</h4>
                        <p className="text-purple-300 text-sm">Etkili makale yapısı</p>
                      </div>
                    </div>
                  </motion.div>
                )}

                <AnimatePresence>
                  {messages.map((message) => (
                    <motion.div
                      key={message.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3 }}
                      className={cn(
                        "flex",
                        message.role === 'user' ? "justify-end" : "justify-start"
                      )}
                    >
                      <div
                        className={cn(
                          "max-w-3xl rounded-2xl p-4 shadow-lg flex items-start space-x-3",
                          message.role === 'user'
                            ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white ml-12 flex-row-reverse space-x-reverse"
                            : "bg-gray-800/80 backdrop-blur-sm text-gray-100 mr-12 border border-purple-500/20"
                        )}
                      >
                        <div className={cn(
                          "w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0",
                          message.role === 'user'
                            ? "bg-white/20"
                            : "bg-purple-600"
                        )}>
                          {message.role === 'user' ? (
                            <User size={16} className="text-white" />
                          ) : (
                            <Bot size={16} className="text-white" />
                          )}
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className={cn(
                            "text-xs font-medium mb-1",
                            message.role === 'user' ? "text-purple-200" : "text-purple-300"
                          )}>
                            {message.role === 'user' ? 'Siz' : 'Makale Asistanı'}
                          </div>
                          <p className="whitespace-pre-wrap leading-relaxed text-sm">{message.content}</p>
                          <div className="flex items-center justify-between mt-2">
                            <div className={cn(
                              "text-xs opacity-60",
                              message.role === 'user' ? "text-purple-200" : "text-gray-400"
                            )}>
                              {new Date(message.timestamp).toLocaleTimeString('tr-TR')}
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                navigator.clipboard.writeText(message.content);
                                toast({ title: "Kopyalandı" });
                              }}
                              className="opacity-60 hover:opacity-100 p-1 h-auto"
                            >
                              <Copy size={12} />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>

                {/* Typing Indicator */}
                <AnimatePresence>
                  {isLoading && (
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      className="flex justify-start"
                    >
                      <div className="max-w-3xl rounded-2xl p-4 bg-gray-800/80 backdrop-blur-sm border border-purple-500/20 mr-12 flex items-start space-x-3">
                        <div className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center flex-shrink-0">
                          <Bot size={16} className="text-white" />
                        </div>
                        
                        <div className="flex-1">
                          <div className="text-xs font-medium mb-1 text-purple-300">Makale Asistanı</div>
                          <div className="flex items-center space-x-2">
                            <div className="flex space-x-1">
                              <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce"></div>
                              <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                              <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                            </div>
                            <span className="text-gray-400 text-sm">Makale içeriği hazırlanıyor...</span>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                <div ref={messagesEndRef} />
              </div>

              {/* Input Area */}
              <div className="p-4 border-t border-gray-700/50 bg-gray-800/50 backdrop-blur-sm">
                <div className="max-w-4xl mx-auto">
                  <div className="relative">
                    <Textarea
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      onKeyPress={handleKeyPress}
                      placeholder="Makale hakkında soru sorun veya yardım isteyin..."
                      className="min-h-[60px] pr-12 resize-none bg-gray-900 border-gray-600 focus:border-purple-500 text-white placeholder-gray-400"
                      disabled={isLoading}
                    />
                    <Button
                      onClick={sendMessage}
                      disabled={!input.trim() || isLoading}
                      size="icon"
                      className="absolute right-2 bottom-2 w-8 h-8 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500"
                    >
                      <Send size={16} />
                    </Button>
                  </div>
                  
                  <div className="flex justify-between items-center mt-2 text-xs text-gray-500">
                    <span>Makale asistanı ile konuşuyorsunuz</span>
                    {!isPremium && (
                      <Button
                        variant="link"
                        size="sm"
                        className="text-purple-400 hover:text-purple-300 p-0 h-auto"
                      >
                        Premium'a geç
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}