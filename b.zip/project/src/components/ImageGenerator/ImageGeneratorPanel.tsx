import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ImageIcon, 
  Wand2, 
  Download, 
  Copy, 
  Heart, 
  Share2,
  Sparkles,
  Palette,
  Camera,
  Brush,
  Zap,
  Star,
  Grid3X3,
  Settings,
  Play,
  RefreshCw,
  Eye,
  Trash2,
  Plus
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

const imageStyles = [
  { id: 'realistic', name: 'Gerçekçi', description: 'Fotoğraf kalitesinde görüntüler' },
  { id: 'artistic', name: 'Sanatsal', description: 'Yaratıcı ve artistik tarzda' },
  { id: 'minimalist', name: 'Minimalist', description: 'Sade ve temiz tasarım' },
  { id: 'vintage', name: 'Vintage', description: 'Nostaljik ve retro tarz' },
  { id: 'modern', name: 'Modern', description: 'Çağdaş ve şık tasarım' },
  { id: 'abstract', name: 'Soyut', description: 'Soyut ve kavramsal sanat' }
];

const imageSizes = [
  { id: 'square', name: 'Kare (1:1)', width: 1024, height: 1024 },
  { id: 'portrait', name: 'Dikey (9:16)', width: 768, height: 1344 },
  { id: 'landscape', name: 'Yatay (16:9)', width: 1344, height: 768 },
  { id: 'wide', name: 'Geniş (21:9)', width: 1536, height: 640 }
];

const qualityLevels = [
  { id: 'standard', name: 'Standart', description: 'Hızlı oluşturma' },
  { id: 'hd', name: 'HD', description: 'Yüksek kalite' },
  { id: 'ultra', name: 'Ultra HD', description: 'En yüksek kalite (Premium)' }
];

const templateCategories = [
  {
    id: 'logo',
    name: 'Logo Tasarımı',
    icon: '🎨',
    color: 'from-pink-500 to-rose-500',
    templates: [
      'Minimalist şirket logosu',
      'Modern teknoloji logosu',
      'Yaratıcı marka logosu'
    ]
  },
  {
    id: 'social',
    name: 'Sosyal Medya Görseli',
    icon: '📱',
    color: 'from-blue-500 to-indigo-500',
    templates: [
      'Instagram post tasarımı',
      'Facebook kapak fotoğrafı',
      'Twitter banner tasarımı'
    ]
  },
  {
    id: 'web',
    name: 'Web Banner',
    icon: '🌐',
    color: 'from-green-500 to-emerald-500',
    templates: [
      'Website hero banner',
      'E-ticaret banner',
      'Blog başlık görseli'
    ]
  },
  {
    id: 'product',
    name: 'Ürün Görseli',
    icon: '📦',
    color: 'from-purple-500 to-violet-500',
    templates: [
      'Ürün tanıtım görseli',
      'E-ticaret ürün fotoğrafı',
      'Katalog görseli'
    ]
  },
  {
    id: 'illustration',
    name: 'İllüstrasyon',
    icon: '🎭',
    color: 'from-orange-500 to-red-500',
    templates: [
      'Karakter illüstrasyonu',
      'Konsept sanatı',
      'Dijital resim'
    ]
  },
  {
    id: 'design',
    name: 'Arka Plan Tasarımı',
    icon: '🎪',
    color: 'from-teal-500 to-cyan-500',
    templates: [
      'Gradient arka plan',
      'Geometrik desen',
      'Doğa temalı arka plan'
    ]
  }
];

interface GeneratedImage {
  id: string;
  url: string;
  prompt: string;
  style: string;
  size: string;
  timestamp: string;
  liked: boolean;
}

export function ImageGeneratorPanel() {
  const [prompt, setPrompt] = useState('');
  const [selectedStyle, setSelectedStyle] = useState('realistic');
  const [selectedSize, setSelectedSize] = useState('square');
  const [selectedQuality, setSelectedQuality] = useState('standard');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImages, setGeneratedImages] = useState<GeneratedImage[]>([]);
  const [activeTab, setActiveTab] = useState('generate');
  const { user } = useAuth();
  const isPremium = user?.role === 'premium';

  const generateImage = async () => {
    if (!prompt.trim()) {
      toast({
        title: "Prompt Gerekli",
        description: "Lütfen oluşturmak istediğiniz görseli açıklayın.",
        variant: "destructive"
      });
      return;
    }

    if (selectedQuality === 'ultra' && !isPremium) {
      toast({
        title: "Premium Gerekli",
        description: "Ultra HD kalite Premium üyelik gerektirir.",
        variant: "destructive"
      });
      return;
    }

    setIsGenerating(true);

    try {
      // Simulate image generation
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      const newImage: GeneratedImage = {
        id: `img_${Date.now()}`,
        url: `https://picsum.photos/${imageSizes.find(s => s.id === selectedSize)?.width}/${imageSizes.find(s => s.id === selectedSize)?.height}?random=${Date.now()}`,
        prompt: prompt,
        style: selectedStyle,
        size: selectedSize,
        timestamp: new Date().toISOString(),
        liked: false
      };

      setGeneratedImages(prev => [newImage, ...prev]);
      
      toast({
        title: "Görsel Oluşturuldu!",
        description: "Yeni görseliniz başarıyla oluşturuldu."
      });

    } catch (error) {
      toast({
        title: "Hata",
        description: "Görsel oluşturulurken bir hata oluştu.",
        variant: "destructive"
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const useTemplate = (template: string) => {
    setPrompt(template);
    toast({
      title: "Şablon Uygulandı",
      description: "Şablon prompt alanına eklendi."
    });
  };

  const toggleLike = (imageId: string) => {
    setGeneratedImages(prev => 
      prev.map(img => 
        img.id === imageId ? { ...img, liked: !img.liked } : img
      )
    );
  };

  const downloadImage = (imageUrl: string, prompt: string) => {
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = `ai-generated-${prompt.slice(0, 20).replace(/\s+/g, '-')}.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: "İndiriliyor",
      description: "Görsel indirme başlatıldı."
    });
  };

  return (
    <div className="flex-1 bg-gradient-to-br from-purple-950 via-indigo-950 to-slate-950 h-full overflow-hidden">
      <div className="flex h-full">
        {/* Left Panel - Controls */}
        <div className="w-80 bg-gradient-to-b from-purple-900/95 via-indigo-900/90 to-purple-950/95 backdrop-blur-xl border-r border-purple-400/30 p-6 overflow-y-auto shadow-2xl shadow-purple-900/50">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            {/* Header */}
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-gradient-to-r from-purple-500 via-pink-500 to-indigo-500 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-purple-500/40">
                <ImageIcon size={24} className="text-white" />
              </div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-white via-purple-100 to-pink-100 bg-clip-text text-transparent">AI Görsel Oluşturucu</h1>
              <p className="text-purple-300 text-sm font-medium">Hayal gücünüzü serbest bırakın</p>
            </div>

            {/* Style Selection */}
            <Card className="bg-gradient-to-br from-purple-900/90 via-indigo-900/80 to-purple-950/90 border-purple-400/40 backdrop-blur-md shadow-xl shadow-purple-900/40">
              <CardHeader>
                <CardTitle className="text-purple-50 text-lg flex items-center font-bold">
                  <Palette size={18} className="mr-2" />
                  Stil Seçimi
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  {imageStyles.map((style) => (
                    <Button
                      key={style.id}
                      variant={selectedStyle === style.id ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedStyle(style.id)}
                      className={cn(
                        "text-xs h-auto p-4 flex flex-col items-center space-y-2 min-h-[80px] w-full",
                        selectedStyle === style.id 
                          ? "bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold shadow-lg shadow-purple-500/40" 
                          : "bg-purple-950/80 border-purple-600/50 text-purple-200 hover:bg-purple-800/60 hover:border-purple-500/70"
                      )}
                    >
                      <span className="font-bold text-center text-sm">{style.name}</span>
                      <span className="text-center leading-tight opacity-90 text-[11px] px-1">{style.description}</span>
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Size and Quality */}
            <Card className="bg-gradient-to-br from-purple-900/90 via-indigo-900/80 to-purple-950/90 border-purple-400/40 backdrop-blur-md shadow-xl shadow-purple-900/40">
              <CardHeader>
                <CardTitle className="text-purple-50 text-lg flex items-center font-bold">
                  <Settings size={18} className="mr-2" />
                  Boyut & Kalite
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-purple-100 text-sm font-semibold mb-2 block">Boyut</label>
                  <Select value={selectedSize} onValueChange={setSelectedSize}>
                    <SelectTrigger className="bg-purple-950/80 border-purple-600/60 text-purple-50 hover:border-purple-400/80">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-purple-950 border-purple-600/60">
                      {imageSizes.map((size) => (
                        <SelectItem key={size.id} value={size.id} className="text-purple-50 hover:bg-purple-900/70">
                          {size.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-purple-100 text-sm font-semibold mb-2 block">Kalite</label>
                  <Select value={selectedQuality} onValueChange={setSelectedQuality}>
                    <SelectTrigger className="bg-purple-950/80 border-purple-600/60 text-purple-50 hover:border-purple-400/80">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-purple-950 border-purple-600/60">
                      {qualityLevels.map((quality) => (
                        <SelectItem 
                          key={quality.id} 
                          value={quality.id} 
                          disabled={quality.id === 'ultra' && !isPremium}
                          className="text-purple-50 hover:bg-purple-900/70"
                        >
                          <div>
                            <div className="font-semibold">{quality.name}</div>
                            <div className="text-xs text-purple-300">{quality.description}</div>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <div className="space-y-3">
              <Button
                onClick={generateImage}
                disabled={isGenerating || !prompt.trim()}
                className="w-full bg-gradient-to-r from-purple-600 via-pink-600 to-indigo-600 hover:from-purple-500 hover:via-pink-500 hover:to-indigo-500 text-white font-bold shadow-xl shadow-purple-500/50 hover:shadow-purple-400/60 transition-all duration-300"
              >
                <Wand2 size={16} className="mr-2" />
                {isGenerating ? 'Oluşturuluyor...' : 'Görsel Oluştur'}
              </Button>

              {!isPremium && (
                <div className="text-center text-xs text-purple-400 bg-purple-950/50 p-2 rounded-lg border border-purple-600/30">
                  Premium ile sınırsız görsel oluşturun
                </div>
              )}
            </div>
          </motion.div>
        </div>

        {/* Right Panel - Main Content */}
        <div className="flex-1 flex flex-col">
          {/* Header */}
          <div className="p-4 border-b border-purple-500/30 bg-gradient-to-r from-purple-900/80 via-indigo-900/70 to-purple-900/80 backdrop-blur-md shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-purple-50">AI Görsel Oluşturucu</h2>
                <p className="text-sm text-purple-300 font-medium">
                  MORTANAS ile büyüleyici görseller yaratın ✨
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <Button
                  variant={activeTab === 'generate' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setActiveTab('generate')}
                  className={cn(
                    activeTab === 'generate' 
                      ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white" 
                      : "border-purple-600/60 text-purple-200 hover:bg-purple-800/60"
                  )}
                >
                  <Sparkles size={16} className="mr-2" />
                  Görsel Oluştur
                </Button>
                <Button
                  variant={activeTab === 'gallery' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setActiveTab('gallery')}
                  className={cn(
                    activeTab === 'gallery' 
                      ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white" 
                      : "border-purple-600/60 text-purple-200 hover:bg-purple-800/60"
                  )}
                >
                  <Grid3X3 size={16} className="mr-2" />
                  Galeri ({generatedImages.length})
                </Button>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto">
            {activeTab === 'generate' ? (
              <div className="p-6 space-y-6">
                {/* Prompt Input */}
                <Card className="bg-gradient-to-br from-purple-950/90 to-indigo-950/90 border-purple-500/50 backdrop-blur-md shadow-xl shadow-purple-900/60">
                  <CardHeader>
                    <CardTitle className="text-purple-50 text-xl flex items-center font-bold">
                      <Brush size={20} className="mr-2" />
                      Görsel Açıklaması
                    </CardTitle>
                    <CardDescription className="text-purple-200 font-semibold">
                      Oluşturmak istediğiniz görseli detaylı olarak açıklayın
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Textarea
                      value={prompt}
                      onChange={(e) => setPrompt(e.target.value)}
                      placeholder="Hayal gücünüzü serbest bırakın ve büyüleyici görseller yaratın! ✨"
                      className="min-h-[120px] bg-purple-950/80 border-purple-600/60 text-purple-50 placeholder-purple-300/70 focus:border-purple-400 focus:ring-purple-400/30 text-base leading-relaxed"
                    />
                    <div className="flex justify-between items-center mt-3 text-sm">
                      <span className="text-purple-200 font-semibold">
                        Hızlı İlham: {prompt.length > 0 ? `${prompt.length} karakter` : 'Detaylı açıklama daha iyi sonuç verir'}
                      </span>
                      <div className="flex items-center space-x-2">
                        <Badge variant="secondary" className="bg-purple-600/50 text-white font-bold">
                          {imageStyles.find(s => s.id === selectedStyle)?.name}
                        </Badge>
                        <Badge variant="secondary" className="bg-indigo-600/50 text-white font-bold">
                          {imageSizes.find(s => s.id === selectedSize)?.name}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Quick Prompts */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card className="bg-gradient-to-br from-purple-950/90 to-indigo-950/90 border-purple-500/50 backdrop-blur-md shadow-xl shadow-purple-900/60">
                    <CardHeader>
                      <CardTitle className="text-white text-lg flex items-center font-black">
                        <Zap size={18} className="mr-2" />
                        Hızlı İlham
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      {[
                        'Futuristik şehir manzarası, neon ışıklar, gece',
                        'Minimalist logo tasarımı, modern, temiz çizgiler',
                        'Fantastik orman, büyülü yaratıklar, mistik atmosfer'
                      ].map((quickPrompt, index) => (
                        <Button
                          key={index}
                          variant="ghost"
                          size="sm"
                          onClick={() => setPrompt(quickPrompt)}
                          className="w-full text-left justify-start bg-purple-950/80 border border-purple-500/60 text-white hover:bg-purple-800/80 hover:border-purple-400/80 text-xs font-semibold transition-all duration-300"
                        >
                          <Play size={12} className="mr-2" />
                          {quickPrompt}
                        </Button>
                      ))}
                    </CardContent>
                  </Card>

                  {/* Generation Preview */}
                  <Card className="bg-gradient-to-br from-purple-950/90 to-indigo-950/90 border-purple-500/50 backdrop-blur-md shadow-xl shadow-purple-900/60">
                    <CardHeader>
                      <CardTitle className="text-white text-lg flex items-center font-black">
                        <Eye size={18} className="mr-2" />
                        Önizleme
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      {isGenerating ? (
                        <div className="flex flex-col items-center justify-center py-8 space-y-4">
                          <div className="w-16 h-16 border-4 border-purple-500/30 border-t-purple-500 rounded-full animate-spin"></div>
                          <div className="text-center">
                            <p className="text-white font-black">Görsel Oluşturuluyor...</p>
                            <p className="text-purple-100 text-sm font-bold">Bu işlem birkaç saniye sürebilir</p>
                          </div>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center justify-center py-8 space-y-4 border-2 border-dashed border-purple-400/50 rounded-lg bg-purple-950/30">
                          <ImageIcon size={48} className="text-purple-300" />
                          <div className="text-center">
                            <p className="text-white font-black">İlk Görselinizi Oluşturun</p>
                            <p className="text-purple-100 text-sm font-bold">Hayal gücünüzü serbest bırakın ve büyüleyici görseller yaratın!</p>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>

                {/* Templates */}
                <Card className="bg-gradient-to-br from-purple-950/90 to-indigo-950/90 border-purple-500/50 backdrop-blur-md shadow-xl shadow-purple-900/60">
                  <CardHeader>
                    <CardTitle className="text-white text-xl flex items-center font-black">
                      <Star size={20} className="mr-2" />
                      Şablonlar
                    </CardTitle>
                    <CardDescription className="text-purple-100 font-bold">
                      Hazır şablonlarla hızlıca başlayın
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {templateCategories.map((category) => (
                        <div
                          key={category.id}
                          className="p-4 bg-purple-950/90 hover:bg-purple-900/90 border border-purple-600/60 hover:border-purple-500/80 rounded-lg cursor-pointer transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/50"
                        >
                          <div className="flex items-start justify-between mb-3">
                            <div className="flex-1">
                              <h4 className="text-white font-black text-sm mb-1">{category.name}</h4>
                              <div className="space-y-1">
                                {category.templates.map((template, index) => (
                                  <Button
                                    key={index}
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => useTemplate(template)}
                                    className="w-full text-left justify-start text-xs text-purple-100 hover:text-white hover:bg-purple-800/70 p-1 h-auto font-semibold"
                                  >
                                    {template}
                                  </Button>
                                ))}
                              </div>
                            </div>
                            <div className={cn(
                              "w-10 h-10 rounded-lg flex items-center justify-center text-lg ml-3",
                              `bg-gradient-to-r ${category.color}`
                            )}>
                              {category.icon}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            ) : (
              /* Gallery View */
              <div className="p-6">
                {generatedImages.length === 0 ? (
                  <div className="text-center py-12">
                    <div className="w-20 h-20 rounded-full bg-gradient-to-r from-purple-500 via-pink-500 to-indigo-500 flex items-center justify-center mx-auto mb-6 shadow-lg shadow-purple-500/40">
                      <ImageIcon size={32} className="text-white" />
                    </div>
                    <h3 className="text-2xl font-black bg-gradient-to-r from-white via-purple-100 to-pink-100 bg-clip-text text-transparent mb-4">
                      İlk Görselinizi Oluşturun!
                    </h3>
                    <p className="text-purple-100 max-w-md mx-auto mb-6 font-bold">
                      Henüz hiç görsel oluşturmadınız. Hayal gücünüzü serbest bırakın ve büyüleyici görseller yaratmaya başlayın!
                    </p>
                    <Button
                      onClick={() => setActiveTab('generate')}
                      className="bg-gradient-to-r from-purple-600 via-pink-600 to-indigo-600 hover:from-purple-500 hover:via-pink-500 hover:to-indigo-500"
                    >
                      <Plus size={16} className="mr-2" />
                      İlk Görselimi Oluştur
                    </Button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {generatedImages.map((image) => (
                      <motion.div
                        key={image.id}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="group"
                      >
                        <Card className="bg-gradient-to-br from-purple-900/60 to-indigo-900/60 border-purple-400/40 backdrop-blur-md shadow-xl shadow-purple-900/40 overflow-hidden">
                          <div className="relative">
                            <img
                              src={image.url}
                              alt={image.prompt}
                              className="w-full h-48 object-cover"
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                              <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between">
                                <div className="flex items-center space-x-2">
                                  <Button
                                    size="sm"
                                    variant="secondary"
                                    onClick={() => toggleLike(image.id)}
                                    className="bg-white/20 backdrop-blur-sm border-0 hover:bg-white/30"
                                  >
                                    <Heart size={14} fill={image.liked ? 'currentColor' : 'none'} className={image.liked ? 'text-red-400' : 'text-white'} />
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="secondary"
                                    onClick={() => downloadImage(image.url, image.prompt)}
                                    className="bg-white/20 backdrop-blur-sm border-0 hover:bg-white/30 text-white"
                                  >
                                    <Download size={14} />
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="secondary"
                                    className="bg-white/20 backdrop-blur-sm border-0 hover:bg-white/30 text-white"
                                  >
                                    <Share2 size={14} />
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </div>
                          <CardContent className="p-4">
                            <p className="text-white text-sm font-bold mb-2 line-clamp-2">
                              {image.prompt}
                            </p>
                            <div className="flex items-center justify-between text-xs">
                              <div className="flex items-center space-x-2">
                                <Badge variant="secondary" className="bg-purple-600/50 text-white font-bold">
                                  {imageStyles.find(s => s.id === image.style)?.name}
                                </Badge>
                                <Badge variant="secondary" className="bg-indigo-600/50 text-white font-bold">
                                  {imageSizes.find(s => s.id === image.size)?.name}
                                </Badge>
                              </div>
                              <span className="text-purple-200 font-semibold">
                                {new Date(image.timestamp).toLocaleDateString('tr-TR')}
                              </span>
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}