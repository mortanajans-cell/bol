import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Check, Crown, Star, Zap, Shield, Infinity } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';

const plans = [
  {
    id: 'free',
    name: 'Free',
    price: 0,
    yearlyPrice: 0,
    description: 'Temel özelliklerle başlayın',
    color: 'from-gray-600 to-gray-700',
    features: [
      { name: '50 mesaj/ay', included: true },
      { name: 'Son 5 konuşma', included: true },
      { name: 'Temel ayarlar', included: true },
      { name: 'Sınırlı şablonlar', included: true },
      { name: 'Max 1024 token yanıt', included: true },
      { name: 'Sınırsız mesaj', included: false },
      { name: 'Konuşma klasörleme', included: false },
      { name: 'Gelişmiş ayarlar', included: false },
      { name: 'Tüm şablon kategorileri', included: false },
      { name: 'Max 4096+ token yanıt', included: false },
    ],
    popular: false,
  },
  {
    id: 'premium',
    name: 'Premium',
    price: 9.99,
    yearlyPrice: 89.99,
    description: 'Tüm özelliklere tam erişim',
    color: 'from-purple-600 to-indigo-600',
    features: [
      { name: 'Sınırsız mesaj', included: true },
      { name: 'Sınırsız konuşma geçmişi', included: true },
      { name: 'Konuşma klasörleme', included: true },
      { name: 'Gelişmiş ayarlar', included: true },
      { name: 'Tüm şablon kategorileri', included: true },
      { name: 'Max 4096+ token yanıt', included: true },
      { name: 'Öncelikli destek', included: true },
      { name: 'Özel şablon oluşturma', included: true },
      { name: 'API erişimi', included: true },
      { name: 'Gelişmiş analizler', included: true },
    ],
    popular: true,
  },
];

export function PaymentsPanel() {
  const [isYearly, setIsYearly] = useState(false);
  const { user } = useAuth();
  const currentPlan = user?.plan || 'free';

  const handleSubscribe = (planId: string) => {
    if (planId === 'free') {
      toast({
        title: "Ücretsiz Plan",
        description: "Zaten ücretsiz planı kullanıyorsunuz.",
      });
      return;
    }

    // In a real app, this would integrate with Stripe
    toast({
      title: "Ödeme Sayfası",
      description: "Stripe ödeme sayfasına yönlendiriliyorsunuz...",
    });
    
    // Simulate Stripe checkout
    setTimeout(() => {
      toast({
        title: "Ödeme Başarılı!",
        description: "Premium planına başarıyla geçiş yaptınız.",
      });
    }, 2000);
  };

  return (
    <div className="flex-1 p-6 bg-gradient-to-b from-gray-900 to-black h-full overflow-y-auto">
      <div className="max-w-6xl mx-auto space-y-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-4"
        >
          <h1 className="text-4xl font-bold text-white">Planlar ve Fiyatlandırma</h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            İhtiyaçlarınıza uygun planı seçin ve AI Portal'ın tüm gücünden yararlanın
          </p>
          
          {/* Billing Toggle */}
          <div className="flex items-center justify-center space-x-4 mt-8">
            <span className={`text-sm ${!isYearly ? 'text-white' : 'text-gray-400'}`}>
              Aylık
            </span>
            <Switch
              checked={isYearly}
              onCheckedChange={setIsYearly}
              className="data-[state=checked]:bg-purple-600"
            />
            <span className={`text-sm ${isYearly ? 'text-white' : 'text-gray-400'}`}>
              Yıllık
            </span>
            <Badge className="bg-green-600 text-white">%25 İndirim</Badge>
          </div>
        </motion.div>

        {/* Plans */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="relative"
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-10">
                  <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-black font-semibold px-4 py-1">
                    <Star size={14} className="mr-1" />
                    En Popüler
                  </Badge>
                </div>
              )}
              
              <Card className={`relative overflow-hidden ${plan.popular ? 'ring-2 ring-purple-500' : ''} bg-gray-800/50 border-gray-700 hover:border-purple-500/50 transition-all duration-300`}>
                {plan.popular && (
                  <div className="absolute inset-0 bg-gradient-to-r from-purple-600/10 to-indigo-600/10" />
                )}
                
                <CardHeader className="relative">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-2xl font-bold text-white flex items-center">
                      {plan.name}
                      {plan.id === 'premium' && <Crown size={24} className="ml-2 text-yellow-500" />}
                    </CardTitle>
                    {currentPlan.includes(plan.id) && (
                      <Badge className="bg-green-600 text-white">
                        Mevcut Plan
                      </Badge>
                    )}
                  </div>
                  
                  <CardDescription className="text-gray-400">
                    {plan.description}
                  </CardDescription>
                  
                  <div className="flex items-baseline space-x-2 mt-4">
                    <span className="text-4xl font-bold text-white">
                      ${isYearly ? plan.yearlyPrice : plan.price}
                    </span>
                    <span className="text-gray-400">
                      /{isYearly ? 'yıl' : 'ay'}
                    </span>
                    {isYearly && plan.id === 'premium' && (
                      <span className="text-sm text-green-400 ml-2">
                        $29.89 tasarruf
                      </span>
                    )}
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-6">
                  <Button
                    onClick={() => handleSubscribe(plan.id)}
                    disabled={currentPlan.includes(plan.id)}
                    className={`w-full ${
                      plan.id === 'premium'
                        ? 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500'
                        : 'bg-gray-600 hover:bg-gray-500'
                    } transition-all duration-200`}
                  >
                    {currentPlan.includes(plan.id) ? 'Mevcut Plan' : 
                     plan.id === 'free' ? 'Ücretsiz Başla' : 'Premium\'a Geç'}
                  </Button>
                  
                  <Separator className="bg-gray-600" />
                  
                  <div className="space-y-3">
                    <h4 className="font-semibold text-white">Özellikler:</h4>
                    {plan.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="flex items-center space-x-3">
                        {feature.included ? (
                          <Check size={16} className="text-green-400 flex-shrink-0" />
                        ) : (
                          <div className="w-4 h-4 rounded-full border border-gray-600 flex-shrink-0" />
                        )}
                        <span className={`text-sm ${
                          feature.included ? 'text-white' : 'text-gray-500'
                        }`}>
                          {feature.name}
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Feature Comparison */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="space-y-6"
        >
          <h2 className="text-2xl font-bold text-white text-center">Özellik Karşılaştırması</h2>
          
          <Card className="bg-gray-800/50 border-gray-700">
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Zap className="text-blue-400" size={20} />
                    <h3 className="text-lg font-semibold text-white">Performans</h3>
                  </div>
                  <div className="space-y-2 text-sm text-gray-400">
                    <p>• Free: Temel yanıt hızı</p>
                    <p>• Premium: Öncelikli işleme</p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Shield className="text-green-400" size={20} />
                    <h3 className="text-lg font-semibold text-white">Güvenlik</h3>
                  </div>
                  <div className="space-y-2 text-sm text-gray-400">
                    <p>• Tüm planlar: End-to-end şifreleme</p>
                    <p>• Premium: Gelişmiş güvenlik</p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Infinity className="text-purple-400" size={20} />
                    <h3 className="text-lg font-semibold text-white">Limits</h3>
                  </div>
                  <div className="space-y-2 text-sm text-gray-400">
                    <p>• Free: Aylık limitler</p>
                    <p>• Premium: Sınırsız kullanım</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* FAQ */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="space-y-6"
        >
          <h2 className="text-2xl font-bold text-white text-center">Sık Sorulan Sorular</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">İptal edebilir miyim?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-400">
                  Evet, istediğiniz zaman iptal edebilirsiniz. Abonelik süreniz bitene kadar tüm özellikleri kullanmaya devam edebilirsiniz.
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Ödeme güvenli mi?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-400">
                  Tüm ödemeler Stripe üzerinden güvenli bir şekilde işlenir. Kredi kartı bilgileriniz şifrelenir ve saklanmaz.
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Plan değiştirebilir miyim?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-400">
                  Evet, istediğiniz zaman planınızı yükseltebilir veya düşürebilirsiniz. Değişiklik anında geçerli olur.
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Destek alabilir miyim?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-400">
                  Free kullanıcılar e-posta desteği, Premium kullanıcılar öncelikli destek ve canlı chat erişimi alır.
                </p>
              </CardContent>
            </Card>
          </div>
        </motion.div>
      </div>
    </div>
  );
}