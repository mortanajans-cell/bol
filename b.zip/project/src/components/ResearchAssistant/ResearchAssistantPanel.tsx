import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Search, 
  BookOpen, 
  BarChart3, 
  Microscope, 
  TrendingUp,
  FileText,
  Users,
  Globe,
  Database,
  Brain,
  Target,
  Zap,
  Star,
  Award,
  Lightbulb,
  Filter,
  Download,
  Share2,
  Copy,
  Eye,
  Send,
  User,
  Bot,
  Settings,
  CheckCircle,
  AlertCircle,
  Clock,
  Bookmark
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useApp } from '@/contexts/AppContext';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

const researchCategories = [
  {
    id: 'academic',
    title: 'Akademik Kaynak Bulma',
    icon: BookOpen,
    color: 'from-purple-600 to-indigo-600',
    description: 'Güvenilir akademik kaynaklar, bilimsel yayınlar ve referans materyalleri',
    features: [
      'Makale ve dergi taraması',
      'Atıf analizi',
      'Kaynak doğrulama',
      'Bibliyografya oluşturma'
    ],
    emoji: '📚'
  },
  {
    id: 'market',
    title: 'Pazar Araştırması',
    icon: BarChart3,
    color: 'from-indigo-600 to-blue-600',
    description: 'Sektör analizi, rekabet incelemesi ve pazar trendleri',
    features: [
      'Sektör raporları',
      'Rakip analizi',
      'Tüketici davranışları',
      'Pazar boyutu hesaplama'
    ],
    emoji: '📊'
  },
  {
    id: 'scientific',
    title: 'Bilimsel Makale Analizi',
    icon: Microscope,
    color: 'from-blue-600 to-cyan-600',
    description: 'Detaylı makale inceleme, özet çıkarma ve kritik değerlendirme',
    features: [
      'Makale özetleme',
      'Metodoloji analizi',
      'Sonuç değerlendirmesi',
      'Karşılaştırmalı analiz'
    ],
    emoji: '🔬'
  },
  {
    id: 'trends',
    title: 'Trend Analizi',
    icon: TrendingUp,
    color: 'from-cyan-600 to-teal-600',
    description: 'Güncel trendler, gelişmekte olan konular ve gelecek öngörüleri',
    features: [
      'Trend belirleme',
      'Veri görselleştirme',
      'Öngörü modelleme',
      'Rapor oluşturma'
    ],
    emoji: '📈'
  }
];

const quickResearchTopics = [
  {
    category: 'academic',
    title: 'Yapay Zeka Etiği',
    description: 'AI etiği konusunda güncel akademik kaynaklar'
  },
  {
    category: 'market',
    title: 'E-ticaret Trendleri 2024',
    description: 'Online alışveriş sektörü analizi'
  },
  {
    category: 'scientific',
    title: 'İklim Değişikliği Araştırmaları',
    description: 'Son bilimsel bulgular ve raporlar'
  },
  {
    category: 'trends',
    title: 'Blockchain Teknolojisi',
    description: 'Kripto ve blockchain trend analizi'
  }
];

export function ResearchAssistantPanel() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [messages, setMessages] = useState<Array<{id: string, role: 'user' | 'assistant', content: string, timestamp: string}>>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('categories');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const { generateAIResponse, settings } = useApp();
  const { user } = useAuth();
  const isPremium = user?.role === 'premium';

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const sendMessage = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setIsLoading(true);

    const userMsgObj = {
      id: `user_${Date.now()}`,
      role: 'user' as const,
      content: userMessage,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMsgObj]);

    try {
      const researchPrompt = `Sen bir araştırma uzmanısın. Kullanıcıların akademik, bilimsel ve pazar araştırmalarında yardımcı oluyorsun.

${selectedCategory ? `Araştırma Kategorisi: ${researchCategories.find(c => c.id === selectedCategory)?.title}` : ''}

Kullanıcı Sorusu: ${userMessage}

Lütfen:
1. Güvenilir kaynak önerileri sun
2. Araştırma metodolojisi öner
3. Anahtar kelimeler ve arama terimleri ver
4. Potansiel veri kaynakları belirt
5. Analiz yaklaşımları öner
6. Pratik adımlar sun

Yanıtını Türkçe ver ve araştırma uzmanı rolünde kal.`;

      const aiResponse = await generateAIResponse(researchPrompt, settings);
      
      const aiMsgObj = {
        id: `ai_${Date.now()}`,
        role: 'assistant' as const,
        content: aiResponse,
        timestamp: new Date().toISOString()
      };

      setMessages(prev => [...prev, aiMsgObj]);

    } catch (error) {
      console.error('Research Assistant Error:', error);
      setMessages(prev => [...prev, {
        id: `error_${Date.now()}`,
        role: 'assistant' as const,
        content: 'Üzgünüm, bir hata oluştu. Lütfen tekrar deneyin.',
        timestamp: new Date().toISOString()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const startResearch = (category: string) => {
    setSelectedCategory(category);
    setActiveTab('research');
    
    const categoryData = researchCategories.find(c => c.id === category);
    toast({
      title: `${categoryData?.emoji} ${categoryData?.title}`,
      description: "Araştırma asistanı hazır! Sorularınızı sorabilirsiniz."
    });
  };

  const useQuickTopic = (topic: typeof quickResearchTopics[0]) => {
    setSelectedCategory(topic.category);
    setInput(`${topic.title} konusunda detaylı araştırma yapmak istiyorum. ${topic.description} hakkında bilgi ver.`);
    setActiveTab('research');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="flex-1 bg-gradient-to-br from-slate-950 via-purple-950 to-indigo-950 h-full overflow-hidden">
      <div className="flex h-full">
        {/* Left Panel - Categories and Tools */}
        <div className="w-80 bg-gradient-to-b from-purple-900/95 via-indigo-900/90 to-purple-950/95 backdrop-blur-xl border-r border-purple-400/30 p-6 overflow-y-auto shadow-2xl shadow-purple-900/50">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            {/* Header */}
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-gradient-to-r from-purple-500 via-indigo-500 to-blue-500 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-purple-500/40">
                <Search size={24} className="text-white" />
              </div>
              <h1 className="text-2xl font-black bg-gradient-to-r from-white via-purple-100 to-indigo-100 bg-clip-text text-transparent">Araştırma Asistanı</h1>
              <p className="text-purple-300 text-sm font-bold">Kapsamlı araştırma araçları ve analiz hizmetleri</p>
            </div>

            {/* Quick Research Topics */}
            <Card className="bg-gradient-to-br from-purple-900/90 via-indigo-900/80 to-purple-950/90 border-purple-400/40 backdrop-blur-md shadow-2xl shadow-purple-900/60">
              <CardHeader>
                <CardTitle className="text-white text-lg flex items-center font-black">
                  <Zap size={18} className="mr-2" />
                  Hızlı Araştırma
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {quickResearchTopics.map((topic, index) => (
                  <Button
                    key={index}
                    variant="ghost"
                    size="sm"
                    onClick={() => useQuickTopic(topic)}
                    className="w-full text-left justify-start bg-purple-950/80 border border-purple-500/60 text-white hover:bg-purple-800/80 hover:border-purple-400/80 text-xs font-semibold transition-all duration-300 h-auto p-3"
                  >
                    <div className="flex items-start space-x-2">
                      <span className="text-lg">{researchCategories.find(c => c.id === topic.category)?.emoji}</span>
                      <div className="flex-1">
                        <div className="font-bold text-white">{topic.title}</div>
                        <div className="text-purple-200 text-xs mt-1">{topic.description}</div>
                      </div>
                    </div>
                  </Button>
                ))}
              </CardContent>
            </Card>

            {/* Research Tools */}
            <Card className="bg-gradient-to-br from-purple-900/90 via-indigo-900/80 to-purple-950/90 border-purple-400/40 backdrop-blur-md shadow-2xl shadow-purple-900/60">
              <CardHeader>
                <CardTitle className="text-white text-lg flex items-center font-black">
                  <Settings size={18} className="mr-2" />
                  Araştırma Araçları
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-purple-600/60 text-purple-200 hover:bg-purple-800/60 hover:border-purple-500/70 font-bold text-xs h-auto p-3 flex flex-col items-center space-y-1"
                  >
                    <Database size={16} />
                    <span>Veri Analizi</span>
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-purple-600/60 text-purple-200 hover:bg-purple-800/60 hover:border-purple-500/70 font-bold text-xs h-auto p-3 flex flex-col items-center space-y-1"
                  >
                    <FileText size={16} />
                    <span>Rapor Oluştur</span>
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-purple-600/60 text-purple-200 hover:bg-purple-800/60 hover:border-purple-500/70 font-bold text-xs h-auto p-3 flex flex-col items-center space-y-1"
                  >
                    <Globe size={16} />
                    <span>Web Tarama</span>
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-purple-600/60 text-purple-200 hover:bg-purple-800/60 hover:border-purple-500/70 font-bold text-xs h-auto p-3 flex flex-col items-center space-y-1"
                  >
                    <Brain size={16} />
                    <span>AI Analiz</span>
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Research Stats */}
            <Card className="bg-gradient-to-br from-emerald-900/90 via-green-900/80 to-teal-900/90 border-emerald-400/50 backdrop-blur-md shadow-2xl shadow-emerald-900/60">
              <CardHeader>
                <CardTitle className="text-white text-lg flex items-center font-black">
                  <Award size={18} className="mr-2" />
                  Araştırma İstatistikleri
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-emerald-950/80 p-3 rounded-lg border border-emerald-400/30">
                    <div className="text-white font-black text-lg">1,247</div>
                    <div className="text-emerald-100 text-xs font-bold">Kaynak Tarandı</div>
                  </div>
                  <div className="bg-emerald-950/80 p-3 rounded-lg border border-emerald-400/30">
                    <div className="text-white font-black text-lg">89</div>
                    <div className="text-emerald-100 text-xs font-bold">Rapor Oluşturuldu</div>
                  </div>
                  <div className="bg-emerald-950/80 p-3 rounded-lg border border-emerald-400/30">
                    <div className="text-white font-black text-lg">156</div>
                    <div className="text-emerald-100 text-xs font-bold">Trend Analizi</div>
                  </div>
                  <div className="bg-emerald-950/80 p-3 rounded-lg border border-emerald-400/30">
                    <div className="text-white font-black text-lg">98%</div>
                    <div className="text-emerald-100 text-xs font-bold">Doğruluk Oranı</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Right Panel - Main Content */}
        <div className="flex-1 flex flex-col">
          {/* Header */}
          <div className="p-4 border-b border-purple-500/30 bg-gradient-to-r from-purple-900/80 via-indigo-900/70 to-purple-900/80 backdrop-blur-md shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-black text-white">🔍 Araştırma Asistanı</h2>
                <p className="text-sm text-purple-100 font-bold">
                  {selectedCategory 
                    ? `${researchCategories.find(c => c.id === selectedCategory)?.emoji} ${researchCategories.find(c => c.id === selectedCategory)?.title}`
                    : 'Kapsamlı araştırma araçları ve analiz hizmetleri'
                  }
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <Button
                  variant={activeTab === 'categories' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setActiveTab('categories')}
                  className={cn(
                    "font-bold",
                    activeTab === 'categories' 
                      ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white" 
                      : "border-purple-600/60 text-purple-200 hover:bg-purple-800/60"
                  )}
                >
                  <Target size={16} className="mr-2" />
                  Kategoriler
                </Button>
                <Button
                  variant={activeTab === 'research' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setActiveTab('research')}
                  className={cn(
                    "font-bold",
                    activeTab === 'research' 
                      ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white" 
                      : "border-purple-600/60 text-purple-200 hover:bg-purple-800/60"
                  )}
                >
                  <Search size={16} className="mr-2" />
                  Araştırma
                </Button>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto">
            {activeTab === 'categories' ? (
              /* Categories View */
              <div className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-6xl mx-auto">
                  {researchCategories.map((category, index) => (
                    <motion.div
                      key={category.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="group"
                    >
                      <Card className="bg-gradient-to-br from-purple-950/90 to-indigo-950/90 border-purple-500/50 backdrop-blur-md shadow-xl shadow-purple-900/60 hover:shadow-purple-800/80 hover:border-purple-400/70 transition-all duration-300 h-full cursor-pointer"
                           onClick={() => startResearch(category.id)}>
                        <CardHeader className="pb-4">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center space-x-3 mb-3">
                                <div className={cn(
                                  "w-12 h-12 rounded-xl flex items-center justify-center text-2xl shadow-lg",
                                  `bg-gradient-to-r ${category.color}`
                                )}>
                                  {category.emoji}
                                </div>
                                <div>
                                  <CardTitle className="text-white text-xl group-hover:text-purple-200 transition-colors font-black">
                                    {category.title}
                                  </CardTitle>
                                </div>
                              </div>
                              <CardDescription className="text-purple-200 font-bold text-sm leading-relaxed">
                                {category.description}
                              </CardDescription>
                            </div>
                          </div>
                        </CardHeader>
                        
                        <CardContent className="space-y-4">
                          <div className="space-y-2">
                            <h4 className="text-white font-black text-sm">Özellikler:</h4>
                            <div className="grid grid-cols-1 gap-2">
                              {category.features.map((feature, featureIndex) => (
                                <div key={featureIndex} className="flex items-center space-x-2 text-xs">
                                  <CheckCircle size={12} className="text-emerald-400 flex-shrink-0" />
                                  <span className="text-purple-100 font-semibold">{feature}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                          
                          <Button
                            className={cn(
                              "w-full font-black transition-all duration-300",
                              `bg-gradient-to-r ${category.color} hover:opacity-90 shadow-lg hover:shadow-xl`
                            )}
                          >
                            <category.icon size={16} className="mr-2" />
                            Araştırmaya Başla
                          </Button>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>

                {/* Additional Info */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="mt-8 max-w-4xl mx-auto"
                >
                  <Card className="bg-gradient-to-br from-purple-950/90 to-indigo-950/90 border-purple-500/50 backdrop-blur-md shadow-xl shadow-purple-900/60">
                    <CardHeader>
                      <CardTitle className="text-white text-xl flex items-center font-black">
                        <Lightbulb size={20} className="mr-2" />
                        Araştırma İpuçları
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <h4 className="text-white font-black">✨ Etkili Araştırma İçin:</h4>
                          <ul className="space-y-1 text-purple-100 text-sm font-semibold">
                            <li>• Spesifik anahtar kelimeler kullanın</li>
                            <li>• Güvenilir kaynakları tercih edin</li>
                            <li>• Farklı bakış açılarını değerlendirin</li>
                            <li>• Güncel verileri kontrol edin</li>
                          </ul>
                        </div>
                        <div className="space-y-2">
                          <h4 className="text-white font-black">🎯 Premium Özellikler:</h4>
                          <ul className="space-y-1 text-purple-100 text-sm font-semibold">
                            <li>• Sınırsız araştırma sorgusu</li>
                            <li>• Gelişmiş analiz araçları</li>
                            <li>• Özel rapor formatları</li>
                            <li>• Öncelikli destek</li>
                          </ul>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              </div>
            ) : (
              /* Research Chat View */
              <div className="flex-1 flex flex-col">
                {/* Chat Messages */}
                <div className="flex-1 overflow-y-auto p-4 space-y-6">
                  {messages.length === 0 && (
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="text-center py-12"
                    >
                      <div className="w-20 h-20 rounded-full bg-gradient-to-r from-purple-500 via-indigo-500 to-blue-500 flex items-center justify-center mx-auto mb-6 shadow-lg shadow-purple-500/40">
                        <Search size={32} className="text-white" />
                      </div>
                      <h3 className="text-2xl font-black bg-gradient-to-r from-white via-purple-100 to-indigo-100 bg-clip-text text-transparent mb-4">
                        Araştırma Asistanınız Hazır!
                      </h3>
                      <p className="text-purple-100 max-w-md mx-auto mb-6 font-bold">
                        {selectedCategory 
                          ? `${researchCategories.find(c => c.id === selectedCategory)?.emoji} ${researchCategories.find(c => c.id === selectedCategory)?.title} konusunda size yardımcı olacağım.`
                          : 'Hangi konuda araştırma yapmak istiyorsunuz? Sorularınızı sorabilirsiniz.'
                        }
                      </p>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl mx-auto">
                        <div className="p-4 bg-gradient-to-br from-purple-900/80 to-indigo-900/80 rounded-lg border border-purple-400/50 hover:border-purple-300/70 transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/50">
                          <BookOpen className="text-blue-500 mb-2" size={24} />
                          <h4 className="text-white font-black mb-1">Kaynak Önerileri</h4>
                          <p className="text-purple-100 text-sm font-semibold">Güvenilir akademik kaynaklar</p>
                        </div>
                        <div className="p-4 bg-gradient-to-br from-purple-900/80 to-indigo-900/80 rounded-lg border border-purple-400/50 hover:border-purple-300/70 transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/50">
                          <BarChart3 className="text-green-500 mb-2" size={24} />
                          <h4 className="text-white font-black mb-1">Veri Analizi</h4>
                          <p className="text-purple-100 text-sm font-semibold">İstatistiksel değerlendirme</p>
                        </div>
                        <div className="p-4 bg-gradient-to-br from-purple-900/80 to-indigo-900/80 rounded-lg border border-purple-400/50 hover:border-purple-300/70 transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/50">
                          <Target className="text-yellow-500 mb-2" size={24} />
                          <h4 className="text-white font-black mb-1">Metodoloji</h4>
                          <p className="text-purple-100 text-sm font-semibold">Araştırma yöntemleri</p>
                        </div>
                        <div className="p-4 bg-gradient-to-br from-purple-900/80 to-indigo-900/80 rounded-lg border border-purple-400/50 hover:border-purple-300/70 transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/50">
                          <FileText className="text-purple-500 mb-2" size={24} />
                          <h4 className="text-white font-black mb-1">Rapor Hazırlama</h4>
                          <p className="text-purple-100 text-sm font-semibold">Profesyonel raporlar</p>
                        </div>
                      </div>
                    </motion.div>
                  )}

                  <AnimatePresence>
                    {messages.map((message) => (
                      <motion.div
                        key={message.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3 }}
                        className={cn(
                          "flex",
                          message.role === 'user' ? "justify-end" : "justify-start"
                        )}
                      >
                        <div
                          className={cn(
                            "max-w-3xl rounded-2xl p-4 shadow-lg flex items-start space-x-3",
                            message.role === 'user'
                              ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white ml-12 flex-row-reverse space-x-reverse"
                              : "bg-slate-800/80 backdrop-blur-sm text-slate-100 mr-12 border border-purple-500/20"
                          )}
                        >
                          <div className={cn(
                            "w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0",
                            message.role === 'user'
                              ? "bg-white/20"
                              : "bg-gradient-to-r from-purple-600 to-indigo-600"
                          )}>
                            {message.role === 'user' ? (
                              <User size={16} className="text-white" />
                            ) : (
                              <Bot size={16} className="text-white" />
                            )}
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <div className={cn(
                              "text-xs font-bold mb-1",
                              message.role === 'user' ? "text-purple-200" : "text-purple-300"
                            )}>
                              {message.role === 'user' ? 'Siz' : 'Araştırma Asistanı'}
                            </div>
                            <p className="whitespace-pre-wrap leading-relaxed text-sm font-semibold">{message.content}</p>
                            <div className={cn(
                              "text-xs opacity-60 mt-2",
                              message.role === 'user' ? "text-purple-200" : "text-purple-300"
                            )}>
                              {new Date(message.timestamp).toLocaleTimeString('tr-TR')}
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>

                  {/* Typing Indicator */}
                  <AnimatePresence>
                    {isLoading && (
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        className="flex justify-start"
                      >
                        <div className="max-w-3xl rounded-2xl p-4 bg-slate-800/80 backdrop-blur-sm border border-purple-500/20 mr-12 flex items-start space-x-3">
                          <div className="w-8 h-8 rounded-full bg-gradient-to-r from-purple-600 to-indigo-600 flex items-center justify-center flex-shrink-0">
                            <Bot size={16} className="text-white" />
                          </div>
                          
                          <div className="flex-1">
                            <div className="text-xs font-bold mb-1 text-purple-200">Araştırma Asistanı</div>
                            <div className="flex items-center space-x-2">
                              <div className="flex space-x-1">
                                <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce"></div>
                                <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                                <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                              </div>
                              <span className="text-purple-200 text-sm font-bold">Araştırma yapılıyor...</span>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <div ref={messagesEndRef} />
                </div>

                {/* Input Area */}
                <div className="p-4 border-t border-purple-500/40 bg-purple-900/60 backdrop-blur-sm">
                  <div className="max-w-4xl mx-auto">
                    <div className="relative">
                      <Textarea
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyPress={handleKeyPress}
                        placeholder="Araştırma konunuzu yazın veya soru sorun..."
                        className="min-h-[60px] pr-12 resize-none bg-purple-950/80 border-purple-500/60 focus:border-purple-400 text-white placeholder-purple-300 font-semibold"
                        disabled={isLoading}
                      />
                      <Button
                        onClick={sendMessage}
                        disabled={!input.trim() || isLoading}
                        size="icon"
                        className="absolute right-2 bottom-2 w-8 h-8 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500"
                      >
                        <Send size={16} />
                      </Button>
                    </div>
                    
                    <div className="flex justify-between items-center mt-2 text-xs text-purple-300 font-bold">
                      <span>🔍 Araştırma asistanı ile konuşuyorsunuz</span>
                      {!isPremium && (
                        <span>✨ Premium ile sınırsız araştırma</span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}