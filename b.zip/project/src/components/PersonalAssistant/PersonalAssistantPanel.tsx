import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Send, 
  Target, 
  Clock, 
  DollarSign, 
  Users, 
  Brain,
  BookOpen,
  Briefcase,
  Heart,
  Code,
  User,
  Bot,
  CheckCircle,
  Circle,
  RotateCcw,
  TrendingUp,
  Calendar,
  Lightbulb,
  Star,
  Award,
  Zap,
  Settings,
  Filter,
  Play,
  Pause,
  BarChart3
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { useApp } from '@/contexts/AppContext';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

interface ProjectStep {
  id: string;
  title: string;
  description: string;
  completed: boolean;
  duration: string;
  priority: 'low' | 'medium' | 'high';
}

interface Project {
  id: string;
  title: string;
  description: string;
  category: string;
  progress: number;
  steps: ProjectStep[];
  startDate: string;
  estimatedCompletion: string;
  difficulty: number;
}

const experienceLevels = [
  { value: 'beginner', label: 'Başlangıç', icon: '🌱', description: 'Yeni başlıyorum' },
  { value: 'intermediate', label: 'Orta', icon: '🌿', description: 'Temel bilgim var' },
  { value: 'advanced', label: 'İleri', icon: '🌳', description: 'Deneyimliyim' }
];

const timePeriods = [
  { value: 'urgent', label: 'Acil', icon: '⚡', description: '1 hafta içinde' },
  { value: 'short', label: 'Kısa Vadeli', icon: '📅', description: '1 ay içinde' },
  { value: 'long', label: 'Uzun Vadeli', icon: '🗓️', description: '3+ ay' }
];

const budgetLevels = [
  { value: 'limited', label: 'Sınırlı Bütçe', icon: '💰', description: 'Minimal harcama' },
  { value: 'medium', label: 'Orta Bütçe', icon: '💳', description: 'Makul yatırım' },
  { value: 'high', label: 'Geniş Bütçe', icon: '💎', description: 'Yüksek yatırım' }
];

const workStyles = [
  { value: 'solo', label: 'Solo Çalışma', icon: '👤', description: 'Tek başıma' },
  { value: 'team', label: 'Takım Çalışması', icon: '👥', description: 'Ekip halinde' },
  { value: 'hybrid', label: 'Hibrit', icon: '🔄', description: 'Karma yaklaşım' }
];

const focusAreas = [
  { value: 'creative', label: 'Yaratıcı Projeler', icon: '🎨', color: 'from-pink-500 to-rose-500' },
  { value: 'business', label: 'İş/Kariyer', icon: '💼', color: 'from-blue-500 to-indigo-500' },
  { value: 'personal', label: 'Kişisel Gelişim', icon: '🌟', color: 'from-green-500 to-emerald-500' },
  { value: 'technical', label: 'Teknik Projeler', icon: '⚙️', color: 'from-purple-500 to-violet-500' }
];

const projectTemplates = [
  {
    title: 'Kitap Yazma Projesi',
    category: 'creative',
    description: 'Kendi kitabınızı yazın ve yayınlayın',
    duration: '16-20 hafta',
    difficulty: 7,
    steps: [
      'Konsept ve Tür Belirleme',
      'Araştırma ve Kaynak Toplama',
      'Ana Hat ve Karakter Geliştirme',
      'Bölüm Planlaması',
      'İlk Taslak Yazımı',
      'Düzenleme ve Revizyon',
      'Beta Okuyucu Süreci',
      'Final Düzenlemesi',
      'Yayın Hazırlığı'
    ]
  },
  {
    title: 'İş Kurma Projesi',
    category: 'business',
    description: 'Kendi işinizi kurun ve büyütün',
    duration: '20-24 hafta',
    difficulty: 9,
    steps: [
      'İş Fikri Geliştirme ve Doğrulama',
      'Pazar Araştırması',
      'İş Planı Hazırlama',
      'Yasal İşlemler ve Kayıtlar',
      'Finansman Sağlama',
      'Ürün/Hizmet Geliştirme',
      'Pazarlama Stratejisi',
      'Lansман Hazırlığı'
    ]
  },
  {
    title: 'Kişisel Marka Oluşturma',
    category: 'personal',
    description: 'Dijital dünyada kişisel markanızı kurun',
    duration: '8-12 hafta',
    difficulty: 5,
    steps: [
      'Kişisel Değer Analizi',
      'Hedef Kitle Belirleme',
      'İçerik Stratejisi Geliştirme',
      'Sosyal Medya Optimizasyonu',
      'Portfolio/Website Oluşturma',
      'Network Kurma',
      'İçerik Üretimi',
      'Analiz ve İyileştirme'
    ]
  },
  {
    title: 'Mobil Uygulama Geliştirme',
    category: 'technical',
    description: 'Kendi mobil uygulamanızı geliştirin',
    duration: '12-16 hafta',
    difficulty: 8,
    steps: [
      'Uygulama Konsepti ve Planlama',
      'UI/UX Tasarımı',
      'Teknik Mimari Belirleme',
      'Frontend Geliştirme',
      'Backend Geliştirme',
      'Test ve Debug',
      'App Store Optimizasyonu',
      'Lansман ve Pazarlama'
    ]
  }
];

export function PersonalAssistantPanel() {
  const [messages, setMessages] = useState<Array<{id: string, role: 'user' | 'assistant', content: string, timestamp: string}>>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [currentProject, setCurrentProject] = useState<Project | null>(null);
  const [filters, setFilters] = useState({
    experience: 'intermediate',
    timeline: 'short',
    budget: 'medium',
    workStyle: 'solo',
    focus: 'business'
  });
  const [showProjectSetup, setShowProjectSetup] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const { generateAIResponse, settings } = useApp();
  const { user } = useAuth();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const sendMessage = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setIsLoading(true);

    const userMsgObj = {
      id: `user_${Date.now()}`,
      role: 'user' as const,
      content: userMessage,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMsgObj]);

    try {
      const personalAssistantPrompt = `Sen gelişmiş bir kişisel asistansın. Kullanıcıların hedeflerini gerçekleştirmelerine yardımcı olan, proje yönetimi becerileri olan ve adım adım rehberlik sağlayan bir mentör gibi davranıyorsun.

Kullanıcı Profili:
- Deneyim Seviyesi: ${experienceLevels.find(e => e.value === filters.experience)?.label}
- Zaman Dilimi: ${timePeriods.find(t => t.value === filters.timeline)?.label}
- Bütçe Durumu: ${budgetLevels.find(b => b.value === filters.budget)?.label}
- Çalışma Tarzı: ${workStyles.find(w => w.value === filters.workStyle)?.label}
- Odak Alanı: ${focusAreas.find(f => f.value === filters.focus)?.label}

Kullanıcı Mesajı: ${userMessage}

Lütfen:
1. Samimi ve destekleyici ol
2. Projeyi mantıklı aşamalara böl
3. Her adım için net talimatlar ver
4. Motivasyon sağlayıcı mesajlar ver
5. Kullanıcının seviyesine uygun dil kullan
6. Gerekirse alternatif çözümler sun

Yanıtını Türkçe ver ve kişisel asistan rolünde kal.`;

      const aiResponse = await generateAIResponse(personalAssistantPrompt, settings);
      
      const aiMsgObj = {
        id: `ai_${Date.now()}`,
        role: 'assistant' as const,
        content: aiResponse,
        timestamp: new Date().toISOString()
      };

      setMessages(prev => [...prev, aiMsgObj]);

    } catch (error) {
      console.error('Personal Assistant Error:', error);
      setMessages(prev => [...prev, {
        id: `error_${Date.now()}`,
        role: 'assistant' as const,
        content: 'Üzgünüm, bir hata oluştu. Lütfen tekrar deneyin.',
        timestamp: new Date().toISOString()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const startProjectTemplate = (template: typeof projectTemplates[0]) => {
    const newProject: Project = {
      id: `project_${Date.now()}`,
      title: template.title,
      description: template.description,
      category: template.category,
      progress: 0,
      steps: template.steps.map((step, index) => ({
        id: `step_${index}`,
        title: step,
        description: `${template.title} projesinin ${index + 1}. adımı`,
        completed: false,
        duration: '1-2 hafta',
        priority: index < 2 ? 'high' : index < 5 ? 'medium' : 'low'
      })),
      startDate: new Date().toISOString(),
      estimatedCompletion: new Date(Date.now() + (parseInt(template.duration) * 7 * 24 * 60 * 60 * 1000)).toISOString(),
      difficulty: template.difficulty
    };

    setCurrentProject(newProject);
    setShowProjectSetup(false);
    
    toast({
      title: "Proje Başlatıldı!",
      description: `${template.title} projeniz oluşturuldu ve takibe alındı.`
    });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="flex-1 bg-gradient-to-br from-indigo-950 via-purple-950 to-slate-950 h-full overflow-hidden">
      <div className="flex h-full">
        {/* Left Panel - Project Management */}
        <div className="w-80 bg-gradient-to-b from-slate-900/95 via-purple-900/90 to-indigo-950/95 backdrop-blur-xl border-r border-purple-400/30 p-6 overflow-y-auto shadow-2xl shadow-purple-900/50">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            {/* Header */}
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-gradient-to-r from-purple-500 via-violet-500 to-indigo-500 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-purple-500/40">
                <Target size={24} className="text-white" />
              </div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-white via-purple-100 to-violet-100 bg-clip-text text-transparent">Kişisel Asistan</h1>
              <p className="text-purple-300 text-sm font-medium">Hedeflerinizi gerçekleştirin</p>
            </div>

            {/* Filters */}
            <Card className="bg-gradient-to-br from-purple-900/90 via-indigo-900/80 to-purple-950/90 border-purple-400/40 backdrop-blur-md shadow-2xl shadow-purple-900/60">
              <CardHeader>
                <CardTitle className="text-white text-xl flex items-center font-black">
                  <Settings size={18} className="mr-2" />
                  Kişisel Profil
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-white text-sm font-bold mb-2 block">Deneyim Seviyesi</label>
                  <Select value={filters.experience} onValueChange={(value) => setFilters({...filters, experience: value})}>
                    <SelectTrigger className="bg-purple-950/90 border-purple-500/60 text-white hover:border-purple-400/80 font-semibold">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-purple-950 border-purple-500/60">
                      {experienceLevels.map((level) => (
                        <SelectItem key={level.value} value={level.value} className="text-white hover:bg-purple-900/70 font-semibold">
                          <div className="flex items-center space-x-2">
                            <span>{level.icon}</span>
                            <div>
                              <div className="font-bold text-white">{level.label}</div>
                              <div className="text-xs text-purple-200 font-medium">{level.description}</div>
                            </div>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-white text-sm font-bold mb-2 block">Zaman Dilimi</label>
                  <Select value={filters.timeline} onValueChange={(value) => setFilters({...filters, timeline: value})}>
                    <SelectTrigger className="bg-purple-950/90 border-purple-500/60 text-white hover:border-purple-400/80 font-semibold">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-purple-950 border-purple-500/60">
                      {timePeriods.map((period) => (
                        <SelectItem key={period.value} value={period.value} className="text-white hover:bg-purple-900/70 font-semibold">
                          <div className="flex items-center space-x-2">
                            <span>{period.icon}</span>
                            <div>
                              <div className="font-bold text-white">{period.label}</div>
                              <div className="text-xs text-purple-200 font-medium">{period.description}</div>
                            </div>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-white text-sm font-bold mb-2 block">Odak Alanı</label>
                  <div className="grid grid-cols-2 gap-2">
                    {focusAreas.map((area) => (
                      <Button
                        key={area.value}
                        variant={filters.focus === area.value ? "default" : "outline"}
                        size="sm"
                        onClick={() => setFilters({...filters, focus: area.value})}
                        className={cn(
                          "text-xs h-auto p-2 flex flex-col items-center space-y-1",
                          filters.focus === area.value 
                            ? `bg-gradient-to-r ${area.color} hover:opacity-90 text-white font-bold shadow-xl shadow-purple-500/50` 
                            : "border-purple-500/60 text-white hover:bg-purple-800/80 hover:border-purple-400/80 font-semibold"
                        )}
                      >
                        <span className="text-base">{area.icon}</span>
                        <span className="text-center leading-tight font-bold">{area.label}</span>
                      </Button>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Current Project */}
            {currentProject && (
              <Card className="bg-gradient-to-br from-emerald-900/90 via-green-900/80 to-teal-900/90 border-emerald-400/50 backdrop-blur-md shadow-2xl shadow-emerald-900/60">
                <CardHeader>
                  <CardTitle className="text-white text-xl flex items-center font-black">
                    <Award size={18} className="mr-2" />
                    Aktif Proje
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h3 className="text-white font-black text-lg">{currentProject.title}</h3>
                    <p className="text-emerald-100 text-sm font-semibold">{currentProject.description}</p>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-white font-bold">İlerleme</span>
                      <span className="text-white font-black">{currentProject.progress}%</span>
                    </div>
                    <Progress value={currentProject.progress} className="h-3 bg-emerald-950/80" />
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="bg-emerald-950/80 p-3 rounded-lg border border-emerald-400/30">
                      <div className="text-white font-bold">Zorluk</div>
                      <div className="text-white font-black text-lg">{currentProject.difficulty}/10</div>
                    </div>
                    <div className="bg-emerald-950/80 p-3 rounded-lg border border-emerald-400/30">
                      <div className="text-white font-bold">Adımlar</div>
                      <div className="text-white font-black text-lg">
                        {currentProject.steps.filter(s => s.completed).length}/{currentProject.steps.length}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2 max-h-40 overflow-y-auto">
                    {currentProject.steps.slice(0, 5).map((step, index) => (
                      <div key={step.id} className="flex items-center space-x-2 p-3 bg-emerald-950/80 rounded-lg border border-emerald-400/20">
                        {step.completed ? (
                          <CheckCircle size={16} className="text-emerald-300" />
                        ) : (
                          <Circle size={16} className="text-emerald-400" />
                        )}
                        <span className={cn(
                          "text-sm flex-1 font-semibold",
                          step.completed ? "text-emerald-200 line-through" : "text-white"
                        )}>
                          {step.title}
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Project Templates */}
            <Card className="bg-gradient-to-br from-purple-900/90 via-indigo-900/80 to-purple-950/90 border-purple-400/40 backdrop-blur-md shadow-2xl shadow-purple-900/60">
              <CardHeader>
                <CardTitle className="text-white text-xl flex items-center font-black">
                  <Lightbulb size={18} className="mr-2" />
                  Proje Şablonları
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {projectTemplates.map((template, index) => (
                  <div
                    key={index}
                    onClick={() => startProjectTemplate(template)}
                    className="p-4 bg-purple-950/80 hover:bg-purple-900/80 border border-purple-500/50 hover:border-purple-400/70 rounded-lg cursor-pointer transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/50"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h4 className="text-white font-bold text-sm">{template.title}</h4>
                        <p className="text-purple-100 text-xs mt-1 font-medium">{template.description}</p>
                        <div className="flex items-center space-x-3 mt-2">
                          <Badge variant="secondary" className="text-xs bg-purple-600/50 text-white font-semibold">
                            {template.duration}
                          </Badge>
                          <div className="flex items-center space-x-1">
                            <Star size={12} className="text-yellow-500" />
                            <span className="text-xs text-white font-bold">{template.difficulty}/10</span>
                          </div>
                        </div>
                      </div>
                      <div className={cn(
                        "w-8 h-8 rounded-lg flex items-center justify-center text-lg",
                        focusAreas.find(f => f.value === template.category)?.color ? 
                        `bg-gradient-to-r ${focusAreas.find(f => f.value === template.category)?.color}` :
                        "bg-purple-600"
                      )}>
                        {focusAreas.find(f => f.value === template.category)?.icon || '📋'}
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Right Panel - Chat Interface */}
        <div className="flex-1 flex flex-col">
          {/* Chat Header */}
          <div className="p-4 border-b border-purple-400/40 bg-gradient-to-r from-purple-900/90 via-indigo-900/80 to-purple-950/90 backdrop-blur-md shadow-xl">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-black text-white">Kişisel Asistan</h2>
                <p className="text-sm text-purple-100 font-bold">
                  Hedeflerinizi gerçekleştirmenize yardımcı oluyorum
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <Badge variant="secondary" className="bg-gradient-to-r from-purple-600/60 to-indigo-600/60 text-white border border-purple-400/40 font-bold">
                  {experienceLevels.find(e => e.value === filters.experience)?.label}
                </Badge>
                <Badge variant="secondary" className="bg-gradient-to-r from-indigo-600/60 to-violet-600/60 text-white border border-indigo-400/40 font-bold">
                  {focusAreas.find(f => f.value === filters.focus)?.label}
                </Badge>
              </div>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-6">
            {messages.length === 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center py-12"
              >
                <div className="w-20 h-20 rounded-full bg-gradient-to-r from-purple-500 via-violet-500 to-indigo-500 flex items-center justify-center mx-auto mb-6 shadow-lg shadow-purple-500/40">
                  <Target size={32} className="text-white" />
                </div>
                <h3 className="text-2xl font-bold bg-gradient-to-r from-white via-purple-100 to-violet-100 bg-clip-text text-transparent mb-4">
                  Hedeflerinizi Gerçekleştirin!
                </h3>
                <p className="text-purple-100 max-w-md mx-auto mb-6 font-bold">
                  Kişisel asistanınız olarak size adım adım rehberlik edeceğim. Hangi projeyi başlatmak istiyorsunuz?
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl mx-auto">
                  <div className="p-4 bg-gradient-to-br from-purple-900/80 to-indigo-900/80 rounded-lg border border-purple-400/50 hover:border-purple-300/70 transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/50">
                    <TrendingUp className="text-green-500 mb-2" size={24} />
                    <h4 className="text-white font-black mb-1">Proje Planlama</h4>
                    <p className="text-purple-100 text-sm font-semibold">Hedeflerinizi adımlara bölelim</p>
                  </div>
                  <div className="p-4 bg-gradient-to-br from-purple-900/80 to-indigo-900/80 rounded-lg border border-purple-400/50 hover:border-purple-300/70 transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/50">
                    <Calendar className="text-blue-500 mb-2" size={24} />
                    <h4 className="text-white font-black mb-1">Zaman Yönetimi</h4>
                    <p className="text-purple-100 text-sm font-semibold">Etkili zaman çizelgesi oluşturun</p>
                  </div>
                  <div className="p-4 bg-gradient-to-br from-purple-900/80 to-indigo-900/80 rounded-lg border border-purple-400/50 hover:border-purple-300/70 transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/50">
                    <Zap className="text-yellow-500 mb-2" size={24} />
                    <h4 className="text-white font-black mb-1">Motivasyon Desteği</h4>
                    <p className="text-purple-100 text-sm font-semibold">Hedefe odaklanmaya devam edin</p>
                  </div>
                  <div className="p-4 bg-gradient-to-br from-purple-900/80 to-indigo-900/80 rounded-lg border border-purple-400/50 hover:border-purple-300/70 transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/50">
                    <BarChart3 className="text-purple-500 mb-2" size={24} />
                    <h4 className="text-white font-black mb-1">İlerleme Takibi</h4>
                    <p className="text-purple-100 text-sm font-semibold">Başarılarınızı ölçün</p>
                  </div>
                </div>
              </motion.div>
            )}

            <AnimatePresence>
              {messages.map((message) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                  className={cn(
                    "flex",
                    message.role === 'user' ? "justify-end" : "justify-start"
                  )}
                >
                  <div
                    className={cn(
                      "max-w-3xl rounded-2xl p-4 shadow-lg flex items-start space-x-3",
                      message.role === 'user'
                        ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white ml-12 flex-row-reverse space-x-reverse"
                        : "bg-slate-800/80 backdrop-blur-sm text-slate-100 mr-12 border border-purple-500/20"
                    )}
                  >
                    <div className={cn(
                      "w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0",
                      message.role === 'user'
                        ? "bg-white/20"
                        : "bg-gradient-to-r from-purple-600 to-indigo-600"
                    )}>
                      {message.role === 'user' ? (
                        <User size={16} className="text-white" />
                      ) : (
                        <Bot size={16} className="text-white" />
                      )}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className={cn(
                        "text-xs font-medium mb-1",
                        message.role === 'user' ? "text-purple-200" : "text-purple-300"
                      )}>
                        {message.role === 'user' ? 'Siz' : 'Kişisel Asistan'}
                      </div>
                      <p className="whitespace-pre-wrap leading-relaxed text-sm font-medium">{message.content}</p>
                      <div className={cn(
                        "text-xs opacity-60 mt-2",
                        message.role === 'user' ? "text-purple-200" : "text-purple-300"
                      )}>
                        {new Date(message.timestamp).toLocaleTimeString('tr-TR')}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            {/* Typing Indicator */}
            <AnimatePresence>
              {isLoading && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="flex justify-start"
                >
                  <div className="max-w-3xl rounded-2xl p-4 bg-slate-800/80 backdrop-blur-sm border border-purple-500/20 mr-12 flex items-start space-x-3">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-r from-purple-600 to-indigo-600 flex items-center justify-center flex-shrink-0">
                      <Bot size={16} className="text-white" />
                    </div>
                    
                    <div className="flex-1">
                      <div className="text-xs font-bold mb-1 text-purple-200">Kişisel Asistan</div>
                      <div className="flex items-center space-x-2">
                        <div className="flex space-x-1">
                          <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce"></div>
                          <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                          <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                        </div>
                        <span className="text-purple-200 text-sm font-semibold">Size özel plan hazırlıyorum...</span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="p-4 border-t border-purple-500/40 bg-purple-900/60 backdrop-blur-sm">
            <div className="max-w-4xl mx-auto">
              <div className="relative">
                <Textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Hedeflerinizi paylaşın, proje hakkında soru sorun veya yardım isteyin..."
                  className="min-h-[60px] pr-12 resize-none bg-purple-950/80 border-purple-500/60 focus:border-purple-400 text-white placeholder-purple-300 font-medium"
                  disabled={isLoading}
                />
                <Button
                  onClick={sendMessage}
                  disabled={!input.trim() || isLoading}
                  size="icon"
                  className="absolute right-2 bottom-2 w-8 h-8 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500"
                >
                  <Send size={16} />
                </Button>
              </div>
              
              <div className="flex justify-between items-center mt-2 text-xs text-purple-300 font-semibold">
                <span>🎯 Kişisel asistanınız ile konuşuyorsunuz</span>
                <span>✨ Hedeflerinizi gerçekleştirmenize yardımcı oluyorum</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}