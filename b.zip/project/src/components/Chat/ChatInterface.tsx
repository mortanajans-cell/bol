import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Plus, RotateCcw, Share, ThumbsUp, ThumbsDown, Copy, User, Bot, Sparkles, Zap, Brain, Code, Lightbulb } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { useApp } from '@/contexts/AppContext';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

export function ChatInterface() {
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { 
    currentConversation, 
    addMessage, 
    createNewConversation, 
    settings, 
    generateAIResponse, 
    updateConversationTitle 
  } = useApp();
  const { user } = useAuth();

  const examplePrompts = [
    {
      icon: Lightbulb,
      title: "Yaratıcı Yazım",
      description: "Bir hikaye, şiir veya yaratıcı metin yazın",
      prompt: "Bana kısa bir bilim kurgu hikayesi yaz. Gelecekte geçsin ve teknoloji temalı olsun."
    },
    {
      icon: Code,
      title: "Kod Yardımı",
      description: "Programlama soruları ve kod örnekleri",
      prompt: "React'te bir todo list komponenti nasıl oluştururum? Kod örneği ile açıkla."
    },
    {
      icon: Brain,
      title: "Analiz ve Açıklama",
      description: "Karmaşık konuları basit şekilde açıklayın",
      prompt: "Yapay zeka ve makine öğrenmesi arasındaki farkı basit terimlerle açıkla."
    },
    {
      icon: Zap,
      title: "Hızlı Sorular",
      description: "Genel bilgi ve hızlı cevaplar",
      prompt: "2024'te teknoloji dünyasındaki en önemli trendler neler?"
    }
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [currentConversation?.messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setIsLoading(true);

    if (!currentConversation) {
      createNewConversation();
      setTimeout(() => {
        sendMessageToConversation(userMessage);
      }, 100);
      return;
    }

    sendMessageToConversation(userMessage);
  };

  const sendMessageToConversation = (userMessage: string) => {
    addMessage(userMessage, 'user');

    if (currentConversation && currentConversation.messages.length === 0) {
      const title = userMessage.slice(0, 50) + (userMessage.length > 50 ? '...' : '');
      setTimeout(() => {
        updateConversationTitle(currentConversation.id, title);
      }, 100);
    }

    setTimeout(async () => {
      const aiResponse = await generateAIResponse(userMessage, settings);
      addMessage(aiResponse, 'assistant');
      setIsLoading(false);
    }, 1000 + Math.random() * 2000);
  };

  const handleExampleClick = (prompt: string) => {
    setInput(prompt);
    setTimeout(() => {
      const textarea = document.querySelector('textarea');
      if (textarea) {
        textarea.focus();
      }
    }, 100);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const copyMessage = (content: string) => {
    navigator.clipboard.writeText(content);
    toast({ title: "Kopyalandı!" });
  };

  const regenerateResponse = () => {
    if (!currentConversation || currentConversation.messages.length === 0) return;
    
    const lastUserMessage = [...currentConversation.messages]
      .reverse()
      .find(msg => msg.role === 'user');
    
    if (!lastUserMessage) return;
    
    setIsLoading(true);
    
    setTimeout(async () => {
      const newResponse = await generateAIResponse(lastUserMessage.content, settings);
      addMessage(newResponse, 'assistant');
      setIsLoading(false);
    }, 500);
  };

  // Empty state - no conversation
  if (!currentConversation) {
    return (
      <div className="flex-1 flex flex-col bg-white h-full">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-full bg-gradient-to-r from-purple-600 to-indigo-600 flex items-center justify-center">
              <Sparkles size={16} className="text-white" />
            </div>
            <h1 className="text-xl font-semibold text-gray-900">AI Portal</h1>
          </div>
          <Button
            onClick={createNewConversation}
            variant="outline"
            size="sm"
            className="border-gray-300 hover:bg-gray-50"
          >
            <Plus size={16} className="mr-2" />
            Yeni Sohbet
          </Button>
        </div>

        {/* Welcome Content */}
        <div className="flex-1 flex flex-col items-center justify-center p-8 max-w-4xl mx-auto w-full">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <div className="w-20 h-20 rounded-full bg-gradient-to-r from-purple-600 to-indigo-600 flex items-center justify-center mx-auto mb-6">
              <Sparkles size={32} className="text-white" />
            </div>
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Size nasıl yardımcı olabilirim?</h2>
            <p className="text-lg text-gray-600 max-w-2xl">
              Sorularınızı sorun, yaratıcı projeler üzerinde çalışın veya herhangi bir konuda yardım alın.
            </p>
          </motion.div>

          {/* Example Prompts */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full max-w-4xl mb-8">
            {examplePrompts.map((example, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                onClick={() => handleExampleClick(example.prompt)}
                className="p-4 border border-gray-200 rounded-xl hover:border-purple-300 hover:shadow-md transition-all cursor-pointer group"
              >
                <div className="flex items-start space-x-3">
                  <div className="w-10 h-10 rounded-lg bg-gray-100 group-hover:bg-purple-100 flex items-center justify-center transition-colors">
                    <example.icon size={20} className="text-gray-600 group-hover:text-purple-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900 mb-1">{example.title}</h3>
                    <p className="text-sm text-gray-600">{example.description}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Input Area */}
          <div className="w-full max-w-3xl">
            <div className="relative">
              <Textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Mesajınızı yazın..."
                className="min-h-[60px] pr-12 resize-none border-gray-300 focus:border-purple-500 focus:ring-purple-500 rounded-xl"
                disabled={isLoading}
              />
              <Button
                onClick={handleSend}
                disabled={!input.trim() || isLoading}
                size="icon"
                className="absolute right-2 bottom-2 w-8 h-8 bg-purple-600 hover:bg-purple-700 rounded-lg"
              >
                <Send size={16} />
              </Button>
            </div>
            
            <div className="flex justify-between items-center mt-3 text-xs text-gray-500">
              <span>AI Portal size yardımcı olmak için burada</span>
              {user?.role === 'free' && (
                <span>Ücretsiz plan: Bu ay {Math.floor(Math.random() * 50)}/50 mesaj</span>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Chat with messages
  return (
    <div className="flex-1 flex flex-col bg-white h-full">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-full bg-gradient-to-r from-purple-600 to-indigo-600 flex items-center justify-center">
            <Sparkles size={16} className="text-white" />
          </div>
          <div>
            <h2 className="font-semibold text-gray-900 truncate max-w-md">{currentConversation.title}</h2>
            <p className="text-sm text-gray-500">{currentConversation.messages.length} mesaj</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <Button
            onClick={regenerateResponse}
            disabled={isLoading || currentConversation.messages.length < 2}
            variant="ghost"
            size="sm"
            className="text-gray-600 hover:text-gray-900"
          >
            <RotateCcw size={16} />
          </Button>
          <Button
            onClick={createNewConversation}
            variant="outline"
            size="sm"
            className="border-gray-300 hover:bg-gray-50"
          >
            <Plus size={16} className="mr-2" />
            Yeni
          </Button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
          <AnimatePresence>
            {currentConversation.messages.map((message, index) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="group"
              >
                <div className="flex items-start space-x-4">
                  {/* Avatar */}
                  <div className={cn(
                    "w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0",
                    message.role === 'user'
                      ? "bg-gray-200"
                      : "bg-gradient-to-r from-purple-600 to-indigo-600"
                  )}>
                    {message.role === 'user' ? (
                      <User size={16} className="text-gray-600" />
                    ) : (
                      <Bot size={16} className="text-white" />
                    )}
                  </div>
                  
                  {/* Message Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2 mb-2">
                      <span className="font-semibold text-gray-900">
                        {message.role === 'user' ? 'Siz' : 'AI Portal'}
                      </span>
                      <span className="text-xs text-gray-500">
                        {new Date(message.timestamp).toLocaleTimeString('tr-TR')}
                      </span>
                    </div>
                    
                    <div className="prose prose-gray max-w-none">
                      <p className="whitespace-pre-wrap text-gray-800 leading-relaxed">
                        {message.content}
                      </p>
                    </div>
                    
                    {/* Message Actions */}
                    {message.role === 'assistant' && (
                      <div className="flex items-center space-x-2 mt-3 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button
                          onClick={() => copyMessage(message.content)}
                          variant="ghost"
                          size="sm"
                          className="h-8 px-2 text-gray-500 hover:text-gray-700"
                        >
                          <Copy size={14} className="mr-1" />
                          Kopyala
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 px-2 text-gray-500 hover:text-gray-700"
                        >
                          <ThumbsUp size={14} />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 px-2 text-gray-500 hover:text-gray-700"
                        >
                          <ThumbsDown size={14} />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 px-2 text-gray-500 hover:text-gray-700"
                        >
                          <Share size={14} />
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {/* Typing Indicator */}
          <AnimatePresence>
            {isLoading && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="flex items-start space-x-4"
              >
                <div className="w-8 h-8 rounded-full bg-gradient-to-r from-purple-600 to-indigo-600 flex items-center justify-center flex-shrink-0">
                  <Bot size={16} className="text-white" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-2">
                    <span className="font-semibold text-gray-900">AI Portal</span>
                    <span className="text-xs text-gray-500">yazıyor...</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input Area */}
      <div className="border-t border-gray-200 p-4">
        <div className="max-w-4xl mx-auto">
          <div className="relative">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Mesajınızı yazın..."
              className="min-h-[60px] pr-12 resize-none border-gray-300 focus:border-purple-500 focus:ring-purple-500 rounded-xl"
              disabled={isLoading}
            />
            <Button
              onClick={handleSend}
              disabled={!input.trim() || isLoading}
              size="icon"
              className="absolute right-2 bottom-2 w-8 h-8 bg-purple-600 hover:bg-purple-700 rounded-lg"
            >
              <Send size={16} />
            </Button>
          </div>
          
          <div className="flex justify-between items-center mt-3 text-xs text-gray-500">
            <span>AI Portal size yardımcı olmak için burada</span>
            {user?.role === 'free' && (
              <span>Ücretsiz plan: Bu ay {Math.floor(Math.random() * 50)}/50 mesaj</span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}