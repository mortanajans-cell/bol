export interface User {
  id: string;
  email: string;
  role: 'free' | 'premium';
  plan: 'free' | 'premium_monthly' | 'premium_yearly';
  created_at: string;
  updated_at: string;
}

export interface Conversation {
  id: string;
  user_id: string;
  title: string;
  messages: Message[];
  created_at: string;
  updated_at: string;
  folder_id?: string;
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export interface Settings {
  id: string;
  user_id: string;
  mode: 'creative' | 'analytical' | 'business' | 'technical';
  temperature: number;
  max_tokens: number;
  response_length: 'short' | 'long';
  response_style: 'balanced' | 'detailed' | 'summary' | 'casual' | 'professional';
}

export interface Template {
  id: string;
  category: string;
  title: string;
  description: string;
  content: string;
  premium_only: boolean;
  is_favorite?: boolean;
}

export interface Payment {
  id: string;
  user_id: string;
  plan: string;
  status: 'active' | 'cancelled' | 'expired';
  start_date: string;
  end_date: string;
  provider_id: string;
}

export interface Folder {
  id: string;
  user_id: string;
  name: string;
  created_at: string;
}